using eboleka.Models;
using eboleka.Services;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authentication.JwtBearer;

var builder = WebApplication.CreateBuilder(args);

var config = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();

builder.Services.AddAuthentication(auth =>{
    auth.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    auth.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    auth.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(val =>{
    val.TokenValidationParameters = new TokenValidationParameters{
        ValidIssuer = config["JwtSettings:Issuer"],
        ValidAudience = config["JwtSettings:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["JwtSettings:TokenKey"]!)),
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true
    };
});

// Add services to the container.

builder.Services.AddAuthorization();

builder.Services.Configure<DatabaseSettings>(
    builder.Configuration.GetSection("Database")
);

builder.Services.Configure<JwtSettings>(
    builder.Configuration.GetSection("JwtSettings")
);

builder.Services.Configure<MapSettings>(
    builder.Configuration.GetSection("Maps")
);

builder.Services.Configure<SecurityAPI>(
    builder.Configuration.GetSection("SecurityAPI")
);

builder.Services.AddHostedService<DailyTaskService>();
builder.Services.AddSingleton<JwtService>();
builder.Services.AddSingleton<AccountService>();
builder.Services.AddSingleton<ProductService>();
builder.Services.AddSingleton<ExploreService>();
builder.Services.AddSingleton<OrderService>();
builder.Services.AddSingleton<CartService>();
builder.Services.AddSingleton<TraceService>();
builder.Services.AddSingleton<NotificationService>();
builder.Services.AddSingleton<TransactionService>();
builder.Services.AddSingleton<WalletService>();
builder.Services.AddSingleton<ArchiveOrderService>();
builder.Services.AddSingleton<EmailService>();
builder.Services.AddSingleton<MapService>();

builder.Services.AddCors();
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseRouting();

app.UseCors(x => x
    .AllowAnyMethod()
    .AllowAnyHeader()
    .SetIsOriginAllowed(origin => true) // allow any origin
    .AllowCredentials()
);

app.UseAuthentication();
app.UseAuthorization();

app.UseEndpoints(endpoint =>{
    endpoint.MapControllers();
});

app.Run();
