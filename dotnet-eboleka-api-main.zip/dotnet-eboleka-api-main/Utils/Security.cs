using System.Security.Cryptography;
using System.Text;

namespace eboleka.Utils;

public class Security{

    public static string getID(){
        return Guid.NewGuid().ToString();
    }

    public static string generateOTP(int MAX_LENGTH){
        string OTP = "";
        string[] Characters = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

        Random rand = new Random();  
    
        for (int i = 0; i < MAX_LENGTH; i++){    
            OTP += Characters[rand.Next(0, Characters.Length)];      
        }  
  
        return OTP;
    }

    public static string hashPassword(string Password){
        using (SHA256 sha256 = SHA256.Create()){
            byte[] passwordBytes = Encoding.UTF8.GetBytes(Password);

            byte[] hashBytes = sha256.ComputeHash(passwordBytes);

            StringBuilder sb = new StringBuilder();
            foreach (byte b in hashBytes){
                sb.Append(b.ToString("x2"));
            }

            return sb.ToString(); 
        }
    } 

    public static bool isPasswordCorrect(string hashedPassword, string password){
        return hashedPassword.Equals(hashPassword(password));
    }

}