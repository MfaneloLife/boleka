namespace eboleka.Utils;

public class Time{

    /* 
    * This class provides static methods for working with date and or time
    */

    public static string getDayDateTime(){
        DateTime currentDateTime = DateTime.Now;
        string formattedDayDateTime = currentDateTime.ToString("dddd dd MMMM yyyy HH:mm:ss");

        return formattedDayDateTime;
    }

    public static string getDateTime(){
        DateTime currentDateTime = DateTime.Now;
        string formattedDateTime = currentDateTime.ToString("dd MMMM yyyy HH:mm:ss");

        return formattedDateTime;
    }

    public static string getDate(){
        DateTime currentDateTime = DateTime.Now;
        string formattedDate = currentDateTime.ToString("dd MMMM yyyy");

        return formattedDate;
    }

    public static string getTime(){
        DateTime currentDateTime = DateTime.Now;
        string formattedTime = currentDateTime.ToString("HH:mm:ss");

        return formattedTime;
    }

    private static string convertMonth(string month){
        string mon = "";
        string[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

        for(int i = 0; i < months.Length; i++){
            if(months[i].Equals(month)){
                mon = (i + 1).ToString();
                break;
            }
        }

        return mon;
    }

    private static string convertMonthFull(string month){
        string mon = "";
        string[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

        for(int i = 0; i < months.Length; i++){
            if(months[i].Equals(month)){
                mon = (i + 1).ToString();
                break;
            }
        }

        return mon;
    }

    public static string convertDate(string date){
        string[] dateSplit = date.Split(" ");

        string day = dateSplit[0];
        string month = convertMonth(dateSplit[1]);
        string year = dateSplit[2];

        return day + "/" + month + "/" + year;
    }

    public static string convertDateFull(string date){
        string[] dateSplit = date.Split(" ");

        string day = dateSplit[0];
        string month = convertMonthFull(dateSplit[1]);
        string year = dateSplit[2];

        return day + "/" + month + "/" + year;
    }


}
