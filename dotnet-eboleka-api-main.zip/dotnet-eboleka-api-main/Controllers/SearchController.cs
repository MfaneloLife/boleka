using System;
using eboleka.Dtos;
using eboleka.Utils;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class SearchController : ControllerBase{
    private const string baseUrl = "/search";

    private readonly ProductService productService;

    public SearchController(ProductService productService){
        this.productService = productService;
    }

    [Authorize]
    [HttpPost(baseUrl)]
    public async Task<IActionResult> search([FromBody]SearchSchema input){
        Dictionary<string, List<ProductDto>> response = new Dictionary<string, List<ProductDto>>();

        var productsQuery = await productService.searchProduct(input.item.Trim());

        List<ProductDto> products = new List<ProductDto>();

        if(productsQuery != null){
            foreach(var product in productsQuery){
                products.Add(new ProductDto(product));
            }
        }

        response.Add("data", products);

        return Ok(response);
    }
}