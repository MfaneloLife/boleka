using System;
using eboleka.Dtos;
using eboleka.Utils;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class ExploreController : ControllerBase{
    private const string baseUrl = "/explore";

    private readonly ExploreService exploreService;
    private readonly ProductService productService;
    private readonly AccountService accountService;


    public ExploreController(ExploreService exploreService, ProductService productService, AccountService accountService){
        this.exploreService = exploreService;
        this.productService = productService;
        this.accountService = accountService;
    }


    [Authorize]
    [HttpPost(baseUrl)]
    public async Task<IActionResult> explore([FromBody]ExploreSchema input){
        Dictionary<string, Explore> response = new Dictionary<string, Explore>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(isBusiness){
            return Unauthorized(response);
        }

        var productsQuery = await productService.getAllProducts();
        var accountQuery = await accountService.getAllBusinesses();

        List<ProductDto> newProducts = new List<ProductDto>();
        List<AccountDto> newAccounts = new List<AccountDto>();

        if(productsQuery != null){
            List<Product> products = productsQuery;
            newProducts = exploreService.getProducts(input.products, products);
        }

        if(accountQuery != null){
            List<Account> accounts = accountQuery;
            newAccounts = exploreService.getBusinesses(input.businesses, accounts);
        }

        response.Add("data", new Explore(newProducts, newAccounts));

        return Ok(response);
    }

}