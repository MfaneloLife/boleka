using Microsoft.AspNetCore.Mvc;
using eboleka.Services;
using eboleka.Models;
using eboleka.Schemas;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class MapController : ControllerBase{
    private const string baseUrl = "/map";

    private readonly MapService mapService;
    private readonly TraceService traceService;

    public MapController(MapService mapService, TraceService traceService){
        this.mapService = mapService;
        this.traceService = traceService;
    }

    [Authorize]
    [HttpPost(baseUrl)]
    public async Task<IActionResult> getAddress([FromBody]MapsSchema input){ 
        Dictionary<string, List<MapsResponseData>> response = new Dictionary<string, List<MapsResponseData>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        MapsResponse mapsResponse = await mapService.geocoding(input.street, input.suburb, input.city, input.code);

        Trail trail = new Trail("Maps query", "Validating address api call ", email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        if(mapsResponse.valid){
            response.Add("data", mapsResponse.places);
            return Ok(response);
        }
        
        return BadRequest();
    }


}