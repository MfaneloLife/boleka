using System;
using eboleka.Dtos;
using eboleka.Utils;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class ProductController : ControllerBase{
    private const string baseUrl = "/product";

    private readonly ProductService productService;
    private readonly OrderService orderService;
    private readonly TraceService traceService;

    public ProductController(ProductService productService, OrderService orderService, TraceService traceService){
        this.productService = productService;
        this.orderService = orderService;
        this.traceService = traceService;
    }

    [Authorize]
    [HttpGet(baseUrl)]
    public async Task<IActionResult> getProducts(){
        Dictionary<string, List<ProductDto>> response = new Dictionary<string, List<ProductDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(!isBusiness){
            return Unauthorized(response);
        }

        var productsQuery = await productService.getProductsByOwnerId(uid);

        List<Product> products;

        if(productsQuery != null){
            products = productsQuery;
        }else{
            products = new List<Product>();
        }

        response.Add("products", productService.getProducts(products));

        return Ok(response);
    }

    [Authorize]
    [HttpPost(baseUrl)]
    public async Task<IActionResult> addProduct([FromBody]ProductSchema input){
        Dictionary<string, List<ProductDto>> response = new Dictionary<string, List<ProductDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(!isBusiness){
            return Unauthorized(response);
        }

        var productsQuery = await productService.getProductsByOwnerId(uid);

        List<Product> products;

        if(productsQuery != null){
            products = productsQuery;
        }else{
            products = new List<Product>();
        }

        if(products.Count < 30){
            Product product = new Product(Security.getID(), input.title, uid, name, input.imageUrl, input.description, input.price, input.isVisible, input.paymentMethods, input.deliveryMethods);
            await productService.addProduct(product);
            products.Add(product);
            response.Add("products", productService.getProducts(products));

            Trail trail = new Trail("Adding service", "New product added: " + input.title , email, baseUrl);
            await traceService.addTrail(uid, email, trail);

            return Ok(response);
        }

        return BadRequest(response);
    }

    [Authorize]
    [HttpPut(baseUrl)]
    public async Task<IActionResult> updateProduct([FromBody]ProductSchema input){
        Dictionary<string, List<ProductDto>> response = new Dictionary<string, List<ProductDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(!isBusiness){
            return Unauthorized(response);
        }

        var productQuery = await productService.getProductById(input.uid);

        if(productQuery != null){
            Product product = productQuery;
            if(!product.getOwnerId().Equals(uid)){
                return Unauthorized(response);
            }

            await productService.updateProduct(product, input);
            var productsQuery = await productService.getProductsByOwnerId(uid);

            List<Product> products;

            if(productsQuery != null){
                products = productsQuery;
            }else{
                products = new List<Product>();
            }

            Trail trail = new Trail("Adding service", "Product has been updated: " + input.title , email, baseUrl);
            await traceService.addTrail(uid, email, trail);

            response.Add("products", productService.getProducts(products));
            return Ok(response);
        }

        return BadRequest(response);
    }

    [Authorize]
    [HttpDelete(baseUrl)]
    public async Task<IActionResult> deleteProduct([FromBody]ProductSchema input){
        Dictionary<string, List<ProductDto>> response = new Dictionary<string, List<ProductDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(!isBusiness){
            return Unauthorized(response);
        }

        var productQuery = await productService.getProductById(input.uid);

        if(productQuery != null){
            Product product = productQuery;
            if(!product.getOwnerId().Equals(uid)){
                return Unauthorized(response);
            } 

            var ordersQuery = await orderService.getOrdersByProductId(product.getUid());
            List<Order> orders = new List<Order>();

            if(ordersQuery != null){
                orders = ordersQuery;
            }

            if(orders.Count > 0){
                await productService.hideProduct(product, traceService);
                return BadRequest();
            }

            Trail trail = new Trail("Deleted service", "Service deleted: " + product.getTitle() , email, baseUrl);
            await traceService.addTrail(uid, email, trail);

            await productService.deleteProductById(input.uid);

            var productsQuery = await productService.getProductsByOwnerId(uid);

            List<Product> products;

            if(productsQuery != null){
                products = productsQuery;
            }else{
                products = new List<Product>();
            }

            response.Add("products", productService.getProducts(products));
            return Ok(response);
        }

        return BadRequest();
    }

}