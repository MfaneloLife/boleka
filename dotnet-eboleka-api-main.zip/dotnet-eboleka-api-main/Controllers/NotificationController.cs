using System;
using eboleka.Dtos;
using eboleka.Utils;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class NotificationController : ControllerBase{
    private const string baseUrl = "/notifications";

    private readonly NotificationService notificationService;

    public NotificationController(NotificationService notificationService){
        this.notificationService = notificationService;
    }

    [Authorize]
    [HttpGet(baseUrl)]
    public async Task<IActionResult> getNotifications(){
        Dictionary<string, List<NotificationDto>> response = new Dictionary<string, List<NotificationDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var notificationQuery = await notificationService.getNotification(uid);

        Notification notification = new Notification(uid);

        if(notificationQuery != null){
            notification = notificationQuery;
        }else{
            await notificationService.addNotification(notification);
        }

        List<NotificationDto> messages = new List<NotificationDto>();

        foreach(Message message in notification.getMessages()){
            messages.Add(new NotificationDto(message));
        }

        response.Add("data", messages);

        return Ok(response);

    }

    [Authorize]
    [HttpPut(baseUrl)]
    public async Task<IActionResult> updateNotifications([FromBody]NotificationSchema input){
        Dictionary<string, List<NotificationDto>> response = new Dictionary<string, List<NotificationDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var notificationQuery = await notificationService.getNotification(uid);

        Notification notification = new Notification(uid);

        if(notificationQuery != null){
            notification = notificationQuery;
        }else{
            await notificationService.addNotification(notification);
        }

        notification.markAsRead(input.uid);

        await notificationService.updateNotification(uid, notification.getMessages());

        return Ok(response);
    }



}