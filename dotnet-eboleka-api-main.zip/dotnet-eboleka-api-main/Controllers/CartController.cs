using System;
using eboleka.Dtos;
using eboleka.Utils;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class CartController : ControllerBase{
    private const string baseUrl = "/cart";

    private readonly CartService cartService;
    private readonly ProductService productService;
    private readonly TraceService traceService;

    public CartController(CartService cartService, ProductService productService, TraceService traceService){
        this.cartService = cartService;
        this.productService = productService;
        this.traceService = traceService;
    }

    [Authorize]
    [HttpGet(baseUrl)]
    public async Task<IActionResult> getCart(){
        Dictionary<string, List<ProductDto>> response = new Dictionary<string, List<ProductDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(isBusiness){
            return Unauthorized(response);
        }

        var cartQuery = await cartService.getCart(uid);

        Cart cart = new Cart(uid);

        if(cartQuery != null){
            cart = cartQuery;
        }else{
            await cartService.addCart(cart);
        }

        var productsQuery = await cartService.getProducts(uid, cart.getProductIds(), productService);

        List<ProductDto> products = new List<ProductDto>();

        if(productsQuery != null){
            products = productsQuery;
        }

        response.Add("data", products);

        return Ok(response);
    }

    [Authorize]
    [HttpPost(baseUrl)]
    public async Task<IActionResult> addCart([FromBody]CartSchema input){
        Dictionary<string, List<ProductDto>> response = new Dictionary<string, List<ProductDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(isBusiness){
            return Unauthorized(response);
        }

        var productQuery = await productService.getProductById(input.uid);

        if(productQuery == null){
            return BadRequest();
        }

        Product product = productQuery;

        if(!product.getIsVisible()){
            return BadRequest();
        }

        var cartQuery = await cartService.getCart(uid);

        Cart cart = new Cart(uid);

        if(cartQuery != null){
            cart = cartQuery;
        }else{
            await cartService.addCart(cart);
        }

        if(!cartService.shouldAdd(input.uid, cart.getProductIds())){
            Trail _trail = new Trail("Add service - cart", "Could not add " + input.uid , email, baseUrl);
            await traceService.addTrail(uid, email, _trail);
            return BadRequest();
        }

        cart.addProductId(input.uid);

        await cartService.updateCart(uid, cart.getProductIds());

        var productsQuery = await cartService.getProducts(uid, cart.getProductIds(), productService);

        List<ProductDto> products = new List<ProductDto>();

        if(productsQuery != null){
            products = productsQuery;
        }

        Trail trail = new Trail("Add service - cart", "Added " + input.uid , email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        response.Add("data", products);

        return Ok(response);
    }

     [Authorize]
    [HttpDelete(baseUrl)]
    public async Task<IActionResult> deleteCart([FromBody]CartSchema input){
        Dictionary<string, List<ProductDto>> response = new Dictionary<string, List<ProductDto>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(isBusiness){
            return Unauthorized(response);
        }

        var cartQuery = await cartService.getCart(uid);

        Cart cart = new Cart(uid);

        if(cartQuery != null){
            cart = cartQuery;
        }else{
            await cartService.addCart(cart);
        }

        if(!cart.getProductIds().Contains(input.uid)){
            Trail _trail = new Trail("Remove service - cart", "Could not remove, does not exists " + input.uid , email, baseUrl);
            await traceService.addTrail(uid, email, _trail);
            return BadRequest();
        }

        await cartService.removeCart(uid, input.uid);

        cart.removeProductId(input.uid);

        var productsQuery = await cartService.getProducts(uid, cart.getProductIds(), productService);

        List<ProductDto> products = new List<ProductDto>();

        if(productsQuery != null){
            products = productsQuery;
        }

        Trail trail = new Trail("Remove service - cart", "Removed " + input.uid , email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        response.Add("data", products);

        return Ok(response);
    }

}