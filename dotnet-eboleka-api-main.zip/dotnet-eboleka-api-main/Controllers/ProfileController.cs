using System;
using eboleka.Dtos;
using eboleka.Utils;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class ProfileController : ControllerBase{
    private const string baseUrl = "/profile";

    private readonly ProductService productService;
    private readonly AccountService accountService;
    private readonly TraceService traceService;

    public ProfileController(ProductService productService, AccountService accountService, TraceService traceService){
        this.productService = productService;
        this.accountService = accountService;
        this.traceService = traceService;
    }


    [Authorize]
    [HttpGet(baseUrl)]
    public async Task<IActionResult> getProfile([FromQuery(Name = "id")]string id){
        Dictionary<string, Profile> response = new Dictionary<string, Profile>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var accountQuery = await accountService.findAccountById(id);

        if(accountQuery == null){
            return BadRequest();
        }

        Account account = accountQuery;

        if(account.getIsBusiness() == isBusiness){
            return BadRequest();
        }

        var productQuery = await productService.getProductsByOwnerId(id);

        List<ProductDto> products = new List<ProductDto>();

        if(productQuery != null){
            List<Product> allProducts = productQuery;
            foreach(Product product in allProducts){
                if(product.getIsVisible()){
                    products.Add(new ProductDto(product));
                }
            }
        }

        response.Add("data", new Profile(new AccountDto(account), products));

        return Ok(response);
    }

    [Authorize]
    [HttpGet(baseUrl + "/me")]
    public async Task<IActionResult> myProfile(){
        Dictionary<string, MyProfileDto> response = new Dictionary<string, MyProfileDto>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var accountQuery = await accountService.findAccountById(uid);

        if(accountQuery == null){
            return BadRequest();
        }

        Account account = accountQuery;

        if(account.getIsSuspended()){
            return BadRequest();
        }

        response.Add("data", new MyProfileDto(account));
        
        return Ok(response);
    }

    [Authorize]
    [HttpPut(baseUrl)]
    public async Task<IActionResult> updateProfile([FromBody]ProfileSchema input){
        Dictionary<string, MyProfileDto> response = new Dictionary<string, MyProfileDto>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var accountQuery = await accountService.findAccountById(uid);

        if(accountQuery == null){
            return BadRequest();
        }

        Account account = accountQuery;

        if(account.getIsSuspended()){
            return Unauthorized();
        }

        Address address = new Address(input.street, input.suburb, input.city, input.code, 0, 0);
        await accountService.updateProfile(uid, input.imageUrl, input.about, input.phone, address);

        account.setImageUrl(input.imageUrl);
        account.setAbout(input.about);
        account.setPhone(input.phone);
        account.setAddress(address);

        Trail trail = new Trail("Update profile", "Profile has been updated" , email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        response.Add("data", new MyProfileDto(account));
        
        return Ok(response);
    }

}