using Microsoft.AspNetCore.Mvc;

namespace eboleka.Controllers;

[ApiController]
public class Home : ControllerBase
{
    [HttpGet("/")]
    public string get(){
        return "Eboleka";
    }

    [HttpPost("/")]
    public string post(){
        return "Eboleka";
    }

}
