using System;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class TransactionController : ControllerBase{
    private const string baseUrl = "/transaction";

    private readonly OrderService orderService;
    private readonly TransactionService transactionService;
    private readonly NotificationService notificationService;
    private readonly WalletService walletService;
    private readonly AccountService accountService;
    private readonly EmailService emailService;
    private readonly ProductService productService;
    private readonly TraceService traceService;

    public TransactionController(TransactionService transactionService, OrderService orderService, NotificationService notificationService, WalletService walletService, AccountService accountService, ProductService productService, EmailService emailService, TraceService traceService){
        this.orderService = orderService;
        this.transactionService = transactionService;
        this.notificationService = notificationService;
        this.walletService = walletService;
        this.accountService = accountService;
        this.emailService = emailService;
        this.productService = productService;
        this.traceService = traceService;
    }

    [Authorize]
    [HttpPost(baseUrl)]
    public async Task<IActionResult> payment([FromBody]ITN_Payload payload){
        Transaction transaction = new Transaction(payload.m_payment_id, payload.pf_payment_id, payload.payment_status, payload.item_name, payload.name_first, payload.email_address, payload.url, payload.amount_gross, payload.amount_net, payload.isvalid);

        if(!payload.payment_status.Equals("COMPLETE")){
            transaction.setReason("PAYMENT NOT COMPLETE");
            await transactionService.recordTransaction(transaction);
            return Ok();
        }

        var orderQuery = await orderService.getOrderById(payload.m_payment_id);

        if(orderQuery == null){
            transaction.setReason("ORDER NOT FOUND");
            await transactionService.recordTransaction(transaction);
            return Ok();
        }

        Order order = orderQuery;

        string[] ids = {order.getClientId(), order.getBusinessId()};

        transaction.setClientId(order.getClientId());
        transaction.setBusinessId(order.getBusinessId());

        if(payload.amount_gross != order.getPrice()){
            transaction.setReason("GROSS AMOUNT NOT EQUAL TO ORDER PRICE");
            await transactionService.recordTransaction(transaction);
            return Ok();
        }

        transaction.setReason("OK");
        await transactionService.recordTransaction(transaction);
        await orderService.payOrder(order.getUid());

        Trail trail = new Trail("Payment received", "Payment received for order: #" + order.getOrderId(), "eboleka", baseUrl);
        await traceService.addTrail(order.getBusinessId(), "", trail);

        foreach(string id in ids){
            var notificationQuery = await notificationService.getNotification(id);

            Notification notification = new Notification(id);

            if(notificationQuery != null){
                notification = notificationQuery;
            }else{
                await notificationService.addNotification(notification);
            }

            string title = "Payment Received: #" + order.getOrderId();
            string body = "Payment has been made to an order #" + order.getOrderId() + "(Service Date: " + order.getServiceDate() + "). " + " There are no actions you have to take.";
            Message message = new Message(title, body, "#00DFA2");

            notification.addMessage(message);

            await notificationService.updateNotification(id, notification.getMessages());
        }

        await emailService.handleOrderEmails(order, productService, accountService, "/payment");

        return Ok();
    }

    [Authorize]
    [HttpGet(baseUrl + "/wallet")]
    public async Task<IActionResult> getWallet(){
        Dictionary<string, string> response = new Dictionary<string, string>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var walletQuery = await walletService.getWallet(uid);

        if(walletQuery == null){
            Wallet _wallet = new Wallet(uid, isBusiness);
            await walletService.addWallet(_wallet);
            walletQuery = _wallet;
        }

        Wallet wallet = walletQuery;

        response.Add("cardIncome", wallet.getCardIncome().ToString());
        response.Add("cashIncome", wallet.getCashIncome().ToString());
        response.Add("date", wallet.getDate());
        response.Add("orders", wallet.getOrdersCompleted().ToString());

        return Ok(response);
    }

}
