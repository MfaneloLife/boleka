using System;
using eboleka.Dtos;
using eboleka.Utils;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class OrderController : ControllerBase{
    private const string baseUrl = "/order";

    private readonly CartService cartService;
    private readonly OrderService orderService;
    private readonly ProductService productService;
    private readonly ArchiveOrderService archiveOrderService;
    private readonly NotificationService notificationService;
    private readonly WalletService walletService;
    private readonly EmailService emailService;
    private readonly AccountService accountService;
    private readonly TraceService traceService;

    public OrderController(OrderService orderService, ProductService productService, CartService cartService, NotificationService notificationService, ArchiveOrderService archiveOrderService, WalletService walletService, EmailService emailService, AccountService accountService, TraceService traceService){
        this.cartService = cartService;
        this.orderService = orderService;
        this.productService = productService;
        this.notificationService = notificationService;
        this.archiveOrderService = archiveOrderService;
        this.walletService = walletService;
        this.emailService = emailService;
        this.accountService = accountService;
        this.traceService = traceService;
    }

    [Authorize]
    [HttpGet(baseUrl)]
    public async Task<IActionResult> getOrders(){
        Dictionary<string, List<OrderBundle>> response = new Dictionary<string, List<OrderBundle>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(isBusiness){
            return BadRequest();
        }

        var orderQuery = await orderService.getOrdersByClientId(uid);

        List<Order> orders  = new List<Order>();

        if(orderQuery != null){
            orders = orderQuery;
        }

        var orderBundlesQuery = await orderService.getOrderBundles(orders, productService);

        List<OrderBundle> orderBundles = new List<OrderBundle>();

        if(orderBundlesQuery != null){
            orderBundles = orderBundlesQuery;
        }

        response.Add("data", orderService.sortOrders(orderBundles));
        return Ok(response);
    }

    [Authorize]
    [HttpPost(baseUrl)]
    public async Task<IActionResult> addOrder([FromBody]OrderSchema input){
        Dictionary<string, OrderCartDto> response = new Dictionary<string, OrderCartDto>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var productQuery = await productService.getProductById(input.productId);

        if(productQuery == null || isBusiness){
            return BadRequest();
        }

        Product product = productQuery;

        if(!product.getIsVisible()){
            return BadRequest();
        }

        Address address = new Address(input.street, input.suburb, input.city, input.code, input.lat, input.lon);
        string orderId = orderService.generateOrderId(input.paymentMethod, input.deliveryMethod);
        Order order = new Order(Security.getID(), orderId, input.serviceDate, input.comments, uid, name, product.getOwnerId(), product.getOwnerName(), product.getUid(), product.getPrice(), input.duration, input.paymentMethod, input.deliveryMethod, address);

        await orderService.addOrder(order);

        Trail trail = new Trail("Order added", "Order placed: #" + orderId, email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        var orderQuery = await orderService.getOrdersByClientId(uid);

        List<Order> orders  = new List<Order>();

        if(orderQuery != null){
            orders = orderQuery;
        }

        var orderBundlesQuery = await orderService.getOrderBundles(orders, productService);

        List<OrderBundle> orderBundles = new List<OrderBundle>();

        if(orderBundlesQuery != null){
            orderBundles = orderService.sortOrders(orderBundlesQuery);
        }

        await cartService.removeCart(uid, input.productId);

        var cartQuery = await cartService.getCart(uid);

        Cart cart = new Cart(uid);

        if(cartQuery != null){
            cart = cartQuery;
        }else{
            await cartService.addCart(cart);
        }

        var productsQuery = await cartService.getProducts(uid, cart.getProductIds(), productService);

        List<ProductDto> products = new List<ProductDto>();

        if(productsQuery != null){
            products = productsQuery;
        }

        OrderCartDto data = new OrderCartDto();
        data.cart = products;
        data.order = orderBundles;

        var notificationQuery = await notificationService.getNotification(product.getOwnerId());

        Notification notification = new Notification(product.getOwnerId());

        if(notificationQuery != null){
            notification = notificationQuery;
        }else{
            await notificationService.addNotification(notification);
        }

        string title = "Request Order: #" + order.getOrderId();
        string body = "A new service request has been placed by " + name + ". Requesting: " + product.getTitle() + ". Date: " + order.getServiceDate() + ". For more details check on requests tab.";
        Message message = new Message(title, body, "#9681EB");

        notification.addMessage(message);

        await notificationService.updateNotification(product.getOwnerId(), notification.getMessages());

        response.Add("data", data);
        return Ok(response);
    }

    [Authorize]
    [HttpGet(baseUrl + "/requests")]
    public async Task<IActionResult> getRequests(){
        Dictionary<string, List<OrderBundle>> response = new Dictionary<string, List<OrderBundle>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(!isBusiness){
            return BadRequest();
        }

        var orderQuery = await orderService.getOrdersByBusinessId(uid);

        List<Order> orders  = new List<Order>();

        if(orderQuery != null){
            orders = orderQuery;
        }

        List<Order> filteredOrders = orderService.filterOrders(orders, false);

        var orderBundlesQuery = await orderService.getOrderBundles(filteredOrders, productService);

        List<OrderBundle> orderBundles = new List<OrderBundle>();

        if(orderBundlesQuery != null){
            orderBundles = orderBundlesQuery;
        }

        response.Add("data", orderService.sortOrders(orderBundles));
        return Ok(response);
    }

    [Authorize]
    [HttpGet(baseUrl + "/approved")]
    public async Task<IActionResult> getApproved(){
        Dictionary<string, List<OrderBundle>> response = new Dictionary<string, List<OrderBundle>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(!isBusiness){
            return BadRequest();
        }

        var orderQuery = await orderService.getOrdersByBusinessId(uid);

        List<Order> orders  = new List<Order>();

        if(orderQuery != null){
            orders = orderQuery;
        }

        List<Order> filteredOrders = orderService.filterOrders(orders, true);

        var orderBundlesQuery = await orderService.getOrderBundles(filteredOrders, productService);

        List<OrderBundle> orderBundles = new List<OrderBundle>();

        if(orderBundlesQuery != null){
            orderBundles = orderBundlesQuery;
        }

        response.Add("data", orderService.sortOrders(orderBundles));
        return Ok(response);
    }

    [Authorize]
    [HttpPut(baseUrl)]
    public async Task<IActionResult> updateApprove([FromBody]OrderSchema input){
        Dictionary<string, List<OrderBundle>> response = new Dictionary<string, List<OrderBundle>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(!isBusiness){
            return BadRequest();
        }

        var orderQuery = await orderService.getOrderById(input.uid);

        Order order = new Order();

        if(orderQuery != null){
            order = orderQuery;
        }else{
            return BadRequest();
        }

        if(!order.getBusinessId().Equals(uid)){
            return BadRequest();
        }

        await orderService.approveOrder(order.getUid());

        Trail trail = new Trail("Order approved", "Order approved: #" + order.getOrderId(), email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        var notificationQuery = await notificationService.getNotification(order.getClientId());

        Notification notification = new Notification(order.getClientId());

        if(notificationQuery != null){
            notification = notificationQuery;
        }else{
            await notificationService.addNotification(notification);
        }

        string title = "Order Aprroved: #" + order.getOrderId();
        string body = "Your order #" + order.getOrderId() + " has been approved by "  + name + " (the supplier). Please check in app if you have to take actions";
        Message message = new Message(title, body, "#6DA9E4");

        notification.addMessage(message);

        await notificationService.updateNotification(order.getClientId(), notification.getMessages());

        var ordersQuery = await orderService.getOrdersByBusinessId(uid);

        List<Order> orders  = new List<Order>();

        if(ordersQuery != null){
            orders = ordersQuery;
        }

        List<Order> filteredOrders = orderService.filterOrders(orders, false);

        var orderBundlesQuery = await orderService.getOrderBundles(filteredOrders, productService);

        List<OrderBundle> orderBundles = new List<OrderBundle>();

        if(orderBundlesQuery != null){
            orderBundles = orderBundlesQuery;
        }

        List<Order> filteredOrders2 = orderService.filterOrders(orders, true);

        var orderBundlesQuery2 = await orderService.getOrderBundles(filteredOrders2, productService);

        List<OrderBundle> orderBundles2 = new List<OrderBundle>();

        if(orderBundlesQuery2 != null){
            orderBundles2 = orderBundlesQuery2;
        }

        await emailService.handleOrderEmails(order, productService, accountService, "/approved");

        response.Add("requests", orderService.sortOrders(orderBundles));
        response.Add("approved", orderService.sortOrders(orderBundles2));
        return Ok(response);
    }

    [Authorize]
    [HttpDelete(baseUrl)]
    public async Task<IActionResult> deleteOrder([FromBody]OrderSchema input){
        Dictionary<string, List<OrderBundle>> response = new Dictionary<string, List<OrderBundle>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var orderQuery = await orderService.getOrderById(input.uid);

        Order order = new Order();

        if(orderQuery != null){
            order = orderQuery;
        }else{
            return BadRequest();
        }

        if(!order.getBusinessId().Equals(uid) && !order.getClientId().Equals(uid)){
            return BadRequest();
        }

        if(order.isPaid()){
            return BadRequest();
        }

        await orderService.deleteOrderById(order.getUid());

        Trail trail = new Trail("Order removed", "Deleted order: #" + order.getOrderId(), email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        string id = isBusiness ? order.getClientId() : order.getBusinessId();

        var notificationQuery = await notificationService.getNotification(id);

        Notification notification = new Notification(id);

        if(notificationQuery != null){
            notification = notificationQuery;
        }else{
            await notificationService.addNotification(notification);
        }

        if(!isBusiness && order.isApproved()){
            string title = "Order Cancelled: #" + order.getOrderId();
            string body = "An order that was approved order #" + order.getOrderId() + "(Service Date: " + order.getServiceDate() + ") " + " has been cancelled by "  + name + " (the client). There are no actions you have to take.";
            Message message = new Message(title, body, "#5A96E3");

            notification.addMessage(message);

            await notificationService.updateNotification(id, notification.getMessages());
        }else if(isBusiness){
            string title = "Order Declined: #" + order.getOrderId();

            string body = "Your order #" + order.getOrderId() + "(Service Date: " + order.getServiceDate() + ") " + " has been declined by "  + name + " (the supplier). Please try a different vendor or service, we are really sorry.";
            Message message = new Message(title, body, "#5A96E3");

            notification.addMessage(message);

            await emailService.handleOrderEmails(order, productService, accountService, "/decline");
 
            await notificationService.updateNotification(id, notification.getMessages());
        }

        List<Order> orders  = new List<Order>();

        if(isBusiness){
            var ordersQuery = await orderService.getOrdersByBusinessId(uid);

            if(ordersQuery != null){
                orders = ordersQuery;
            }
        }else{
            var ordersQuery = await orderService.getOrdersByClientId(uid);

            if(ordersQuery != null){
                orders = ordersQuery;
            }
        }

        List<OrderBundle> orderBundles = new List<OrderBundle>();

        if(isBusiness){
            List<Order> filteredOrders = orderService.filterOrders(orders, false);

            var orderBundlesQuery = await orderService.getOrderBundles(filteredOrders, productService);

            if(orderBundlesQuery != null){
                orderBundles = orderBundlesQuery;
            }
        }else{
            var orderBundlesQuery = await orderService.getOrderBundles(orders, productService);

            if(orderBundlesQuery != null){
                orderBundles = orderBundlesQuery;
            } 
        }

        response.Add("data", orderService.sortOrders(orderBundles));

        return Ok(response);
    }

    [Authorize]
    [HttpPost(baseUrl + "/identifier")]
    public async Task<IActionResult> getOrderIdentifier([FromBody]IdentifierSchema input){
        Dictionary<string, IdentifierDto> response = new Dictionary<string, IdentifierDto>();

        var orderQuery = await orderService.getOrderById(input.uid);

        if(orderQuery == null){
            return BadRequest();
        }

        Order order  = orderQuery;

        IdentifierDto identifier = new IdentifierDto(order.getUid(), order.getOrderId(), order.getPrice());

        response.Add("data", identifier);

        return Ok(response);
    }

    [Authorize]
    [HttpPut(baseUrl + "/scan")]
    public async Task<IActionResult> generateQR([FromBody]ScanSchema input){
        Dictionary<string, string> response = new Dictionary<string, string>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(isBusiness){
            return BadRequest();
        }

        var orderQuery = await orderService.getOrderById(input.uid);

        if(orderQuery == null){
            return BadRequest();
        }

        Order order = orderQuery;

        if(!order.getClientId().Equals(uid) || order.isCompleted()){
            return BadRequest();
        }

        QR qr = new QR(Security.getID(), Time.getTime(), Time.getDate());

        await orderService.updateQR(order.getUid(), qr);

        response.Add("engine", "ebolekangn");
        response.Add("uid", order.getUid());
        response.Add("clientId", uid);
        response.Add("businessId", order.getBusinessId());
        response.Add("orderId", order.getOrderId());
        response.Add("key", qr.getCode());

        return Ok(response);
    }

    [Authorize]
    [HttpPost(baseUrl + "/scan")]
    public async Task<IActionResult> validateQR([FromBody]ScanSchema input){
        Dictionary<string, string> response = new Dictionary<string, string>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        if(!isBusiness){
            return BadRequest();
        }

        var orderQuery = await orderService.getOrderById(input.uid);

        if(orderQuery == null){
            return BadRequest();
        }

        Order order = orderQuery;

        if(!order.getBusinessId().Equals(uid) || order.isCompleted()){
            return BadRequest();
        }

        bool valid = orderService.isCodeValid(order.getQR(), input.key);

        if(!valid){
            return BadRequest();
        }

        order.setCompleted(true);
        await orderService.completeOrder(order.getUid());

        var walletQuery = await walletService.getWallet(uid);

        if(walletQuery == null){
            Wallet _wallet = new Wallet(uid, isBusiness);
            await walletService.addWallet(_wallet);
            walletQuery = _wallet;
        }

        Wallet wallet = walletQuery;

        double cardIncome = wallet.getCardIncome();
        double cashIncome = wallet.getCashIncome();
        int completedOrders = wallet.getOrdersCompleted();

        if(order.getPaymentMethod() == 0){
            await walletService.updateCashIncome(uid, cashIncome + order.getPrice());
        }else{
            await walletService.updateCardIncome(uid, cardIncome + order.getPrice());
        }

        await walletService.updateCompletedOrder(uid, completedOrders + 1);

        ArchiveOrder archiveOrder = new ArchiveOrder(order);
        
        await archiveOrderService.archive(archiveOrder);

        Trail trail = new Trail("Order completed", "Order mark as done: #" + order.getOrderId(), email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        return Ok(response);
    }

    [Authorize]
    [HttpDelete(baseUrl + "/drop")]
    public async Task<IActionResult> deleteApprovedOrder([FromBody]OrderSchema input){
        Dictionary<string, List<OrderBundle>> response = new Dictionary<string, List<OrderBundle>>();

        var userClaims = HttpContext.User.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        var orderQuery = await orderService.getOrderById(input.uid);
        Order order = new Order();

        if(orderQuery != null){
            order = orderQuery;
        }else{
            return BadRequest();
        }

        if(!order.getBusinessId().Equals(uid) || order.isCompleted()){
            return BadRequest();
        }

        await orderService.deleteOrderById(order.getUid());

        if(order.isPaid()){
            await walletService.applyRefund(order);
        }

        var notificationQuery = await notificationService.getNotification(order.getClientId());

        Notification notification = new Notification(order.getClientId());

        if(notificationQuery != null){
            notification = notificationQuery;
        }else{
            await notificationService.addNotification(notification);
        }

        string title = "Order Cancelled: #" + order.getOrderId();
        string body = "Your order #" + order.getOrderId() + "(Service Date: " + order.getServiceDate() + ") " + " has been cancelled by "  + name + " (the supplier). Please try a different vendor or service, we are really sorry.";
        Message message = new Message(title, body, "#de5f72");
        notification.addMessage(message);

        await emailService.handleOrderEmails(order, productService, accountService, "/cancel");

        await notificationService.updateNotification(order.getClientId(), notification.getMessages());
        
        List<Order> orders  = new List<Order>();

        var ordersQuery = await orderService.getOrdersByBusinessId(uid);

        if(ordersQuery != null){
            orders = ordersQuery;
        }
        
        List<OrderBundle> orderBundles = new List<OrderBundle>();

        List<Order> filteredOrders = orderService.filterOrders(orders, true);

        var orderBundlesQuery = await orderService.getOrderBundles(filteredOrders, productService);

        if(orderBundlesQuery != null){
            orderBundles = orderBundlesQuery;
        }

        Trail trail = new Trail("Order drop", "Order has been dropped: #" + order.getOrderId(), email, baseUrl);
        await traceService.addTrail(uid, email, trail);

        response.Add("data", orderService.sortOrders(orderBundles));

        return Ok(response);
    }



}