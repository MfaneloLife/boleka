using System;
using eboleka.Utils;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace eboleka.Controllers;

public class AccountController : ControllerBase{
    private const string baseUrl = "/account";

    private readonly NotificationService notificationService;
    private readonly AccountService accountService;
    private readonly JwtService jwtService;
    private readonly EmailService emailService;
    private readonly WalletService walletService;
    private readonly TraceService traceService;

    public AccountController(AccountService accountService, JwtService jwtService, EmailService emailService, NotificationService notificationService, WalletService walletService, TraceService traceService){
        this.notificationService = notificationService;
        this.accountService = accountService;
        this.jwtService = jwtService;
        this.emailService = emailService;
        this.walletService = walletService;
        this.traceService = traceService;
    }

    [HttpPost(baseUrl + "/register")]
    public async Task<IActionResult> registerUser([FromBody]RegisterSchema input){
        Dictionary<string, string> response = new Dictionary<string, string>();
        Account account = new Account(input.name, input.email.Trim().ToLower(), input.phone, input.password.Trim(), input.isBusiness);

        bool isDataValid = accountService.isDataValid(input.name, input.email.Trim().ToLower(), input.password.Trim(), input.phone);

        if(isDataValid){
            var accountExists = await accountService.accountExistsByEmail(account.getEmail());
        
            if(!accountExists){
                await accountService.createAccount(account);

                Wallet wallet = new Wallet(account.getUid(), account.getIsBusiness());
                await walletService.addWallet(wallet);

                Dictionary<string, string> data = new Dictionary<string, string>();
                data.Add("name", account.getName());
                data.Add("email", account.getEmail());
                await emailService.sendWelcomeMessage(data);

                Trail trail = new Trail("Account reg", "New account created", account.getEmail(), baseUrl + "/register");
                await traceService.addTrail(account.getUid(), account.getEmail(), trail);
        
                response.Add("status", "CREATED");
                response.Add("email", account.getEmail());
                return Ok(response);
            }else{
                response.Add("status", "EXISTS");
                response.Add("email", account.getEmail());
                return BadRequest(response);
            }
        }else{
            response.Add("status", "INVALID");
            response.Add("email", account.getEmail());
            return BadRequest(response);
        }
    }

    [HttpPost(baseUrl + "/signin")]
    public async Task<IActionResult> signinUser([FromBody]SigininSchema input){
        Dictionary<string, string> response = new Dictionary<string, string>();
        var accountQuery = await accountService.findAccountByEmail(input.email.Trim().ToLower());

        if(accountQuery != null){
            Account account = accountQuery;

            if(accountService.isOTPTimeout(account.getOtp())){
                response.Add("status", "TIMEOUT");
                return BadRequest(response);
            }else{
                bool passwordCorrect = account.isPasswordCorrect(input.password.Trim());
                
                if(passwordCorrect){
                    if(account.getIsSuspended()){
                        response.Add("status", "XXX");
                        return BadRequest(response);
                    }

                    Trail trail = new Trail("Account signin", "Sign in, account credentials correct", account.getEmail(), baseUrl + "/signin");
                    await traceService.addTrail(account.getUid(), account.getEmail(), trail);

                    await accountService.handleOTP(account, emailService);
                    response.Add("status", "CORRECT");
                    response.Add("uid", account.getUid());
                    response.Add("email", account.getEmail());
                    response.Add("name", account.getName());
                    response.Add("phone", account.getPhoneNumber());
                    response.Add("isBusiness", account.getIsBusiness().ToString().ToLower());
                    return Ok(response);
                }else{
                    response.Add("status", "INVALID");
                    return BadRequest(response);
                }
            }
        }else{
            response.Add("status", "INVALID");
            return BadRequest(response);
        }

    }

    [HttpPost(baseUrl + "/otp")]
    public async Task<IActionResult> authOTP([FromBody]OTPSchema input){
        Dictionary<string, string> response = new Dictionary<string, string>();
        var accountQuery = await accountService.findAccountById(input.uid);

        if(input.deviceId == null || input.deviceId.Equals("")){
            return Unauthorized();
        }

        if(accountQuery != null){
            Account account = accountQuery;

            if(accountService.isOTPTimeout(account.getOtp())){
                response.Add("status", "TIMEOUT");
                return BadRequest(response);
            }else{
                if(account.getOtp().getPin().Equals(input.otp)){
                    string time = account.getOtp().getTime();
                    string date = account.getOtp().getDate();
                    if(accountService.isOTPExpired(time, date)){
                        response.Add("status", "EXPIRED");
                        await accountService.handleOTP(account, emailService);
                        return BadRequest(response);
                    }else{
                        Trail trail = new Trail("Account OTP", "OTP request, device signin", account.getEmail(), baseUrl + "/otp");
                        await traceService.addTrail(account.getUid(), account.getEmail(), trail);

                        await accountService.resertOTP(account);
                        string token = jwtService.generateToken(account.getUid(), account.getEmail(), account.getName(), account.getIsBusiness());
                        response.Add("status", "CORRECT");
                        response.Add("token", token);

                        var notificationQuery = await notificationService.getNotification(account.getUid());

                        Notification notification = new Notification(account.getUid());

                        if(notificationQuery != null){
                            notification = notificationQuery;
                        }else{
                            await notificationService.addNotification(notification);
                        }

                        string title = "Device Login";
                        string body = "A device has just logged into your account. " + input.device;
                        Message message = new Message(title, body, "#F94A29");

                        notification.addMessage(message);

                        await notificationService.updateNotification(account.getUid(), notification.getMessages());

                        await accountService.updateDeviceId(input.uid, input.deviceId);

                        return Ok(response);
                    }
                }else{
                    await accountService.handleOTP(account, emailService);
                    response.Add("status", "INVALID");
                    return BadRequest(response);
                }
            }
        }else{
            response.Add("status", "INVALID");
            return BadRequest(response);
        }
    }

    [HttpPost(baseUrl + "/refresh")]
    public async Task<IActionResult> refeshToken([FromBody] OTPSchema input){
        Dictionary<string, string> response = new Dictionary<string, string>();

        if (!jwtService.isTokenValid(input.uid) || input.deviceId.Equals("")){
            return BadRequest();
        }

        string uid = jwtService.getUid(input.uid);

        var accountQuery = await accountService.findAccountById(uid);

        if(accountQuery == null){
            return BadRequest();
        }

        Account account = accountQuery;

        if(!account.getDeviceId().Equals(Security.hashPassword(input.deviceId))){
            Trail _trail = new Trail("Token refresh", "Device id has changed, cannot issue out a new token", account.getEmail(), baseUrl + "/refresh");
            await traceService.addTrail(account.getUid(), account.getEmail(), _trail);
            return BadRequest();
        }

        Trail trail = new Trail("Token refresh", "Generating a new access token", account.getEmail(), baseUrl + "/refresh");
        await traceService.addTrail(account.getUid(), account.getEmail(), trail);

        string token = jwtService.refreshToken(input.uid);
        response.Add("token", token);

        return Ok(response);
    }
}



