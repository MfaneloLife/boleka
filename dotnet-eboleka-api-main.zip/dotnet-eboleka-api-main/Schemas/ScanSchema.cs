namespace eboleka.Schemas;

public class ScanSchema{

    public string uid {get; set;} = null!;
    public string orderId {get; set;} = null!;
    public string clientId {get; set;} = null!;
    public string businessId {get; set;} = null!;
    public string key {get; set;} = null!;
}
   
