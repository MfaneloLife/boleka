using eboleka.Models;
namespace eboleka.Schemas;

public class NotificationSchema{

    public string uid {get; set;} = null!;

}