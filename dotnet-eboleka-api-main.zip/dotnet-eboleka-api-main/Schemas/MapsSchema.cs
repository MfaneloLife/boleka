namespace eboleka.Schemas;

public class MapsSchema{
    public string street {get; set;} = null!;
    public string suburb {get; set;} = null!;
    public string city {get; set;} = null!;
    public string code {get; set;} = null!;
}