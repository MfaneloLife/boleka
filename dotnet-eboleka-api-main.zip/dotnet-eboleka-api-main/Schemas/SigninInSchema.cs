
namespace eboleka.Schemas;

public class SigininSchema{
    public string email {get; set;} = null!;
    public string password {get; set;} = null!;
}
