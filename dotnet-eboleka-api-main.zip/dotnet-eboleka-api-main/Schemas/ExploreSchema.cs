using eboleka.Dtos;
namespace eboleka.Schemas;

public class ExploreSchema{
    public List<string> products {get; set;} = null!;
    public List<string> businesses {get; set;} = null!;
}