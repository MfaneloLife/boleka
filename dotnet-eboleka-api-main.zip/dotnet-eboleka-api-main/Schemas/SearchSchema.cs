namespace eboleka.Schemas;

public class SearchSchema{
    public string item {get; set;} = null!;
}
   