namespace eboleka.Schemas;

public class ITN_Payload{

    public string url {get; set;} = null!;
    public string payment_string {get; set;} = null!;
    public string m_payment_id {get; set;} = null!;
    public string pf_payment_id {get; set;} = null!;
    public string payment_status {get; set;} = null!;
    public string item_name {get; set;} = null!;
    public double amount_gross {get; set;} = 0;
    public double amount_net {get; set;} = 0;
    public string name_first {get; set;} = null!;
    public string email_address {get; set;} = null!;
    public bool isvalid {get; set;} = false;
}
