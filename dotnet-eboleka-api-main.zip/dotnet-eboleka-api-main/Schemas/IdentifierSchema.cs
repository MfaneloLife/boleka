namespace eboleka.Schemas;

public class IdentifierSchema{

    public string uid {get; set;} = null!;

}