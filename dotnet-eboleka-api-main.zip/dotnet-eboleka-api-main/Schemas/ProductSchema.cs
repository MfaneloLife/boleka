using eboleka.Models;
namespace eboleka.Schemas;

public class ProductSchema{

    public string uid {get; set;} = null!;
    public string title {get; set;} = null!;
    public string imageUrl {get; set;} = null!;
    public string description {get; set;} = null!;
    public double price {get; set;} = 0.0;
    public bool isVisible {get; set;} = false;
    public List<DeliveryMethod> deliveryMethods {get; set;} = null!;
    public List<PaymentMethod> paymentMethods {get; set;} = null!;
}
