using eboleka.Models;
namespace eboleka.Schemas;

public class CartSchema{

    public string uid {get; set;} = null!;

}