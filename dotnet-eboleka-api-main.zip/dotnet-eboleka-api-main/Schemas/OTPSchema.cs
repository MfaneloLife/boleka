
namespace eboleka.Schemas;

public class OTPSchema{
    public string uid {get; set;} = null!;
    public string otp {get; set;} = null!;
    public string device {get; set;} = null!;
    public string deviceId {get; set;} = null!;
}
