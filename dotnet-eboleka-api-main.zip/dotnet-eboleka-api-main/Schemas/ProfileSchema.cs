namespace eboleka.Schemas;

public class ProfileSchema{
    public string imageUrl {get; set;} = null!;
    public string about {get; set;} = null!;
    public string phone {get; set;} = null!;
    public string street {get; set;} = null!;
    public string suburb {get; set;} = null!;
    public string city {get; set;} = null!;
    public string code {get; set;} = null!;
}
