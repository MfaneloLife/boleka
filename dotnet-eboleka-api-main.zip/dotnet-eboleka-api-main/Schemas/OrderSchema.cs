using eboleka.Models;
namespace eboleka.Schemas;

public class OrderSchema{

    public string uid {get; set;} = null!;
    public string productId {get; set;} = null!;
    public string serviceDate {get; set;} = null!;
    public int duration {get; set;} = 0;
    public string comments {get; set;} = null!;

    public string street {get; set;} = null!;
    public string suburb {get; set;} = null!;
    public string city {get; set;} = null!;
    public string code {get; set;} = null!;

    public double lat {get; set;} = 0.0;
    public double lon {get; set;} = 0.0;

    public PaymentMethod paymentMethod {get; set;} = 0;
    public DeliveryMethod deliveryMethod {get; set;} = 0;
}