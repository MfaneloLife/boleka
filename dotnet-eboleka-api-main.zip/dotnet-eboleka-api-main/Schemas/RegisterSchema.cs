
namespace eboleka.Schemas;

public class RegisterSchema{

    public string email {get; set;} = null!;
    public string name {get; set;} = null!;
    public string phone {get; set;} = null!;
    public string password {get; set;} = null!;
    public bool isBusiness {get; set;} = false;
}
