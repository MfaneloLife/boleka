namespace eboleka.Models;

public enum DeliveryMethod {
    DELIVERY, COLLECTION
}