namespace eboleka.Models;

public class SecurityAPI
{
    public string Url { get; set; } = null!;

    public string API_Token { get; set; } = null!;
}