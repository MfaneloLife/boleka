using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace eboleka.Models;

public class OTP{
    [BsonElement("pin")]
    private string pin;

    [BsonElement("time")]
    private string time;

    [BsonElement("date")]
    private string date;

    [BsonElement("attempts")]
    private int attempts;

    [BsonElement("requests")]
    private int requests;

    public OTP(string pin, string time, string date, int requests, int attempts) {
        this.pin = pin;
        this.time = time;
        this.date = date;
        this.requests = requests;
        this.attempts = attempts;
    }

    public int getRequests() {
        return requests;
    }

    public int getAttempts(){
        return attempts;
    }

    public string getPin() {
        return pin;
    }

    public string getTime() {
        return time;
    }

    public string getDate() {
        return date;
    }

    public void setDate(string date) {
        this.date = date;
    }

    public void setPin(string pin) {
        this.pin = pin;
    }

    public void setRequests(int requests) {
        this.requests = requests;
    }

    public void setAttempts(int attempts){
        this.attempts = attempts;
    }

    public void setTime(string time) {
        this.time = time;
    }
    

}