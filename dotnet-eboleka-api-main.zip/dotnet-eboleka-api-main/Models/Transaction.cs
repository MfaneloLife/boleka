using eboleka.Models;
using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Transaction{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

    [BsonElement("url")]
    private string url;

    [BsonElement("m_payment_id")]
    private string m_payment_id;

    [BsonElement("pf_payment_id")]
    private string pf_payment_id;

    [BsonElement("clientId")]
    private string clientId;

    [BsonElement("businessId")]
    private string businessId;

    [BsonElement("payment_status")]
    private string payment_status;

    [BsonElement("item_name")]
    private string item_name;

    [BsonElement("amount_gross")]
    private double amount_gross;

    [BsonElement("amount_net")]
    private double amount_net;

    [BsonElement("name_first")]
    private string name_first;

    [BsonElement("email_address")]
    private string email_address;

    [BsonElement("reason")]
    private string reason;

    [BsonElement("isvalid")]
    private bool isvalid;

    [BsonElement("date")]
    private string date;

    public Transaction(string m_payment_id, string pf_payment_id, string payment_status, string item_name, string name_first, string email_address, string url, double amount_gross, double amount_net, bool isvalid){
        uid = Security.getID();
        this.m_payment_id = m_payment_id;
        this.pf_payment_id = pf_payment_id;
        this.payment_status = payment_status;
        this.item_name = item_name;
        this.name_first = name_first;
        this.email_address = email_address;
        this.amount_gross = amount_gross;
        this.amount_net = amount_net;
        this.isvalid = isvalid;
        this.url = url;
        date = Time.getDayDateTime();
        reason = "";
        clientId = "";
        businessId = "";
    }

    public void setClientId(string id){
        clientId = id;
    }

    public void setBusinessId(string id){
        businessId = id;
    }

    public void setReason(string reason){
        this.reason = reason;
    }

    
    

} 
