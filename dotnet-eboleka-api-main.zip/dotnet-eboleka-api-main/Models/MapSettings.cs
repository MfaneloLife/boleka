namespace eboleka.Models;

public class MapSettings
{
    public string MapKey { get; set; } = null!;
}