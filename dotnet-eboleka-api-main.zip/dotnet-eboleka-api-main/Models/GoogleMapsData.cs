namespace eboleka.Models;

public class GoogleMapsData{
    public ResultData[] results { get; set; } = null!;
    public string status { get; set; } = null!;
}

public class ResultData{
    public AddressComponent[] address_components { get; set; } = null!;
    public string formatted_address { get; set; } = null!;
    public Geometry geometry { get; set; } = null!;
    public string place_id { get; set; } = null!;
    public string[] types { get; set; } = null!;
}

public class AddressComponent{
    public string long_name { get; set; } = null!;
    public string short_name { get; set; } = null!;
    public string[] types { get; set; } = null!;
}

public class Geometry{
    public Coordinates location { get; set; } = null!;
}

public class Coordinates{
    public double lat { get; set; } = 0.0;
    public double lng { get; set; } = 0.0;
}