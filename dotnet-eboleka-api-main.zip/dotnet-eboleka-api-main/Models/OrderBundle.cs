using eboleka.Dtos;
namespace eboleka.Models;

public class OrderBundle{

    public OrderDto order {get; set;} = null!;
    public ProductDto product {get; set;} = null!;
    

    public OrderBundle(OrderDto order, ProductDto product){
        this.order = order;
        this.product = product;
    }

}