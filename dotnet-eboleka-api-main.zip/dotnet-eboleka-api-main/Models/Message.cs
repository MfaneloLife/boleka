using eboleka.Models;
using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;


namespace eboleka.Models;

public class Message{

    [BsonElement("uid")]
    private string uid;

    [BsonElement("title")]
    private string title;

    [BsonElement("message")]
    private string message;

    [BsonElement("time")]
    private string time;

    [BsonElement("date")]
    private string date;

    [BsonElement("read")]
    private bool read;

    [BsonElement("colour")]
    private string colour;

    public Message(string title, string message, string colour){
        this.uid = Security.getID();
        this.title = title;
        this.message = message;
        this.date = Time.getDate();
        this.time = Time.getTime();
        this.colour = colour;
        read = false;
    }

    public string getUid(){
        return uid;
    }

    public string getTitle(){
        return title;
    }

    public string getMessage(){
        return message;
    }

    public string getTime(){
        return time;
    }

    public string getDate(){
        return date;
    }

    public string getColour(){
        return colour;
    }

    public bool getRead(){
        return read;
    }

    public void setRead(){
        this.read = true;
    }

}