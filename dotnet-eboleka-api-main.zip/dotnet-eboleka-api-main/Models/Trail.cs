using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Trail{

    [BsonElement("title")]
    private string title;

    [BsonElement("action")]
    private string action;

    [BsonElement("acter")]
    private string acter;

    [BsonElement("url")]
    private string url;

    [BsonElement("datetime")]
    private string datetime;

    public Trail(string title, string action, string acter, string url){
        this.title = title;
        this.action = action;
        this.acter = acter;
        this.url = url;
        datetime = Time.getDateTime();
    }

    public string getTitle(){
        return title;
    }

    public string getAction(){
        return action;
    }

    public string getActer(){
        return acter;
    }

    public string getUrl(){
        return url;
    }

    public string getDatetime(){
        return datetime;
    }

}