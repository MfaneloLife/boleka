namespace eboleka.Dtos;

public class Profile{

    public AccountDto account {get; set;} = null!;
    public List<ProductDto> products {get; set;} = null!;
   
    public Profile(AccountDto account, List<ProductDto> products){
        this.account = account;
        this.products = products;
    }

}