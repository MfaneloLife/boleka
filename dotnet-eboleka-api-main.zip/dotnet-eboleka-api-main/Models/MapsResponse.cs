namespace eboleka.Models;

public class MapsResponse{
    public bool valid {get; set;} = false;
    public string reason {get; set;} = null!;
    public List<MapsResponseData> places {get; set;} = null!;
}

public class MapsResponseData{
    public string id {get; set;} = null!;
    public string address {get; set;} = null!;
    public double lat {get; set;} = 0.0;
    public double lng {get; set;} = 0.0;
}