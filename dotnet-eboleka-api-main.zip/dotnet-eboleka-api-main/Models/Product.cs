using eboleka.Models;
using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Product{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

    [BsonElement("title")]
    private string title;

    [BsonElement("price")]
    private double price;

    [BsonElement("ownerId")]
    private string ownerId;

    [BsonElement("ownerName")]
    private string ownerName;

    [BsonElement("imageUrl")]
    private string imageUrl;

    [BsonElement("isVisible")]
    private bool isVisible;

    [BsonElement("description")]
    private string description;

    [BsonElement("createdDate")]
    private string createdDate;

    [BsonElement("paymentMethods")]
    private List<PaymentMethod> paymentMethods;

    [BsonElement("deliveryMethods")]
    private List<DeliveryMethod> deliveryMethods;

    public Product(string uid, string title, string ownerId, string ownerName, string imageUrl, string description, double price, bool isVisible, List<PaymentMethod> paymentMethods, List<DeliveryMethod> deliveryMethods){
        this.uid = uid;
        this.title = title;
        this.price = price;
        this.ownerId = ownerId;
        this.imageUrl = imageUrl;
        this.ownerName = ownerName;
        this.isVisible = isVisible;
        this.description = description;
        this.paymentMethods = paymentMethods;
        this.deliveryMethods = deliveryMethods;
        createdDate= Time.getDateTime();
    }

    public string getUid() {
        return uid;
    }

    public string getTitle() {
        return title;
    }

    public double getPrice() {
        return price;
    }

    public string getOwnerId() {
        return ownerId;
    }

    public string getImageUrl() {
        return imageUrl;
    }

    public bool getIsVisible() {
        return isVisible;
    }

    public string getDescription() {
        return description;
    }

    public List<PaymentMethod> getPaymentMethods() {
        return paymentMethods;
    }

    public string getCreatedDate() {
        return createdDate;
    }

    public List<DeliveryMethod> getDeliveryMethods() {
        return deliveryMethods;
    }

    public void setDeliveryMethods(List<DeliveryMethod> deliveryMethods) {
        this.deliveryMethods = deliveryMethods;
    }

    public string getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(string ownerName) {
        this.ownerName = ownerName;
    }

    public void setImageUrl(string imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setDescription(string description) {
        this.description = description;
    }

    public void setTitle(string title) {
        this.title = title;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setVisible(bool visible) {
        isVisible = visible;
    }

    public void setPaymentMethods(List<PaymentMethod> paymentMethods) {
        this.paymentMethods = paymentMethods;
    }




}