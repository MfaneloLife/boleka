namespace eboleka.Models;

public class JwtSettings
{
    public string Issuer { get; set; } = null!;

    public string Audience { get; set; } = null!;

    public string TokenKey { get; set; } = null!;

    public string RefreshTokenKey { get; set; } = null!;
}