using eboleka.Models;
using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Notification{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

    [BsonElement("messages")]
    private List<Message> messages;

    public Notification(string uid){
        this.uid = uid;
        messages = new List<Message>();
    }

    public string getUid(){
        return uid;
    }

    public List<Message> getMessages(){
        return messages;
    }

    public void addMessage(Message message){
        this.messages.Insert(0, message);

        if(messages.Count > 20){
            messages.RemoveAt(messages.Count - 1);
        }
    }

    public void markAsRead(string uid){
        foreach(Message message in messages){
            if(message.getUid().Equals(uid)){
                message.setRead();
                break;
            }
        }
    }

}