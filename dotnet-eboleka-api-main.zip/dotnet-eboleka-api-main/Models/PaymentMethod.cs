
namespace eboleka.Models;

public enum PaymentMethod{
    CASH, CARD
}
