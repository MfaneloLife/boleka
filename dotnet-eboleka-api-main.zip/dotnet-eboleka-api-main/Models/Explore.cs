using eboleka.Dtos;
namespace eboleka.Models;

public class Explore{

    public List<ProductDto> products {get; set;} = null!;
    public List<AccountDto> businesses {get; set;} = null!;

    public Explore(List<ProductDto> products, List<AccountDto> businesses){
        this.products = products;
        this.businesses = businesses;
    }

}