using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Trace{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

     [BsonElement("email")]
    private string email;

    [BsonElement("prev")]
    private List<Trail> prev;

    [BsonElement("curr")]
    private List<Trail> curr;

    public Trace(string uid, string email){
        this.uid = uid;
        this.email = email;
        prev = new List<Trail>();
        curr = new List<Trail>();
    }

    public void addTrail(Trail trail){
        curr.Insert(0, trail);
    }

    public List<Trail> getCurrTrails(){
        return curr;
    }

    public List<Trail> getPrevTrails(){
        return prev;
    }



}