using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class ArchiveOrder{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

    [BsonElement("order")]
    private Order order;

    [BsonElement("dateCompleted")]
    private string dateCompleted;

    [BsonElement("clientId")]
    private string clientId;

    [BsonElement("businessId")]
    private string businessId;


    public ArchiveOrder(Order order) {
        uid = order.getUid();
        clientId = order.getClientId();
        businessId = order.getBusinessId();
        this.order = order;
        dateCompleted = Time.getDateTime();
    }

    public string getUid() {
        return uid;
    }

    public string getClientId(){
        return clientId;
    }

    public string getBusinessId(){
        return businessId;
    }

    public string getDateCompleted(){
        return dateCompleted;
    }

    public Order getOrder(){
        return order;
    }

}