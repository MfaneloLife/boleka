using eboleka.Models;
using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Wallet{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

    [BsonElement("isBusiness")]
    private bool isBusiness;

    [BsonElement("cardIncome")]
    private double cardIncome;

    [BsonElement("cashIncome")]
    private double cashIncome;

    [BsonElement("lastPayout")]
    private string lastPayout;

    [BsonElement("completedOrders")]
    private int completedOrders;

    public Wallet(string uid, bool isBusiness){
        this.uid = uid;
        this.isBusiness = isBusiness;
        cardIncome = 0;
        cardIncome = 0;
        completedOrders = 0;
        lastPayout = "";
    }

    public string getUid(){
        return uid;
    }

    public bool getIsBusiness(){
        return isBusiness;
    }

    public double getCardIncome(){
        return cardIncome;
    }

    public double getCashIncome(){
        return cashIncome;
    }

    public int getOrdersCompleted(){
        return completedOrders;
    }

    public string getDate(){
        return lastPayout;
    }

}