using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace eboleka.Models;

public class Address{
    [BsonElement("street")]
    private string street;

    [BsonElement("suburb")]
    private string suburb;

    [BsonElement("city")]
    private string city;

    [BsonElement("code")]
    private string code;

    [BsonElement("alt")]
    private double alt;

    [BsonElement("lon")]
    private double lon;

    public Address(string street, string suburb, string city, string code, double alt, double lon){
        this.street = street;
        this.city = city;
        this.code = code;
        this.suburb = suburb;
        this.lon = lon;
        this.alt = alt;
    }

    public void update(string street, string suburb, string city, string code){
        this.street = street;
        this.city = city;
        this.code = code;
        this.suburb = suburb;
    }

    public string getStreet(){
        return street;
    }

    public string getSuburb(){
        return suburb;
    }

    public string getCity(){
        return city;
    }

    public string getCode(){
        return code;
    }

    public double getLat(){
        return alt;
    }

    public double getLng(){
        return lon;
    }

}