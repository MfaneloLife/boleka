using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Order{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

    [BsonElement("orderId")]
    private string orderId;

    [BsonElement("dateAdded")]
    private string dateAdded;

    [BsonElement("dateApproved")]
    private string dateApproved;

    [BsonElement("serviceDate")]
    private string serviceDate;

    [BsonElement("comments")]
    private string comments;

    [BsonElement("clientId")]
    private string clientId;

    [BsonElement("clientName")]
    private string clientName;

    [BsonElement("businessId")]
    private string businessId;

    [BsonElement("businessName")]
    private string businessName;

    [BsonElement("productId")]
    private string productId;

    [BsonElement("paid")]
    private bool paid;

    [BsonElement("approved")]
    private bool approved;

    [BsonElement("completed")]
    private bool completed;

    [BsonElement("price")]
    private double price;

    [BsonElement("duration")]
    private int duration;

    [BsonElement("paymentMethod")]
    private PaymentMethod paymentMethod;

    [BsonElement("deliveryMethod")]
    private DeliveryMethod deliveryMethod;

    [BsonElement("address")]
    private Address address;

    [BsonElement("qr")]
    private QR qr;

    public Order(){
        
    }

    public Order(string uid, string orderId, string serviceDate, string comments, string clientId, string clientName, string businessId, string businessName, string productId, double price, int duration, PaymentMethod paymentMethod, DeliveryMethod deliveryMethod, Address address) {
        this.uid = uid;
        this.orderId = orderId;
        this.serviceDate = serviceDate;
        this.comments = comments;
        this.clientId = clientId;
        this.clientName = clientName;
        this.businessId = businessId;
        this.businessName = businessName;
        this.productId = productId;
        this.paid = false;
        this.approved = false;
        this.completed = false;
        this.price = price;
        this.duration = duration;
        this.paymentMethod = paymentMethod;
        this.deliveryMethod = deliveryMethod;
        this.address = address;
        this.dateAdded = Time.getDate();
        this.qr = new QR(Security.getID(), Time.getTime(), Time.getDate());
    }

    public string getUid() {
        return uid;
    }

    public void setUid(string uid) {
        this.uid = uid;
    }

    public string getOrderId() {
        return orderId;
    }

    public void setOrderId(string orderId) {
        this.orderId = orderId;
    }

    public string getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(string dateAdded) {
        this.dateAdded = dateAdded;
    }

    public string getDateApproved() {
        return dateApproved;
    }

    public void setDateApproved(string dateApproved) {
        this.dateApproved = dateApproved;
    }

    public string getServiceDate() {
        return serviceDate;
    }

    public void setServiceDate(string serviceDate) {
        this.serviceDate = serviceDate;
    }

    public string getComments() {
        return comments;
    }

    public void setComments(string comments) {
        this.comments = comments;
    }

    public string getClientId() {
        return clientId;
    }

    public void setClientId(string clientId) {
        this.clientId = clientId;
    }

    public string getClientName() {
        return clientName;
    }

    public void setClientName(string clientName) {
        this.clientName = clientName;
    }

    public string getBusinessId() {
        return businessId;
    }

    public void setBusinessId(string businessId) {
        this.businessId = businessId;
    }

    public string getBusinessName() {
        return businessName;
    }

    public void setBusinessName(string businessName) {
        this.businessName = businessName;
    }

    public string getProductId() {
        return productId;
    }

    public void setProductId(string productId) {
        this.productId = productId;
    }

    public bool isPaid() {
        return paid;
    }

    public void setPaid(bool paid) {
        this.paid = paid;
    }

    public bool isApproved() {
        return approved;
    }

    public void setApproved(bool approved) {
        this.approved = approved;
    }

    public bool isCompleted() {
        return completed;
    }

    public void setCompleted(bool completed) {
        this.completed = completed;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public DeliveryMethod getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(DeliveryMethod deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public QR getQR(){
        return qr;
    }

}