using eboleka.Models;
using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Cart{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

    [BsonElement("productIds")]
    private List<string> productIds;

    public Cart(string uid){
        this.uid = uid;
        productIds = new List<string>();
    }

    public List<string> getProductIds(){
        return productIds;
    }

    public void addProductId(string productId){
        productIds.Add(productId);
    }

    public void removeProductId(string productId){
        productIds.Remove(productId);
    }

}