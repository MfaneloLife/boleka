using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace eboleka.Models;

public class QR{
    [BsonElement("code")]
    private string code;

    [BsonElement("time")]
    private string time;

    [BsonElement("date")]
    private string date;

    public QR(string code, string time, string date){
        this.code = code;
        this.time = time;
        this.date = date;
    }

    public string getCode(){
        return code;
    }

    public string getTime(){
        return time;
    }

    public string getDate(){
        return date;
    }

}