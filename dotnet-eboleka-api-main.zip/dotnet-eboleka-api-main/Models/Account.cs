using eboleka.Models;
using eboleka.Utils;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace eboleka.Models;

public class Account{

    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    private string Id;

    [BsonElement("uid")]
    private string uid;

    [BsonElement("email")]
    private string email;

    [BsonElement("name")]
    private string name;

    [BsonElement("password")]
    private string password;

    [BsonElement("phone")]
    private string phone;

    [BsonElement("deviceId")]
    private string deviceId;

    [BsonElement("imageUrl")]
    private string imageUrl;

    [BsonElement("about")]
    private string about;

    [BsonElement("isBusiness")]
    private bool isBusiness;

    [BsonElement("isSuspended")]
    private bool isSuspended;

    [BsonElement("createdDate")]
    private string createdDate;

    [BsonElement("address")]
    private Address address;

    [BsonElement("otp")]
    private OTP otp;

    public Account(string name, string email, string phoneNumber, string password, bool isBusiness){
        about = "";
        this.uid = Security.getID();
        this.name = name;
        this.email = email;
        this.password = Security.hashPassword(password);
        this.isBusiness = isBusiness;
        this.phone = phoneNumber;
        otp = new OTP("", "", "", 0, 0);
        createdDate = Time.getDayDateTime();
        address = new Address("", "", "", "", 0, 0);
        isSuspended = false;
        deviceId = "";
    }

    public string getUid(){
        return uid;
    }

    public string getDeviceId(){
        return deviceId;
    }

    public string getAbout(){
        return about;
    }

    public bool getIsSuspended(){
        return isSuspended;
    }

    public bool isPasswordCorrect(string password){
        return Security.isPasswordCorrect(this.password, password);
    }

    public string getEmail() {
        return email;
    }

    public string getName() {
        return name;
    }

    public string getPassword() {
        return password;
    }

    public string getPhoneNumber() {
        return phone;
    }

    public bool getIsBusiness() {
        return this.isBusiness;
    }

    public string getCreatedDate() {
        return createdDate;
    }

    public OTP getOtp() {
        return otp;
    }

    public void setOtp(OTP otp) {
        this.otp = otp;
    }

    public string getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(string imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Address getAddress(){
        return address;
    }

    public void setPhone(string phone){
        this.phone = phone;
    }

    public void setAbout(string about){
        this.about = about;
    }

    public void setAddress(Address address){
        this.address = address;
    }

} 
