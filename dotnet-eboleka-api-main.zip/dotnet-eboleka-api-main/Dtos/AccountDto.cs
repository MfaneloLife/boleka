using eboleka.Models;

namespace eboleka.Dtos;

public class AccountDto{

    public string uid {get; set;} = null!;
    public string name {get; set;} = null!;
    public string email {get; set;} = null!;
    public string about {get; set;} = null!;
    public string deviceId {get; set;} = null!;
    public string phone {get; set;} = null!;
    public string imageUrl {get; set;} = null!;
    public bool isBusiness {get; set;} = false;
    public bool isSuspended {get; set;} = false;
    public string createdDate {get; set;} = null!;

    public string street {get; set;} = null!;
    public string suburb {get; set;} = null!;
    public string city {get; set;} = null!;
    public string code {get; set;} = null!;

    public AccountDto(Account account){
        uid = account.getUid();
        name = account.getName();
        email = account.getEmail();
        about = account.getAbout();
        deviceId = account.getDeviceId();
        phone = account.getPhoneNumber();
        imageUrl = account.getImageUrl();
        isBusiness = account.getIsBusiness();
        isSuspended = account.getIsBusiness();
        createdDate = account.getCreatedDate();

        street = account.getAddress().getStreet();
        suburb = account.getAddress().getSuburb();
        city = account.getAddress().getCity();
        code = account.getAddress().getCode();
    }

    
}
