using eboleka.Models;

namespace eboleka.Dtos;

public class OrderDto{

    public string uid {get; set;} = null!;
    public string orderId {get; set;} = null!;
    public string dateAdded {get; set;} = null!;
    public string serviceDate {get; set;} = null!;
    public string comments {get; set;} = null!;
    public string clientId {get; set;} = null!;
    public string clientName {get; set;} = null!;
    public string businessId {get; set;} = null!;
    public string businessName {get; set;} = null!;
    public string productId {get; set;} = null!;

    public bool paid {get; set;} = false;
    public bool approved {get; set;} = false;
    public bool completed {get; set;} = false;

    public double price {get; set;} = 0;
    public int duration {get; set;} = 0;

    public string street {get; set;} = null!;
    public string suburb {get; set;} = null!;
    public string city {get; set;} = null!;
    public string code {get; set;} = null!;

    public double lat {get; set;} = 0;
    public double lng {get; set;} = 0;

    public string paymentMethod {get; set;} = null!;
    public string deliveryMethod {get; set;} = null!;

    public OrderDto(Order order){
        uid = order.getUid();
        orderId = order.getOrderId();
        dateAdded = order.getDateAdded();
        serviceDate = order.getServiceDate();
        comments = order.getComments();
        clientId = order.getClientId();
        clientName = order.getClientName();
        businessId = order.getBusinessId();
        businessName = order.getBusinessName();
        productId = order.getProductId();

        paid = order.isPaid();
        approved = order.isApproved();
        completed = order.isCompleted();

        price = order.getPrice();
        duration = order.getDuration();

        street = order.getAddress().getStreet();
        suburb = order.getAddress().getSuburb();
        city = order.getAddress().getCity();
        code = order.getAddress().getCode();

        lat = order.getAddress().getLat();
        lng = order.getAddress().getLng();


        paymentMethodToString(order.getPaymentMethod());
        deliveryMethodToString(order.getDeliveryMethod());

    }

    private void deliveryMethodToString(DeliveryMethod deliveryMethod){
        List<string> methods = new List<string>();

        if(deliveryMethod == 0){
            this.deliveryMethod = "DELIVERY";
        }else{
            this.deliveryMethod = "COLLECTION";
        }
    }

    private void paymentMethodToString(PaymentMethod paymentMethod){
        if(paymentMethod == 0){
            this.paymentMethod = "CASH";
        }else{
            this.paymentMethod = "CARD";
        }
    }

    
}
