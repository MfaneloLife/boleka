using eboleka.Models;

namespace eboleka.Dtos;

public class ProductDto{

    public string uid {get; set;} = null!;
    public string ownerId {get; set;} = null!;
    public string ownerName {get; set;} = null!;
    public string title {get; set;} = null!;
    public string imageUrl {get; set;} = null!;
    public string description {get; set;} = null!;
    public double price {get; set;} = 0.0;
    public bool isVisible {get; set;} = false;
    public List<string> deliveryMethods {get; set;} = null!;
    public List<string> paymentMethods {get; set;} = null!;

    public ProductDto(Product product){
        uid = product.getUid();
        ownerId = product.getOwnerId();
        ownerName = product.getOwnerName();
        title = product.getTitle();
        imageUrl = product.getImageUrl();
        description = product.getDescription();
        price = product.getPrice();
        isVisible = product.getIsVisible();
        paymentMethodToString(product.getPaymentMethods());
        deliveryMethodToString(product.getDeliveryMethods());
    }

    private void deliveryMethodToString(List<DeliveryMethod> deliveryMethods){
        List<string> methods = new List<string>();

        foreach(DeliveryMethod method in deliveryMethods){
            if(method == 0){
                methods.Add("DELIVERY");
            }else{
                methods.Add("COLLECTION");
            }
        }

        this.deliveryMethods = methods;
    }

    private void paymentMethodToString(List<PaymentMethod> paymentMethods){
        List<string> methods = new List<string>();

        foreach(PaymentMethod method in paymentMethods){
            if(method == 0){
                methods.Add("CASH");
            }else{
                methods.Add("CARD");
            }
        }

        this.paymentMethods = methods;
    }
}
