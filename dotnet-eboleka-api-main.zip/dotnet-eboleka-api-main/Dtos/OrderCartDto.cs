using eboleka.Models;

namespace eboleka.Dtos;

public class OrderCartDto{

    public List<ProductDto> cart {get; set;} = null!;
    public List<OrderBundle> order {get; set;} = null!;

}