using eboleka.Models;

namespace eboleka.Dtos;

public class NotificationDto{

    public string uid{get; set;} = null!;
    public string title{get; set;} = null!;
    public string message{get; set;} = null!;
    public string time{get; set;} = null!;
    public string date {get; set;} = null!;
    public bool read {get; set;} = false;
    public string colour {get; set;} = null!;

    public NotificationDto(Message message){
        uid = message.getUid();
        title = message.getTitle();
        this.message = message.getMessage();
        time = message.getTime();
        date = message.getDate();
        colour = message.getColour();
        read = message.getRead();
    }

}