using eboleka.Models;

namespace eboleka.Dtos;

public class IdentifierDto{

    public string uid {get; set;} = null!;
    public string orderId {get; set;} = null!;
    public double price {get; set;} = 0;

    public IdentifierDto(string uid, string orderId, double price){
        this.uid = uid;
        this.orderId = orderId;
        this.price = price;
    }

}