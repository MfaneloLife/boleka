using eboleka.Dtos;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using MongoDB.Bson;

namespace eboleka.Services;

public class ProductService{

    private readonly IMongoCollection<Product> productCollection;
    

    public ProductService(IOptions<DatabaseSettings> databaseSettings){
        
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        productCollection = mongoDatabase.GetCollection<Product>("product");
    }

    public async Task addProduct(Product product){
        await productCollection.InsertOneAsync(product);
    }

    public async Task deleteProductById(string id){
        var filter = Builders<Product>.Filter.Eq("uid", id);
        await productCollection.DeleteOneAsync(filter);
    }

    public async Task<List<Product>?> getAllProducts(){
        var filter = Builders<Product>.Filter.Eq("isVisible", true);
        return await productCollection.Find(filter).ToListAsync();
    }

    public async Task<Product?> getProductById(string id){
        var filter = Builders<Product>.Filter.Eq("uid", id);
        return await productCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<List<Product>?> getProductsByOwnerId(string id){
        var filter = Builders<Product>.Filter.Eq("ownerId", id);
        return await productCollection.Find(filter).ToListAsync();
    }  

    public List<ProductDto> getProducts(List<Product> products){
        List<ProductDto> productDtos = new List<ProductDto>();

        foreach(Product product in products){
            productDtos.Add(new ProductDto(product));
        }

        return productDtos;
    }

    public async Task<List<Product>?> searchProduct(string name){
        var filter = Builders<Product>.Filter.Regex("title", new BsonRegularExpression(name, "i"));

        return await productCollection.Find(filter).ToListAsync();
    }


    public async Task hideProduct(Product product, TraceService traceService){
        var filter = Builders<Product>.Filter.Eq("uid", product.getUid());
        var update = Builders<Product>.Update.Set("isVisible", false);

        if(product.getIsVisible()){
            await productCollection.UpdateOneAsync(filter, update);
            Trail trail = new Trail("Hide service", "User tried to deleted servive, but it the service had orders: " + product.getTitle(), "eboleka", "/product");
            await traceService.addTrail(product.getOwnerId(), "", trail);
        }
    }

    public async Task updateProduct(Product product, ProductSchema schema){
        var filter = Builders<Product>.Filter.Eq("uid", product.getUid());
        
        var updateTitle = Builders<Product>.Update.Set("title", schema.title);
        var updatePrice = Builders<Product>.Update.Set("price", schema.price);
        var updateImageUrl = Builders<Product>.Update.Set("imageUrl", schema.imageUrl);
        var updateIsVisible = Builders<Product>.Update.Set("isVisible", schema.isVisible);
        var updateDescription = Builders<Product>.Update.Set("description", schema.description);
        var updatePaymentMethods = Builders<Product>.Update.Set("paymentMethods", schema.paymentMethods);
        var updateDeliveryMethods = Builders<Product>.Update.Set("deliveryMethods", schema.deliveryMethods);

        if(!product.getTitle().Equals(schema.title)){
            await productCollection.UpdateOneAsync(filter, updateTitle);
        }

        if(product.getPrice() != schema.price){
            await productCollection.UpdateOneAsync(filter, updatePrice);
        }

        if(!product.getImageUrl().Equals(schema.imageUrl)){
            await productCollection.UpdateOneAsync(filter, updateImageUrl);
        }

        if(product.getIsVisible() != schema.isVisible){
            await productCollection.UpdateOneAsync(filter, updateIsVisible);
        }

        if(!product.getDescription().Equals(schema.description)){
            await productCollection.UpdateOneAsync(filter, updateDescription);
        }
        
        await productCollection.UpdateOneAsync(filter, updatePaymentMethods);
        await productCollection.UpdateOneAsync(filter, updateDeliveryMethods);
    }



}