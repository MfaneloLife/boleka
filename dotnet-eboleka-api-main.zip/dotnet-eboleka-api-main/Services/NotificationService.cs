using System.Text.RegularExpressions;
using eboleka.Models;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class NotificationService{

    private readonly IMongoCollection<Notification> notificationCollection;
    

    public NotificationService(IOptions<DatabaseSettings> databaseSettings){
    
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        notificationCollection = mongoDatabase.GetCollection<Notification>("notification");
    }

    public async Task<Notification?> getNotification(string uid){
        var filter = Builders<Notification>.Filter.Eq("uid", uid);
        return await notificationCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task addNotification(Notification notification){
        await notificationCollection.InsertOneAsync(notification);
    }

    public async Task updateNotification(string uid, List<Message> messages){
        var filter = Builders<Notification>.Filter.Eq("uid", uid);
        var update = Builders<Notification>.Update.Set("messages", messages);
        await notificationCollection.UpdateOneAsync(filter, update);
    } 

}