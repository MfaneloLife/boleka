using eboleka.Models;
using Microsoft.Extensions.Options;
using System.Net;
using Newtonsoft.Json;


namespace eboleka.Services;

public class MapService{

    private string MapKey;

    public MapService(IOptions<MapSettings> settings){
        MapKey = settings.Value.MapKey;
    }

    public async Task<MapsResponse> geocoding(string street, string suburb, string city, string code){
        MapsResponse mapsResponse = new MapsResponse();
        mapsResponse.valid = false;

        string address = street.Trim().Replace(" ", "+") + "+," + suburb.Trim().Replace(" ", "+") + "+," + city.Trim().Replace(" ", "+") + "+," + code.Trim().Replace(" ", "+");

        Uri uri = new Uri("https://maps.googleapis.com/maps/api/geocode/json?address=" + address + "&key=" + MapKey);
        HttpClient client = new HttpClient();
        HttpResponseMessage response = await client.GetAsync(uri);

        if (response.StatusCode == HttpStatusCode.OK){
            string content = await response.Content.ReadAsStringAsync();
            var mapsData = JsonConvert.DeserializeObject<GoogleMapsData>(content);

            List<MapsResponseData> mapsResponseDatas = new List<MapsResponseData>();

            if(mapsData!.status.Equals("OK")){
                foreach(ResultData data in mapsData.results){
                    MapsResponseData mapsResponseData = new MapsResponseData();
                    mapsResponseData.id = data.place_id;
                    mapsResponseData.address = data.formatted_address;
                    mapsResponseData.lat = data.geometry.location.lat;
                    mapsResponseData.lng = data.geometry.location.lng;

                    mapsResponseDatas.Add(mapsResponseData);
                }
                mapsResponse.valid = true;
                mapsResponse.places = mapsResponseDatas;
            }
        }

        return mapsResponse;
    }

}