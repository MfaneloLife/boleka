using eboleka.Models;
using Microsoft.Extensions.Options;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace eboleka.Services;

public class JwtService{

    private string Issuer;

    private string Audience;

    private string TokenKey;

    private string RefreshTokenKey;

    public JwtService(IOptions<JwtSettings> settings){
        Issuer = settings.Value.Issuer;
        Audience = settings.Value.Audience;
        TokenKey = settings.Value.TokenKey;
        RefreshTokenKey = settings.Value.RefreshTokenKey;
    }

    public string generateToken(string uid, string email, string name, bool isBusiness){
        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.UTF8.GetBytes(TokenKey);

        var claims = new List<Claim>{
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new(JwtRegisteredClaimNames.Sub, email),
            new(JwtRegisteredClaimNames.Email, email),
            new("Uid", uid),
            new("Name", name),
            new("IsBusiness", isBusiness.ToString())
        };

        var tokenDescriptor = new SecurityTokenDescriptor{
            Subject = new ClaimsIdentity(claims),
            Expires = DateTime.UtcNow.AddSeconds(5400),
            Issuer = this.Issuer,
            Audience = this.Audience,
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key),SecurityAlgorithms.HmacSha512Signature)
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);
        
        return tokenHandler.WriteToken(token);
    }

    public string getUid(string token){
        var handler = new JwtSecurityTokenHandler();
        var jwtToken = handler.ReadJwtToken(token);

        var payload = jwtToken.Payload;

        var userClaims = payload.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        return claimValues[3];
    }

    public string refreshToken(string token){
        var handler = new JwtSecurityTokenHandler();
        var jwtToken = handler.ReadJwtToken(token);

        var payload = jwtToken.Payload;

        var userClaims = payload.Claims;
        var claimValues = userClaims.Select(claim => claim.Value).ToList();

        string uid = claimValues[3];
        string name = claimValues[4];
        string email = claimValues[2];
        bool isBusiness = bool.Parse(claimValues[5]);

        return generateToken(uid, email, name, isBusiness);
    }

    public bool isTokenValid(string token){
        var tokenHandler = new JwtSecurityTokenHandler();
        var validationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(TokenKey)),
            ValidateLifetime = false,
            ValidateIssuer = true, // Set to true if you want to validate the issuer
            ValidateAudience = true, // Set to true if you want to validate the audience
            ClockSkew = TimeSpan.Zero, // Adjust the allowed clock skew if needed
            ValidIssuer = this.Issuer,
            ValidAudience = this.Audience
        };

        try{
            SecurityToken validatedToken;
            var principal = tokenHandler.ValidateToken(token, validationParameters, out validatedToken);
            return true;
        }
        catch (Exception){
            return false;
        }
    }


}