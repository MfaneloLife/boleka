using System.Net.Http.Headers;
using eboleka.Models;
using Microsoft.Extensions.Options;

namespace eboleka.Services;

public class EmailService{

    private string Url;
    private string API_Token;
    private HttpClient client;

    public EmailService(IOptions<SecurityAPI> settings){
        Url = settings.Value.Url + "/mail";
        client = new HttpClient();
        API_Token = settings.Value.API_Token;
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", API_Token);
    }

    public async Task sendWelcomeMessage(Dictionary<string, string> data){
        HttpResponseMessage response = await client.PostAsJsonAsync(Url + "/new-account", data);
    }

    public async Task sendOTP(Dictionary<string, string> data){
        HttpResponseMessage response = await client.PostAsJsonAsync(Url + "/otp", data);
    }

    public async Task handleOrderEmails(Order order, ProductService productService, AccountService accountService, string route){
        var productQuery = await productService.getProductById(order.getProductId());

        if(productQuery == null){
            Product _product = new Product("", "", "", "", "", "", 0, false, new List<PaymentMethod>(), new List<DeliveryMethod>());
            productQuery = _product;
        }

        Product product = productQuery;
        Dictionary<string, string> data = new Dictionary<string, string>();

        var accountQuery = await accountService.findAccountById(order.getClientId());

        if(accountQuery != null){
        Account account = accountQuery;

        data.Add("email", account.getEmail());
        data.Add("name", account.getName());
        data.Add("id", order.getOrderId());
        data.Add("imageUrl", product.getImageUrl());
        data.Add("price", order.getPrice().ToString());
        data.Add("title", product.getTitle());
        data.Add("date", order.getServiceDate());
        data.Add("isCardPayment", (order.getPaymentMethod() == 0).ToString().ToLower());

        HttpResponseMessage response = await client.PostAsJsonAsync(Url + route, data);
        }
    }
    
}