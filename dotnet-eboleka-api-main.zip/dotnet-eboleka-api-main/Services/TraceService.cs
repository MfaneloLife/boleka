using eboleka.Models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class TraceService{

    private readonly IMongoCollection<Trace> traceCollection;
    

    public TraceService(IOptions<DatabaseSettings> databaseSettings){
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        traceCollection = mongoDatabase.GetCollection<Trace>("trace");
    }

    private async Task addTrace(Trace trace){
        await traceCollection.InsertOneAsync(trace);
    }

    public async Task<Trace?> getTraceById(string id){
        var filter = Builders<Trace>.Filter.Eq("uid", id);
        return await traceCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<Trace?> getTraceByEmail(string email){
        var filter = Builders<Trace>.Filter.Eq("email", email);
        return await traceCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task addTrail(string uid, string email, Trail trail){
        var queryTrace = await getTraceById(uid);

        if(queryTrace == null){
            Trace _trace = new Trace(uid, email);
            await addTrace(_trace);
            queryTrace = _trace;
        }

        Trace trace = queryTrace;
        trace.addTrail(trail);

        var filter = Builders<Trace>.Filter.Eq("uid", uid);
        var update = Builders<Trace>.Update.Set("curr", trace.getCurrTrails());
        await traceCollection.UpdateOneAsync(filter, update);

    }

}