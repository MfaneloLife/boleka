using eboleka.Dtos;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class CartService{

    private readonly IMongoCollection<Cart> cartCollection;
    

    public CartService(IOptions<DatabaseSettings> databaseSettings){
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        cartCollection = mongoDatabase.GetCollection<Cart>("cart");
    }

    public async Task addCart(Cart cart){
        await cartCollection.InsertOneAsync(cart);
    }

    public async Task<Cart?> getCart(string id){
        var filter = Builders<Cart>.Filter.Eq("uid", id);
        return await cartCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task updateCart(string id, List<string> productIds){
        var filter = Builders<Cart>.Filter.Eq("uid", id);
        var update = Builders<Cart>.Update.Set("productIds", productIds);
        await cartCollection.UpdateOneAsync(filter, update);
    }

    public async Task removeCart(string id, string productId){
        var cartQuery = await getCart(id);

        if(cartQuery != null){
            Cart cart = cartQuery;
            cart.removeProductId(productId);
            await updateCart(id, cart.getProductIds());
        }
    }

    public async Task<List<ProductDto>> getProducts(string uid, List<string> productIds, ProductService productService){
        List<ProductDto> products = new List<ProductDto>();

        foreach(string id in productIds){
            var productQuery = await productService.getProductById(id);

            if(productQuery != null){
                Product product = productQuery;
                if(product.getIsVisible()){
                    products.Add(new ProductDto(product));
                }else{
                    await removeCart(uid, id);
                }
            }else{
                await removeCart(uid, id);
            }
        }

        return products;
    }

    public bool shouldAdd(string productId, List<string> productIds){
        if(productIds.Count > 12){
            return false;
        }

        foreach(string id in productIds){
            if(id.Equals(productId)){
                return false;
            }
        }

        return true;
    }

}