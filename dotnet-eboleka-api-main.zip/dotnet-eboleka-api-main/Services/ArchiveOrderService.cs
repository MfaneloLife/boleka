using eboleka.Models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class ArchiveOrderService{

    private readonly IMongoCollection<ArchiveOrder> collection;
    

    public ArchiveOrderService(IOptions<DatabaseSettings> databaseSettings){
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        collection = mongoDatabase.GetCollection<ArchiveOrder>("archived_order");
    }

    public async Task archive(ArchiveOrder order){
        await collection.InsertOneAsync(order);
    }

}