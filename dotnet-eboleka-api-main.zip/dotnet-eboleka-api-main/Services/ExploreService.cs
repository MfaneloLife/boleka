using eboleka.Dtos;
using eboleka.Models;
using eboleka.Schemas;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class ExploreService{

    private readonly IMongoCollection<Product> productCollection;
    private readonly IMongoCollection<Account> accountCollection;

    public ExploreService(IOptions<DatabaseSettings> databaseSettings){
        
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        productCollection = mongoDatabase.GetCollection<Product>("product");
        accountCollection = mongoDatabase.GetCollection<Account>("account");
    }

    public List<ProductDto> getProducts(List<string> viewedProducts, List<Product> allProducts){
        int added = 0;

        shuffleList(allProducts);
        
        foreach(string viewed in viewedProducts){
            allProducts.RemoveAll(product => product.getUid().Equals(viewed));
        }

        List<ProductDto> products = new List<ProductDto>();

        foreach(Product product in allProducts){
            products.Add(new ProductDto(product));
            added++;
            if(added >=  20){
                break;
            }
        }

        return products;
    }

    public List<AccountDto> getBusinesses(List<string> viewedAccounts, List<Account> allAccounts){
        int added = 0;

        shuffleList(allAccounts);
        
        foreach(string viewed in viewedAccounts){
            allAccounts.RemoveAll(account => account.getUid().Equals(viewed));
        }

        List<AccountDto> accounts = new ();

        foreach(Account account in allAccounts){
            //TODO: add bu's with data...
            accounts.Add(new AccountDto(account));
            added = added + 1;
            if(added >=  20){
                break;
            }
        }

        return accounts;
    }

    private void shuffleList<T>(List<T> list){
        Random random = new Random();
        int n = list.Count;
        while (n > 1){
            n--;
            int k = random.Next(n + 1);
            T value = list[k];
            list[k] = list[n];
            list[n] = value;
        }
    }

}