using eboleka.Models;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

public class DailyTaskService : IHostedService, IDisposable{

    private Timer _timer;
    private readonly IMongoCollection<Order> orderCollection;

    public DailyTaskService(IOptions<DatabaseSettings> databaseSettings){
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        orderCollection = mongoDatabase.GetCollection<Order>("order");
    }


    public Task StartAsync(CancellationToken cancellationToken){
        ScheduleTask();
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken){
        _timer?.Change(Timeout.Infinite, 0);
        return Task.CompletedTask;
    }

    public void Dispose(){
        _timer?.Dispose();
    }

    private void ScheduleTask(){
        DateTime currentTime = DateTime.Now;
        DateTime scheduledTime = new DateTime(currentTime.Year, currentTime.Month, currentTime.Day, 1, 0, 0);

        if (currentTime > scheduledTime){
            scheduledTime = scheduledTime.AddDays(1);
        }

        TimeSpan timeUntilScheduled = scheduledTime - currentTime;
        int dueTime = (int)timeUntilScheduled.TotalMilliseconds;

        _timer = new Timer(ExecuteTask, null, dueTime, Timeout.Infinite);
    }

    private async void ExecuteTask(object state){
        
        Console.WriteLine("Executing the daily task...");

        var ordersQuery = await getAllOrders();

        if(ordersQuery != null){
            cleanup(ordersQuery);
        }
        
        ScheduleTask();
    }

    private async void cleanup(List<Order> orders){
        foreach(Order order in orders){
            string dateNow = Time.convertDateFull(Time.getDate());
            string dateAdded = Time.convertDateFull(order.getDateAdded());

            Console.WriteLine(order.getOrderId());

            if(order.isCompleted()){
                await deleteOrderById(order.getUid());
                continue;
            }

            if(!order.isApproved()){
                if(remove(dateNow, dateAdded)){
                    await deleteOrderById(order.getUid());
                    continue;
                }
            }

            if(order.getPaymentMethod().Equals(PaymentMethod.CARD) && !order.isPaid()){
                if(remove(dateNow, dateAdded)){
                    await deleteOrderById(order.getUid());
                    continue;
                }
            }
        }

        Console.WriteLine("Done");
    }

    private async Task<List<Order>?> getAllOrders(){
        var filter = Builders<Order>.Filter.Empty;
        return await orderCollection.Find(filter).ToListAsync();
    }

    private async Task deleteOrderById(string id){
        var filter = Builders<Order>.Filter.Eq("uid", id);
        await orderCollection.DeleteOneAsync(filter);
    }

    private bool remove(string dateNow, string dateAdded){
        int dayNow = Int32.Parse(dateNow.Split("/")[0]);
        int monthNow = Int32.Parse(dateNow.Split("/")[1]);

        int dayAdded = Int32.Parse(dateAdded.Split("/")[0]);
        int monthAdded = Int32.Parse(dateAdded.Split("/")[1]);

        if(monthAdded == monthNow){
            return Math.Abs(dayNow - dayAdded) > 3;
        }else{
            return dayNow > 2;
        }
    }
}
