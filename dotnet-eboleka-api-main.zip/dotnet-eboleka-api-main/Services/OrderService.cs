using eboleka.Models;
using eboleka.Dtos;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class OrderService{

    private readonly IMongoCollection<Order> orderCollection;
    

    public OrderService(IOptions<DatabaseSettings> databaseSettings){
        
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        orderCollection = mongoDatabase.GetCollection<Order>("order");
    }

    public async Task addOrder(Order order){
        await orderCollection.InsertOneAsync(order);
    }

    public async Task<Order?> getOrderById(string id){
        var filter = Builders<Order>.Filter.Eq("uid", id);
        return await orderCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<List<Order>?> getOrdersByClientId(string id){
        var filter = Builders<Order>.Filter.Eq("clientId", id);
        return await orderCollection.Find(filter).ToListAsync();
    }

    public async Task<List<Order>?> getOrdersByBusinessId(string id){
        var filter = Builders<Order>.Filter.Eq("businessId", id);
        return await orderCollection.Find(filter).ToListAsync();
    }

    public async Task<List<Order>?> getOrdersByProductId(string id){
        var filter = Builders<Order>.Filter.Eq("productId", id);
        return await orderCollection.Find(filter).ToListAsync();
    }

    public async Task approveOrder(string id){
        var filter = Builders<Order>.Filter.Eq("uid", id);
        var update = Builders<Order>.Update.Set("approved", true);
        await orderCollection.UpdateOneAsync(filter, update);
    }

    public async Task payOrder(string id){
        var filter = Builders<Order>.Filter.Eq("uid", id);
        var update = Builders<Order>.Update.Set("paid", true);
        await orderCollection.UpdateOneAsync(filter, update);
    }

    public async Task completeOrder(string id){
        var filter = Builders<Order>.Filter.Eq("uid", id);
        var update = Builders<Order>.Update.Set("completed", true);
        await orderCollection.UpdateOneAsync(filter, update);
    }

    public async Task deleteOrderById(string id){
        var filter = Builders<Order>.Filter.Eq("uid", id);
        await orderCollection.DeleteOneAsync(filter);
    }

    public List<Order> filterOrders(List<Order> orders, bool filter){
        List<Order> filteredOrders = new List<Order>();

        foreach(Order order in orders){
            if(order.isApproved() == filter){
                filteredOrders.Add(order);
            }
        }

        return filteredOrders;
    }

    public async Task<List<OrderBundle>?> getOrderBundles(List<Order> orders, ProductService productService){
        List<OrderBundle> orderBundles = new List<OrderBundle>();

        foreach(Order order in orders){
            var productQuery = await productService.getProductById(order.getProductId());
            if(productQuery != null){
                orderBundles.Add(new OrderBundle(new OrderDto(order), new ProductDto(productQuery)));
            }
        }

        return orderBundles;
    }

    public List<OrderBundle> sortOrders(List<OrderBundle> orders){
        List<OrderBundle> list = new List<OrderBundle>();

        foreach(OrderBundle order in orders){
            if(list.Count == 0){
                list.Add(order);
            }else{
                bool added = false;
                for(int i = 0; i < list.Count; i++){
                    if(addOrder(order.order.serviceDate, list[i].order.serviceDate)){
                        added = true;
                        list.Insert(i, order);
                        break;
                    }
                }

                if(!added){
                    list.Add(order);
                }
            }
        }

        return list;
    }

    public async Task updateQR(string id, QR qr){
        var filter = Builders<Order>.Filter.Eq("uid", id);
        var update = Builders<Order>.Update.Set("qr", qr);
        await orderCollection.UpdateOneAsync(filter, update);
    }

    public bool isCodeValid(QR qr, string key){
        string time = Time.getTime();
        string date = Time.getDate();

        if(!qr.getDate().Equals(date)){
            return false;
        }

        int generatedTime = (Int32.Parse(qr.getTime().Split(":")[0]) * 60) + Int32.Parse(qr.getTime().Split(":")[1]);
        int now = (Int32.Parse(time.Split(":")[0]) * 60) + Int32.Parse(time.Split(":")[1]);

        if(Math.Abs(now - generatedTime) > 180){
            return false;
        }

        if(qr.getCode().Equals(key)){
            return true;
        }

        return false;
    }

    private bool addOrder(string order, string curr){
        string[] orderSplit = order.Split(" ");
        string[] currSplit = curr.Split(" ");

        string orderTime = orderSplit[3];
        string currTime = currSplit[3];

        string currDate = Time.convertDate(currSplit[0] + " " + currSplit[1] + " " + currSplit[2]);
        string orderDate = Time.convertDate(orderSplit[0] + " " + orderSplit[1] + " " + orderSplit[2]);

        if(currDate.Equals(orderDate)){
            string[] _order = orderTime.Split(":");
            string[] _curr = currTime.Split(":");

            if(Int32.Parse(_order[0]) <= Int32.Parse(_curr[0]) && Int32.Parse(_order[1]) <= Int32.Parse(_curr[1])){
                return true;
            }

            return false;
        }else{
            string[] _order = orderDate.Split("/");
            string[] _curr = currDate.Split("/");

            if(Int32.Parse(_order[0]) <= Int32.Parse(_curr[0]) && Int32.Parse(_order[1]) <= Int32.Parse(_curr[1]) && Int32.Parse(_order[2]) <= Int32.Parse(_curr[2])){
                return true;
            }

            return false;
        }
    }

    public string generateOrderId(PaymentMethod paymentMethod, DeliveryMethod deliveryMethod){
        Random rand = new Random();  

        DateTime currentDateTime = DateTime.Now;
        string formattedDate = currentDateTime.ToString("yyMMdd");

        string orderId = formattedDate;

        string[] numbers = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
        string[] alphabets = {"A", "B", "C", "D", "E","F", "G","H", "I","J", "K","L", "M","N", "O","P", "Q","R", "S","T", "U","V", "W","X", "Y","Z"};

        for (int i = 0; i < 5; i++){    
            orderId += numbers[rand.Next(0, numbers.Length)];      
        } 

        if(paymentMethod == 0){
            orderId += "C";
        }else{
            orderId += "A";
        }

        if(deliveryMethod == 0){
            orderId += "D";
        }else{
            orderId += "C";
        }

        for (int i = 0; i < 2; i++){    
            orderId += alphabets[rand.Next(0, alphabets.Length)];      
        }

        return orderId;
    }

} 