using System.Text.RegularExpressions;
using eboleka.Models;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class TransactionService{

    private readonly IMongoCollection<Transaction> transactionCollection;
    

    public TransactionService(IOptions<DatabaseSettings> databaseSettings){
        
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        transactionCollection = mongoDatabase.GetCollection<Transaction>("transaction");
    }

    public async Task recordTransaction(Transaction transaction){
        await transactionCollection.InsertOneAsync(transaction);
    }

}