using System.Text.RegularExpressions;
using eboleka.Models;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class AccountService{

    private readonly IMongoCollection<Account> accountCollection;
    

    public AccountService(IOptions<DatabaseSettings> databaseSettings){
        
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        accountCollection = mongoDatabase.GetCollection<Account>("account");
    }

    public bool isDataValid(string name, string email, string password, string phone){
        bool valid = true;

        if(name.Length < 1){
            valid = false;
        }

        if(password.Length < 7){
            valid = false;
        }

        Regex regex = new Regex(@"^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$");
        Match match = regex.Match(email);
        if(!match.Success){
            valid = false;
        }

        Regex phoneRegex = new Regex(@"^0[6|7|8][0-9]{8}$");
        Match phoneMatch = phoneRegex.Match(phone);
        if(!phoneMatch.Success){
            valid = false;
        }

        return valid;
    }

    public async Task createAccount(Account account){
        await accountCollection.InsertOneAsync(account);
    }

    public async Task<bool> accountExistsByEmail(string email){
        var filter = Builders<Account>.Filter.Eq("email", email);
        if(await accountCollection.Find(filter).FirstOrDefaultAsync() != null){
            return true;
        }
        return false;
    }

    public async Task<Account?> findAccountByEmail(string email){
        var filter = Builders<Account>.Filter.Eq("email", email);
        return await accountCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<Account?> findAccountById(string id){
        var filter = Builders<Account>.Filter.Eq("uid", id);
        return await accountCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<List<Account>?> getAllBusinesses(){
        var filter = Builders<Account>.Filter.Eq("isBusiness", true);
        return await accountCollection.Find(filter).ToListAsync();
    }

    public async Task updateProfile(string id, string imageUrl, string about, string phone, Address address){
        var filter = Builders<Account>.Filter.Eq("uid", id);

        var updateImageUrl = Builders<Account>.Update.Set("imageUrl", imageUrl);
        var updateAbout = Builders<Account>.Update.Set("about", about);
        var updatePhone = Builders<Account>.Update.Set("phone", phone);
        var updateAddress = Builders<Account>.Update.Set("address", address);

        await accountCollection.UpdateOneAsync(filter, updateImageUrl);
        await accountCollection.UpdateOneAsync(filter, updateAbout);
        await accountCollection.UpdateOneAsync(filter, updatePhone);
        await accountCollection.UpdateOneAsync(filter, updateAddress);
    }

    private bool shouldSendOTP(String now, String today, String requestTime, String requestDate, int requests){
        bool flag = true;
        if(!requestDate.Equals("") && !requestTime.Equals("") && requestDate.Equals(today)){
            int nowMinutes = (Int32.Parse(now.Split(":")[0]) * 60) + Int32.Parse(now.Split(":")[1]);
            int requestMinutes = (Int32.Parse(requestTime.Split(":")[0]) * 60) + Int32.Parse(requestTime.Split(":")[1]);

            //If less than 2 minutes should not send
            if(Math.Abs(nowMinutes - requestMinutes) < 2 || requests >= 10){
                flag = false;
            }
        }

        return flag;
    }

    public async Task handleOTP(Account account, EmailService emailService){
        Dictionary<string, string> data = new Dictionary<string, string>();
        string now = Time.getTime();
        string today = Time.getDate();

        string requestTime = account.getOtp().getTime();
        string requestDate = account.getOtp().getDate();

        string pin = account.getOtp().getPin();
        string newPin = Security.generateOTP(8);

        int requests = account.getOtp().getRequests() + 1;

        if(!today.Equals(requestDate)){
            requests = 1;
        }

        OTP newOTP = new OTP(newPin, now, today, requests, 0);

        if(pin.Equals("") || shouldSendOTP(now, today, requestTime, requestDate, requests - 1)){
            data.Add("email", account.getEmail());
            data.Add("name", account.getName());
            data.Add("otp", newPin);
            var filter = Builders<Account>.Filter.Eq("email", account.getEmail());
            var updateOTP = Builders<Account>.Update.Set("otp", newOTP);
            await accountCollection.UpdateOneAsync(filter, updateOTP);
            await emailService.sendOTP(data);
        }

    }

    public async Task handleIncorrectPassword(Account account){
        OTP otp = account.getOtp();
        int attempts = otp.getAttempts();
        otp.setAttempts(attempts + 1);
        var filter = Builders<Account>.Filter.Eq("email", account.getEmail());
        var updateOTP = Builders<Account>.Update.Set("otp", otp);
        await accountCollection.UpdateOneAsync(filter, updateOTP);
    }

    public async Task updateDeviceId(string id, string deviceId){
        var filter = Builders<Account>.Filter.Eq("uid", id);
        var update = Builders<Account>.Update.Set("deviceId", Security.hashPassword(deviceId));
        await accountCollection.UpdateOneAsync(filter, update);
    }

    public async Task resertOTP(Account account){
        OTP otp = account.getOtp();
        otp.setAttempts(0);
        otp.setRequests(0);
        var filter = Builders<Account>.Filter.Eq("email", account.getEmail());
        var updateOTP = Builders<Account>.Update.Set("otp", otp);
        await accountCollection.UpdateOneAsync(filter, updateOTP);
    }

    public bool isOTPTimeout(OTP otp){
        string now = Time.getTime();
        string today = Time.getDate();

        string requestTime = otp.getTime();
        string requestDate = otp.getDate();

        if(!today.Equals(requestDate)){
            return false;
        }

        if(otp.getAttempts() > 10 || otp.getRequests() >  10){
            return true;
        }

        return false;
    }

    public bool isOTPExpired(string requestTime, string requestDate){
        bool flag = true;

        string now = Time.getTime();
        string today = Time.getDate();

        if(requestDate.Equals(today)){
            int nowMinutes = (Int32.Parse(now.Split(":")[0]) * 60) + Int32.Parse(now.Split(":")[1]);
            int requestMinutes = (Int32.Parse(requestTime.Split(":")[0]) * 60) + Int32.Parse(requestTime.Split(":")[1]);

            if(Math.Abs(nowMinutes - requestMinutes) <= 10){
                return false;
            }
        }

        return flag;
    }
}



