using System.Text.RegularExpressions;
using eboleka.Models;
using eboleka.Utils;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace eboleka.Services;

public class WalletService{

    private readonly IMongoCollection<Wallet> walletCollection;
    

    public WalletService(IOptions<DatabaseSettings> databaseSettings){
        
        var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
        var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);

        walletCollection = mongoDatabase.GetCollection<Wallet>("wallet");
    }

    public async Task addWallet(Wallet wallet){
        await walletCollection.InsertOneAsync(wallet);
    }

    public async Task<Wallet?> getWallet(string uid){
        var filter = Builders<Wallet>.Filter.Eq("uid", uid);
        return await walletCollection.Find(filter).FirstOrDefaultAsync();
    }

    public async Task updateCardIncome(string id, double income){
        var filter = Builders<Wallet>.Filter.Eq("uid", id);
        var update = Builders<Wallet>.Update.Set("cardIncome", income);
        await walletCollection.UpdateOneAsync(filter, update);
    }

    public async Task updateCashIncome(string id, double income){
        var filter = Builders<Wallet>.Filter.Eq("uid", id);
        var update = Builders<Wallet>.Update.Set("cashIncome", income);
        await walletCollection.UpdateOneAsync(filter, update);
    }

    public async Task updateCompletedOrder(string id, double total){
        var filter = Builders<Wallet>.Filter.Eq("uid", id);
        var update = Builders<Wallet>.Update.Set("completedOrders", total);
        await walletCollection.UpdateOneAsync(filter, update);
    }

    public async Task applyRefund(Order order){
        double amount = order.getPrice();

        var queryBusinessWallet = await getWallet(order.getBusinessId());
        var queryClientWallet = await getWallet(order.getClientId());

        if(queryBusinessWallet == null){
            Wallet _wallet = new Wallet(order.getBusinessId(), true);
            await addWallet(_wallet);
            queryBusinessWallet = _wallet;
        }

        if(queryClientWallet == null){
            Wallet _wallet = new Wallet(order.getClientId(), false);
            await addWallet(_wallet);
            queryClientWallet = _wallet;
        }

        Wallet businessWallet = queryBusinessWallet;
        Wallet clientWallet = queryClientWallet;

        double businessAmount = businessWallet.getCardIncome() - amount;
        double clientAmount = clientWallet.getCardIncome() + amount;

        await updateCardIncome(order.getBusinessId(), businessAmount);
        await updateCardIncome(order.getClientId(), clientAmount);

        

    }
    
}