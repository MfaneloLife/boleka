import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Splash from './src/screens/Splash';
import Login from './src/screens/Login';
import Register from './src/screens/Register';
import ResetPassword from './src/screens/ResetPassword';
import OTP from './src/screens/OTP';
import Home from './src/screens/Home';
import Cart from './src/screens/Cart';
import AccountContextProvider from './src/providers/AccountContext';
import BusinessDataContextProvider from './src/providers/BusinessDataContext';
import ViewService from './src/screens/ViewService';
import ClientDataContextProvider from './src/providers/ClientDataContext';
import Checkout from './src/screens/Checkout';
import ViewOrder from './src/screens/ViewOrder';
import Chat from './src/screens/Chat';
import Payment from './src/screens/Payment';
import ViewProfile from './src/screens/ViewProfile';
import NotificationsX from './src/screens/NotificationsX';
import Scan from './src/screens/Scan';
import Scanner from './src/screens/Scanner';
import Search from './src/screens/Search';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <AccountContextProvider>
    <BusinessDataContextProvider>
    <ClientDataContextProvider>
    <NavigationContainer>
        <Stack.Navigator>
        <Stack.Screen name="Splash" component={Splash} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Login" component={Login} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Register" component={Register} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="ResetPassword" component={ResetPassword} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="OTP" component={OTP} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Home" component={Home} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Cart" component={Cart} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="ViewService" component={ViewService} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Checkout" component={Checkout} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="ViewOrder" component={ViewOrder} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Chat" component={Chat} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Payment" component={Payment} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="ViewProfile" component={ViewProfile} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="NotificationsX" component={NotificationsX} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Scan" component={Scan} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Scanner" component={Scanner} options = {{header: ()=> null, statusBarColor: '#282828'}}/>
        <Stack.Screen name="Search" component={Search} options = {{header: ()=> null, statusBarColor: '#282828'}}/>


      </Stack.Navigator>
    </NavigationContainer>
    </ClientDataContextProvider>
    </BusinessDataContextProvider>
    </AccountContextProvider>
  );
}