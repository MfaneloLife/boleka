import React, {useContext, useState} from "react";
import { View, TouchableOpacity, Modal, ScrollView, StyleSheet, Image, Platform, Keyboard } from "react-native";
import { Text, Appbar, Divider, TextInput, FAB, Snackbar, Switch, RadioButton, Button} from "react-native-paper";
import { Octicons } from '@expo/vector-icons';
import MapView, {Marker}from 'react-native-maps';


const ViewMap = ({visible, setVisible, lat, lng}:{visible: boolean, setVisible: Function, lat:number, lng:number})=>{
    const [location, setLocation] = useState({"coords": {"accuracy": 0, "altitude": 0, "altitudeAccuracy": 0, "heading": 0, "latitude": -25.9644113, "longitude": 28.1021085, "speed": 0}, "mocked": false, "timestamp": 0});
    const locationDelta = {
        latitudeDelta: 0.04,
        longitudeDelta: 0.05,
    };

    return(
        <Modal transparent visible = {visible} animationType = 'slide' onDismiss={()=> setVisible(false)}>
        <View style = {{flexDirection: 'column', flex: 1, justifyContent: 'flex-end'}}>
        <View style = {styles.Container}>
        <TouchableOpacity style = {{alignSelf: 'center'}} onPress={()=> setVisible(false)}>
        <Octicons name="horizontal-rule" size={50} color="black" />
        </TouchableOpacity>
        
        <MapView provider="google"
        region = {{latitude: lat, longitude: lng,latitudeDelta: locationDelta.latitudeDelta, longitudeDelta: locationDelta.longitudeDelta}}
        style={{width: '100%', height: 300}}>
    
        <Marker
        coordinate={{latitude: lat, longitude: lng}}
        />
        </MapView>

        </View>
        </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#FFF",
        borderTopRightRadius: 20,
        borderTopLeftRadius: 20,
        marginTop: 20,
        
        minHeight: 360
    },

});

export default ViewMap;