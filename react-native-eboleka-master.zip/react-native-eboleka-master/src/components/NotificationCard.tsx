import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Text } from "react-native-paper";
import React, { useEffect, useState, useContext } from 'react';
import ViewNotification from './ViewNotification';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import axios from 'axios';
import host from "../config/host.json";

const NotificationCard = ({navigation, notification}:{navigation: any, notification: any}) => {
    const api = host.url;
    const {isBusiness, userID, token} = useContext(AccountContext) as AccountInterface;
    const [view, setView] = useState<boolean>(false);

    const [date, setDate] = useState<string>("");
    const [read, setRead] = useState<boolean>(false);
    const colours:Array<string> = ["#9681EB", "#FF6666", "#5A96E3", "#00DFA2", "#6DA9E4", "#F94A29"];

    useEffect(()=>{
        const init = ():void => {
            if(notification.read){
                setRead(true);
            }
        }

        init();
        getDate();
    }, []);

    const getDate = ()=>{
        const months: Array<string> = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

        const today:Date = new Date();
        const day:string = String(today.getDate()).padStart(2, '0');
        const month = months[today.getMonth()];
        const year:string = String(today.getFullYear());

        setDate(`${day} ${month} ${year}`);
    }

    const onRead = async()=>{
       await axios.put(`${api}/notifications`, 
       {uid: notification.uid}, 
       {headers: {"Authorization" : `Bearer ${token}`}});
    }

    const onView = ()=>{
        if(!read){
            onRead();
        }
        setRead(true);
        setView(true);
    }

    return(
        <TouchableOpacity style = {styles.Main} onPress={()=> onView()}>
            <View>
            <View style = {[styles.Avater, {backgroundColor: read ? "gray" : notification.colour}]}>
            <Text variant="labelLarge" style = {{fontSize: 20, color: "#FFF"}}>{notification.title[0]}</Text>
            </View>
            </View>

            <View style = {styles.Content}>
            <Text variant="labelLarge" style = {{color: read ? "gray" : "white"}}>{notification.title}</Text>
            <Text style = {{color: "gray"}}>{notification.message.length > 70 ? notification.message.slice(0, 70) + "..." : notification.message}</Text>
            <Text style = {{color: "gray", marginTop: 4}}>{date === notification.date ? notification.time.substring(0, 5) : notification.date}</Text>
            </View>
            <ViewNotification visible = {view} setVisible={setView} notification = {notification}/>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    Main:{
        display: 'flex',
        flexDirection: 'row',
        backgroundColor: "#282828",
        paddingVertical: 12,
        marginBottom:2,
        paddingHorizontal: 4,
    },
    Content:{
        display: 'flex',
        flexDirection: 'column',
        flex: 1,
        paddingLeft: 4
    },
    Avater:{
        width: 50,
        height: 50,
        borderRadius: 4,
        justifyContent: 'center',
        alignItems: 'center'
    }
});

export default NotificationCard;