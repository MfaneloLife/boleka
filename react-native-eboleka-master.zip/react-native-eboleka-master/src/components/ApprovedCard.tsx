import React, {useContext, useState} from "react";
import { View, Dimensions, Alert } from "react-native";
import { Card, Text, Button } from "react-native-paper";
import axios from "axios";
import { Feather, MaterialCommunityIcons, FontAwesome5, MaterialIcons, Foundation } from '@expo/vector-icons';

const ApprovedCard = ({navigation, order, service}: {navigation: any, order: any, service: any})=>{

    const onView = ()=>{
        navigation.navigate("ViewOrder", {service, order});
    }

    return(
        <Card onPress={()=> onView()} style = {{marginHorizontal: 5, marginVertical: 5, backgroundColor: "#282828" }}>
        <Card.Cover source={{uri: service.imageUrl}} style={{borderBottomLeftRadius: 0, borderBottomRightRadius: 0}}/>
        <View style = {{marginVertical: 5, paddingHorizontal: 12}}>
        <Text variant="titleLarge" style = {{color: "#FFFFFF"}}>{service.title}</Text>
        <Text variant="bodyMedium" style = {{color: "#FFB200"}}>{order.clientName}</Text>

        <View style = {{flexDirection: 'row', justifyContent: 'space-between', marginTop: 5,}}>
        <View style = {{flexDirection: 'row', alignItems: 'center'}}>
        <FontAwesome5 name="calendar-alt" size={24} color="gray" />
        <Text variant="bodyMedium" style = {{color: "#FFFFFF", marginLeft: 5}}>{`${order.serviceDate.split(" ")[0]} ${order.serviceDate.split(" ")[1]} ${order.serviceDate.split(" ")[2]}`}</Text>
        </View>

        <View style = {{flexDirection: 'row', alignItems: 'center'}}>
        <MaterialIcons name="access-time" size={24} color="gray" />
        <Text variant="bodyMedium" style = {{color: "#FFFFFF", marginLeft: 5}}>{order.serviceDate.split(" ")[3]}</Text>
        </View>
        </View>

        <View style = {{flexDirection: 'row', justifyContent: 'space-between', marginTop: 5}}>
        <View style = {{flexDirection: 'row', alignItems: 'center'}}>
        {order.deliveryMethod == 'DELIVERY' ?
        <MaterialCommunityIcons name="truck-delivery-outline" size={24} color="gray" />
        :
        <Feather name="package" size={24} color='gray' />
        }
        <Text variant="bodyMedium" style = {{color: "#FFFFFF", marginLeft: 5}}>{order.deliveryMethod}</Text>
        </View>

        <View style = {{flexDirection: 'row', alignItems: 'center'}}>
        {order.completed ? 
        <Text variant="bodyMedium" style = {{color: "#FFFFFF"}}>Completed</Text>
        :
        <>
        {order.paymentMethod == 'CARD' ? 
        <>
        {order.paid ?
        <Text variant="bodyMedium" style = {{color: "#FFFFFF"}}>Payment Received</Text>
        :
        <Text variant="bodyMedium" style = {{color: "#FFFFFF"}}>Awaiting Payment</Text>
        }
        </>
        :
        <Text variant="bodyMedium" style = {{color: "#FFFFFF"}}>Cash Payment</Text>
        }
        </>
        }
        </View>


        </View>
        
        </View>
        </Card>
    );
}

export default ApprovedCard;

