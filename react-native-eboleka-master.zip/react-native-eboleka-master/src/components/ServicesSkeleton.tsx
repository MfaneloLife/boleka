import { View, Dimensions, StyleSheet, Animated } from 'react-native';
import React, {useRef, useEffect, useContext} from 'react';
import { Card, Text } from 'react-native-paper';
import { AccountContext, AccountInterface } from '../providers/AccountContext';

const ServicesSkeleton = () => {
    const cardWidth:number = (Dimensions.get('window').width / 2) - 10;
    const {isBusiness} = useContext(AccountContext) as AccountInterface;

    useEffect(()=>{
        fadeHandler(true);
    }, []);

    const fadeHandler =(fade: boolean)=>{
        setTimeout(()=>{
            if(fade){
                fadeIn();
                fadeHandler(!fade);
            }else{
                fadeOut();
                fadeHandler(!fade);
            }
        }, 2000);
    }

    const fadeAnim = useRef(new Animated.Value(1)).current;

    const fadeIn = () => {
        // Will change fadeAnim value to 1 in 5 seconds
        Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 2000,
        useNativeDriver: true,
        }).start();
    };

    const fadeOut = () => {
        // Will change fadeAnim value to 0 in 3 seconds
        Animated.timing(fadeAnim, {
        toValue: 0.2,
        duration: 2000,
        useNativeDriver: true,
        }).start();
    };

    return (
        <Card style = {{width: cardWidth, marginHorizontal: 5, marginVertical: 5, backgroundColor: "#282828" }}>
            <Animated.View style = {[styles.ImageHolder, {width: cardWidth, opacity: fadeAnim}]}></Animated.View>
            <View style = {{paddingHorizontal: 5, paddingTop: 5, paddingBottom: 10}}>
            <Animated.View style = {[styles.TextHolder, {width: cardWidth * 0.6, opacity: fadeAnim}]}></Animated.View>
            <Animated.View style = {[styles.TextHolder, {width: cardWidth * 0.4, opacity: fadeAnim}]}></Animated.View>
            <Animated.View style = {[styles.TextHolder, {width: cardWidth * 0.3, opacity: fadeAnim}]}></Animated.View>

            {isBusiness &&
            <View style = {{flexDirection: "row", justifyContent: "space-around"}}>
            <Animated.View style = {[styles.ButtonHolder, {width: cardWidth * 0.5, opacity: fadeAnim}]}></Animated.View>
            <Animated.View style = {[styles.ButtonHolder, {width: cardWidth * 0.4, opacity: fadeAnim}]}></Animated.View>
            </View>
            }
            </View>
        </Card>
    );
}

const styles = StyleSheet.create({
    TextHolder:{
        backgroundColor: "gray",
        borderRadius: 20,
        padding: 9,
        marginTop: 5
    },
    ButtonHolder:{
        backgroundColor: "gray",
        borderRadius: 20,
        padding: 12,
        marginTop: 10,
        height: 45
    },
    ImageHolder:{
        backgroundColor: "gray",
        borderRadius: 10,
        padding: 12,
        height: 200
    }
});

export default ServicesSkeleton;