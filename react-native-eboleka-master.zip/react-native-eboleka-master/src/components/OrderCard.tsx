import { View, Dimensions, Alert, StyleSheet } from 'react-native';
import { Card, Text, Button, Divider } from "react-native-paper";
import React, {useContext, useState} from 'react';
import axios, { AxiosError, AxiosResponse } from 'axios';
import { MaterialCommunityIcons, Feather, MaterialIcons } from '@expo/vector-icons';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import host from "../config/host.json";
import { BusinessDataContext, DataInterface } from '../providers/BusinessDataContext';
import OrderQuery from './OrderQuery';

const OrderCard = ({navigation, order, service, setDim}:{navigation: any, order: any, service: any, setDim: Function}) => {
    const url = host.url;
    const serverToken = host.token;

    const url_security = host.url_security;
    const imageWidth = Dimensions.get('window').width * 0.45;
    const {setRequests, setOrders} = useContext(BusinessDataContext) as DataInterface;
    const {isBusiness, userID, token, name, email} = useContext(AccountContext) as AccountInterface;

    const [decline, setDecline] = useState<boolean>(false);
    const [approve, setApprove] = useState<boolean>(false);

    const [query, setQuery] = useState<boolean>(false);

    const height: number = isBusiness ? 200 : (order.approved ? 200 : 150);

    const onView = ()=>{
        navigation.navigate('ViewOrder', {service, order});
    }

    const getStatus = ()=>{
        let status = "Awaiting Approval";
        if(order.approved){
            status = "Cash Payment";
            if(order.paymentMethod == "CARD"){
                status = "Awaiting Payment";
                if(order.completed){
                    status = "Completed";
                    
                }else if(order.paid){
                    status = "Payment Received";
                }
            }
        }

        return <Text variant="titleLarge" style = {{marginLeft: 5, color: "#FFFFFF", fontSize: 14}}>{status}</Text>
    }

    const onDeleteDialog = ()=>{
        if(!decline){
            Alert.alert('Decline', `You are about to decline ${service.title} request`, [
                {
                  text: 'Cancel',
                  onPress: () => console.log('Cancel Pressed'),
                  style: 'cancel',
                },
                {text: 'Decline', onPress: () => onDecline()},
              ]);
        }
    }

    const onDecline = async()=>{
        setDim(true);
        setDecline(true);
        await axios.delete(`${url}/order/`, {
            data:{uid: order.uid},
            headers: {"Authorization" : `Bearer ${token}`}
        }).then((response: AxiosResponse)=>{
            setRequests(response.data.data);
            setDim(false);
            setDecline(false);
        }).catch((reason: AxiosError)=>{
            setDim(false);
            setDecline(false);
            console.log(reason);
        });
    }

    const onApprove = async()=>{
        setDim(true);
        setApprove(true);
        await axios.put(`${url}/order/`, {
            uid: order.uid
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setOrders(response.data.approved);
            setRequests(response.data.requests);
            setDim(false);
            setApprove(false);
        }).catch((reason: AxiosError)=>{
            setDim(false);
            setApprove(false);
            console.log(reason);
        });
    }

    
    
    const onVerify =async()=>{
        setQuery(true);
        await axios.post(`${url_security}/payment/identifier`,{
            uid : order.uid,
            title: service.title,
            imageUrl: service.imageUrl,
            name: name,
            email: email
        },{headers: {"Authorization" : `Bearer ${serverToken}`}})
        .then((response: AxiosResponse)=>{
            console.log(response.data);
            setQuery(false);
            navigation.navigate('Payment', {token: response.data.key});
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setQuery(false);
        });
    }

    return (
        <Card onPress={()=> onView()} style = {{minHeight: height, marginHorizontal: 5, marginVertical: 5, backgroundColor: "#282828" }}>
            <View style = {{display: 'flex', flexDirection: 'row', width: '100%'}}>

            <View style = {{width: imageWidth}}>
            <Card.Cover style = {{width: imageWidth, height: height}} source={{ uri: service.imageUrl}} />
            </View>

            <View style = {{display: 'flex', flexDirection: 'column', padding: 5}}>
            <View>
            <Text variant="titleLarge" style = {{color: "#FFFFFF", fontSize: 18}}>{service.title}</Text>
            <Text variant="titleSmall" style = {{color: "#FFFFFF"}}>{isBusiness ? order.clientName : service.ownerName}</Text>

            <View style = {{display: 'flex', flexDirection: 'row', alignItems: 'center'}}>
            <MaterialCommunityIcons name="calendar-month" size={24} color="gray" />
            <Text variant="titleLarge" style = {{marginLeft: 5, color: "#FFFFFF", fontSize: 14, marginTop: 5}}>{`${order.serviceDate.split(" ")[0]} ${order.serviceDate.split(" ")[1]} ${order.serviceDate.split(" ")[2]}`}</Text>
            </View>

            

            <View style = {{display: 'flex', flexDirection: 'row', alignItems: 'center'}}>
            {order.deliveryMethod == 'DELIVERY' ?
            <MaterialCommunityIcons name="truck-delivery-outline" size={24} color="gray" />
            :
            <Feather name="package" size={24} color='gray' />
            }
            <Text variant="titleLarge" style = {{marginLeft: 5, color: "#FFFFFF", fontSize: 14}}>{order.deliveryMethod}</Text>
            </View>

            <View style = {{display: 'flex', flexDirection: 'row', alignItems: 'center'}}>
            <MaterialIcons name="av-timer" size={24} color="gray" />
            <Text variant="titleLarge" style = {{marginLeft: 5, color: "#FFFFFF", fontSize: 14}}>{getStatus()}</Text>
            </View>

            </View>
            {isBusiness &&
            <View style = {{flexDirection: 'row', marginTop: 5}}>
                <Button loading = {decline} textColor="#FFB200" style = {[styles.Buttons, {borderColor: 'gray', borderWidth: 1, borderStyle: 'solid'}]} onPress = {()=> onDeleteDialog()}>{decline ? '' : 'Decline'}</Button>
                <Button loading = {approve} textColor="#FFFFFF" buttonColor="#FFB200" style = {[styles.Buttons, {marginLeft: 10}]} onPress={()=> onApprove()}>{approve ? '' : 'Approve'}</Button>
            </View>
            }

            {!isBusiness && order.approved &&
            <View style = {{flexDirection: 'row', marginTop: 5}}>
                <Button loading = {decline} textColor="#FFB200" style = {[styles.Buttons, {borderColor: 'gray', borderWidth: 1, borderStyle: 'solid'}]} onPress = {()=> {navigation.navigate('Chat', {orderId: order.orderId})}}>Chat</Button>
                {order.paymentMethod === "CARD" ? 
                <>
                {order.paid ?
                <>
                {!order.completed &&
                <Button textColor="#FFFFFF" buttonColor="#FFB200" style = {[styles.Buttons, {marginLeft: 10}]} onPress={()=> navigation.navigate("Scan", {order: order, title: service.title})}>Scan</Button>
                }
                 </>
                :
                <Button loading = {approve} textColor="#FFFFFF" buttonColor="#FFB200" style = {[styles.Buttons, {marginLeft: 10}]} onPress={()=> onVerify()}>Pay</Button>
                }
                </>
                :
                <>
                {!order.completed &&
                <Button textColor="#FFFFFF" buttonColor="#FFB200" style = {[styles.Buttons, {marginLeft: 10}]} onPress={()=> navigation.navigate("Scan", {order: order, title: service.title})}>Scan</Button>
                }
                </>
                }
                </View>
            }

            </View>

            </View>

            {query &&
             <OrderQuery visible = {query} />
            }
        </Card>
    );
}

const styles = StyleSheet.create({
    Buttons:{
        borderRadius: 20,
        paddingHorizontal: 2
    }
});

export default OrderCard;