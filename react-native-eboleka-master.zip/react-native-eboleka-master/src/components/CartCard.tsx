import { View, Dimensions, Alert } from 'react-native';
import { Card, Text, Button } from "react-native-paper";
import React, {useContext, useState} from 'react';
import axios, { AxiosError, AxiosResponse } from 'axios';
import host from "../config/host.json";
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';

const CartCard = ({navigation, service, setDeleting}:{navigation: any, service: any, setDeleting: Function}) => {
    const url = host.url;
    const imageWidth = Dimensions.get('window').width * 0.45;
    const {userID, token} = useContext(AccountContext) as AccountInterface;
    const {setCart} = useContext(ClientDataContext) as ClientDataInterface;
    
    const onDeleteDialog = ()=>{
        Alert.alert('Delete', `You are about to remove ${service.title} from your cart`, [
            {
                text: 'Cancel',
                style: 'cancel',
            },
            {text: 'Delete', onPress: () => onDelete()},
            ]);
    }

    const onDelete = async()=>{
        setDeleting(true);
        await axios.delete(`${url}/cart/`, {
            headers:{"Authorization" : `Bearer ${token}`},
            data:{
                uid: service.uid
            }
        }).then((response: AxiosResponse)=>{
            setCart(response.data.data);
            setDeleting(false);
        }).catch((err: AxiosError)=>{
            console.log(err);
            setDeleting(false);
        });
    }

    const onView = ()=>{
        navigation.navigate("ViewService", {service: service});
    }

    const onCheckout = ()=>{
        navigation.navigate("Checkout", {service: service});
    }

    return (
        <Card style = {{ marginHorizontal: 5, marginVertical: 5, backgroundColor: "#282828" }} onPress={()=> onView()}>
            <View style = {{display: 'flex', flexDirection: 'row', width: '100%'}}>

            <View style = {{width: imageWidth}}>
            <Card.Cover source={{ uri: service.imageUrl}} />
            </View>

            <View style = {{display: 'flex', flexDirection: 'column', padding: 5, justifyContent: 'space-between'}}>
            <View>
            <Text variant="titleLarge" style = {{color: "#FFFFFF", fontSize: 18}}>{service.title}</Text>
            <Text variant="titleLarge" style = {{color: "#FFFFFF", fontSize: 14}}>{service.ownerName}</Text>
            <Text variant="titleLarge" style = {{color: "#FFFFFF", fontSize: 20, fontWeight: 'bold'}}>{`R${service.price}`}</Text>
            </View>

            <Button textColor = "#FFFFFF" mode = 'outlined' style = {{borderRadius: 5, width: imageWidth, borderColor: "#FFFFFF"}} onPress={()=> onDeleteDialog()}>Remove</Button>
            <Button textColor = "#FFFFFF" buttonColor='#FFB200' mode = 'contained' style = {{borderRadius: 5, width: imageWidth}} onPress={()=> onCheckout()}>Checkout</Button>

            </View>

            </View>
    
            
           
        </Card>
    );
}

export default CartCard;