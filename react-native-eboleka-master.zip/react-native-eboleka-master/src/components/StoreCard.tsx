import React, {useContext, useState} from "react";
import { View, Dimensions, Alert } from "react-native";
import { Card, Text, Button } from "react-native-paper";

const Storecard = ({navigation, store}:{navigation: any, store: any})=>{
    const cardWidth = (Dimensions.get('window').width / 2) - 10;

    const onViewProfile = ()=>{
        navigation.navigate('ViewProfile', {name: store.name, id: store.uid});
    }

    return(
        <Card style = {{width: cardWidth, marginHorizontal: 5, marginVertical: 5, backgroundColor: "#282828" }}>
            {store.imageUrl == null ?
            <Card.Cover source={require("../assets/store.jpg")} />
            :
            <Card.Cover  source={{ uri: store.imageUrl}} />
            }
            <View style = {{paddingHorizontal: 5, paddingTop: 5, paddingBottom: 10}}>
            <Text variant="titleLarge" style = {{color: "#FFFFFF", fontSize: 18}}>{store.name.length > 15 ? store.name.substring(0, 15) + "..." : store.name}</Text>
            
            </View>

            <Button textColor = "#FFFFFF" buttonColor="#FFB200" style = {{marginHorizontal: 5, marginBottom: 12}} onPress={()=> onViewProfile()}>View</Button>        
        </Card>
    );
}

export default Storecard;

