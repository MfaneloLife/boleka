import React, {useContext, useState, useEffect} from "react";
import { View, TouchableOpacity, Modal, ScrollView, StyleSheet, Image, Platform, Keyboard } from "react-native";
import { Text, Appbar, Divider, TextInput, FAB, Snackbar, Switch, RadioButton, Button} from "react-native-paper";
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import uuid from 'react-native-uuid';
import { firebase } from "../config/firebase";
import axios, { AxiosError, AxiosResponse } from "axios";
import darkMode from '../theme/darkMode';
import InvisibleLoader from "../utils/InvisibleLoader";
import { AccountContext, AccountInterface} from '../providers/AccountContext';
import host from "../config/host.json";
import { BusinessDataContext, DataInterface } from "../providers/BusinessDataContext";

const Editservice = ({visible, setVisible, service}:{visible: boolean, setVisible: any, service: any})=>{
    const api = host.url;
    const {setServices} = useContext(BusinessDataContext) as DataInterface;
    const {userID, email, name, token} = useContext(AccountContext) as AccountInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', ',', '.'];

    useEffect(()=>{
        setImage(service.imageUrl);
        setTitle(service.title);
        setPrice(String(service.price));
        setServiceVisible(service.isVisible);
        setDescription(service.description);

        initMethods();
    }, []);

    const initMethods = ()=>{
        const deliveryArray: Array<string> = service.deliveryMethods;
        const paymentArray: Array<string> = service.paymentMethods;

        if(deliveryArray.length == 2){
            setDelivery('2');
        }else{
            switch(deliveryArray[0]){
                case "DELIVERY":
                    setDelivery('0');
                    break;
                case "COLLECTION":
                    setDelivery('1');
                    break;
            }
        }

        if(paymentArray.length == 2){
            setPayment('2');
        }else{
            switch(paymentArray[0]){
                case "CARD":
                    setPayment('1');
                    break;
                case "CASH":
                    setPayment('0');
                    break;
            }
        }
    }

    const [serviceVisible, setServiceVisible] = useState<boolean>(true);
    const [payment, setPayment] = useState<string>('2');
    const [delivery, setDelivery] = useState<string>('2');

    const [image, setImage] = useState<string | null>(null);

    const [title, setTitle] = useState<string>('');
    const [price, setPrice] = useState<string>('');
    const [description, setDescription] = useState<string>('');

    const [uploading, setUploading] = useState<boolean>(false);

    const [toast, setToast] = useState('');
    const [showSnackbar, setShowSnackbar] = useState(false);

    const clearData = ()=>{
        setPrice('');
        setTitle('');
        setImage(null);
        setPayment('2');
        setDelivery('2');
        setDescription('');
    }

    const onDismissSnackBar = () =>{
        setShowSnackbar(false);
    }

    const pickImage = async () => {
        let result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          allowsEditing: true,
          aspect: [4, 3],
          quality: 1,
        });
    
        if (!result.canceled) {
            setImage(result.assets[0].uri);
        }
    };

    const changePrice =(text: string)=>{
        let valid: boolean = true;
        let count: number = 0;

        for(let i = 0; i < text.length; i++){
            const char: string = text[i];
            if(!numbers.includes(char)){
                valid = false;
            }

            if(char === '.' || char === ','){
                count = count + 1;
            }
        }

        if(text[0] === '.' || text[0] === ',' || text[0] === '0'){
            valid = false;
        }

        if(count > 1){
            valid = false;
        }

        if(valid){
            setPrice(text);
        }
    }

    const onUpload = ()=>{
        Keyboard.dismiss();
        setToast("All fields are required");

        if(image !== null && title.trim() !== "" && price.trim() !== "" && description.trim() != ""){
            uploadImage();
        }else{
            setShowSnackbar(true);
        }
    }

    const uploadImage = async()=>{
        setUploading(true);
        if(String(image) == service.imageUrl){
            uploadService(String(image));
        }else{
            setToast('Failed to update');
            const response = await fetch(String(image));
            const blob = await response.blob();
            const filename = uuid.v4('128');
            
            const ref = firebase.storage().ref().child(`services/${filename}`);
            
            ref.put(blob).then((snapshot:any) => {
                snapshot.ref.getDownloadURL().then((url:string) => {
                    uploadService(url);
                })
            }).catch((err:any)=>{
                console.log(err);
                setShowSnackbar(true);
                setUploading(false);
            });
        }
        
    }

    const removeImage = async(imageUrl: string)=>{
        let imageRef = firebase.storage().refFromURL(imageUrl);
        imageRef.delete().then((res)=>{}).catch((err)=>{});
    }

    const uploadService = async(url:string)=>{
        const amount: number = parseFloat(price.replace(',', '.'));

        const paymentMethods: Array<number> = new Array();
        const deliveryMethods: Array<number> = new Array();

        if(delivery === '0'){
            deliveryMethods.push(0);
        }else if(delivery === '1'){
            deliveryMethods.push(1);
        }else{
            deliveryMethods.push(0);
            deliveryMethods.push(1);
        }

        if(payment === '0'){
            paymentMethods.push(0);
        }else if(delivery === '1'){
            paymentMethods.push(1);
        }else{
            paymentMethods.push(0);
            paymentMethods.push(1);
        }

        await axios.put(`${api}/product/`, {
            uid: service.uid,
            imageUrl: url,
            ownerId: userID,
            ownerName: name,
            title: title.trim(),
            price: amount.toFixed(2),
            isVisible: serviceVisible,
            description: description.trim(),
            paymentMethods: paymentMethods,
            deliveryMethods: deliveryMethods,
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            if(url !== service.imageUrl){
                removeImage(service.imageUrl);
            }
            setServices(response.data.products)
            setUploading(false);
            setVisible(false);
            clearData();
        }).catch((reason: AxiosError)=>{
            if(url !== service.imageUrl){
                removeImage(url);
            }
            if (reason.response!.status === 401) {
                setToast('Could not update');
            } else {
                setToast('Something went wrong, try again later');
            }
            
            console.log(reason);
            setShowSnackbar(true);
            setUploading(false);
        });
    }

    return(
        <Modal visible = {visible} animationType = 'slide'>
            <View style = {darkMode.Main}>
            <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
            <Appbar.Content title="Update Service" color = "#FFFFFF"/>
            <Appbar.Action icon="window-close" onPress={()=> setVisible(false)} color = "#FFFFFF"/>
            </Appbar.Header>
            <ScrollView>

            <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.Title}>Service Details</Text>
            <TouchableOpacity style = {styles.Image} onPress={()=> pickImage()}>
            {image == null ?
                <MaterialCommunityIcons name="file-image-plus-outline" size={50} color="white" />
                :
                <Image source={{uri: image}} style={{ width: '100%', height: 220, borderTopLeftRadius: 5, borderTopRightRadius: 5}}/>
            }
            </TouchableOpacity>

            <TextInput 
            value={title}
            label="Title" 
            style = {styles.Input}
            textColor='#121212'
            activeUnderlineColor='#FFB200'
            dense
            maxLength={40}
            onChangeText={(text)=> setTitle(text)}
            />

            <TextInput 
            value={price}
            label="Price" 
            style = {styles.Input}
            textColor='#121212'
            activeUnderlineColor='#FFB200'
            dense
            maxLength={10}
            keyboardType="numeric"
            onChangeText={(text)=> changePrice(text)}
            />

            <TextInput 
            value={description}
            label="Description" 
            style = {styles.Input}
            textColor='#121212'
            activeUnderlineColor='#FFB200'
            maxLength={140}
            dense
            multiline
            onChangeText={(text)=> setDescription(text)}
            />
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Visibility</Text>
                <View style = {{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                    <Text style = {{color: "#FFFFFF"}}>Service visible to clients</Text>
                    <Switch value={serviceVisible} color="#FFB200" onValueChange={()=> setServiceVisible(!serviceVisible)}/>
                </View>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Payment Method</Text>
                <RadioButton.Group onValueChange={newValue => setPayment(newValue)} value={payment}>
                    <View style = {styles.Radio}>
                        <RadioButton disabled value="1" color="#FFB200"/>
                        <Text style = {{color: "#FFFFFF"}}>Card/Online</Text>
                    </View>

                    <View style = {styles.Radio}>
                        <RadioButton value="0" color="#FFB200"/>
                        <Text style = {{color: "#FFFFFF"}}>Cash</Text>
                    </View>

                    <View style = {styles.Radio}>
                        <RadioButton disabled value="2" color="#FFB200"/>
                        <Text style = {{color: "#FFFFFF"}}>Card and Cash</Text>
                    </View>
                </RadioButton.Group>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Delivery Method</Text>
                <RadioButton.Group onValueChange={newValue => setDelivery(newValue)} value={delivery}>
                    <View style = {styles.Radio}>
                        <RadioButton value="0" color="#FFB200"/>
                        <Text style = {{color: "#FFFFFF"}}>Delivery</Text>
                    </View>

                    <View style = {styles.Radio}>
                        <RadioButton value="1" color="#FFB200"/>
                        <Text style = {{color: "#FFFFFF"}}>Collection</Text>
                    </View>

                    <View style = {styles.Radio}>
                        <RadioButton value="2" color="#FFB200"/>
                        <Text style = {{color: "#FFFFFF"}}>Delivery and Collection</Text>
                    </View>
                </RadioButton.Group>
            </View>

            <Button loading={uploading} mode = "contained" style = {{marginTop: 20, marginHorizontal: 12, borderRadius: 5, backgroundColor: "#FFB200", marginBottom: 50}} onPress={()=> onUpload()}>UPDATE</Button>
            
            <Snackbar duration={1500} visible={showSnackbar} onDismiss={onDismissSnackBar} style={{backgroundColor: '#282828'}}>{toast}</Snackbar>
            <InvisibleLoader visible={uploading}/>
            </ScrollView>
            </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#282828",
        borderRadius: 10,
        marginHorizontal: 12,
        marginTop: 20,
        padding: 8
    },
    Title:{
        color: "#FFFFFF",
        marginBottom: 5
    },
    Radio:{
        flexDirection: 'row',
        alignItems: 'center'
    },
    Image:{
        minHeight: 100,
        width: '100%',
        marginBottom: 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    Input:{
        marginVertical: 5,
        //backgroundColor: "#282828", 
        fontWeight: '600',
    }
});

export default Editservice;
