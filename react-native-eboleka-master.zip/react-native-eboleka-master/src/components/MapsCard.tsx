import React from "react";
import { View, StyleSheet, TouchableOpacity } from "react-native";
import { Text } from "react-native-paper";

const MapsCard = ({place, setDeliveryAddress, setChoice}:{place: any, setDeliveryAddress:Function, setChoice:Function})=>{

    const address:Array<string> = place.address.split(",");

    const update = ()=>{
        setDeliveryAddress(place);
        setChoice(true);
    }

    return(
        <TouchableOpacity style = {[styles.Main, { borderColor: '#FFF'}]} onPress={()=> update()}>
            {address.length >= 4 ?
            <>
            <Text style = {{color: "#FFF"}}>{address[0].trim()}</Text>
            <Text style = {{color: "#FFF"}}>{address[1].trim()}</Text>
            <Text style = {{color: "#FFF"}}>{address[2].trim()}</Text>
            <Text style = {{color: "#FFF"}}>{address[3].trim()}</Text>
            </>
            :
            <>
            {address.map((item, index)=>
            <Text style = {{color: "#FFF"}} key={index}>
            {item.trim()}
            </Text>
            )}
            </>
            }
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    Main:{
        borderWidth: 1,
        marginVertical: 2,
        padding: 4,
        borderRadius: 2
    }
});

export default MapsCard;
