import React, {useContext, useState} from "react";
import { View, TouchableOpacity, Modal, ScrollView, StyleSheet, Image, Platform, Keyboard } from "react-native";
import { Text, Appbar, Divider, TextInput, FAB, Snackbar, Switch, RadioButton, Button} from "react-native-paper";
import { Octicons } from '@expo/vector-icons';
import axios, { AxiosError, AxiosResponse } from "axios";
import { AccountContext, AccountInterface} from '../providers/AccountContext';

const ViewNotification = ({visible, setVisible, notification}:{visible: boolean, setVisible: Function, notification: any})=>{
    const {userID, email, name, token} = useContext(AccountContext) as AccountInterface;
    
    return(
        <Modal transparent visible = {visible} animationType = 'slide' onDismiss={()=> setVisible(false)}>
        <View style = {{flexDirection: 'column', flex: 1, justifyContent: 'flex-end'}}>
        <View style = {styles.Container}>
        <TouchableOpacity style = {{alignSelf: 'center'}} onPress={()=> setVisible(false)}>
        <Octicons name="horizontal-rule" size={50} color="black" />
        </TouchableOpacity>
        
        <Text variant="headlineSmall" style = {{ marginBottom: 10}} >{notification.title}</Text>
        <Text>{notification.message}</Text>

        <Text style = {{marginTop: 12}}>{notification.time}</Text>
        <Text>{notification.date}</Text>
        </View>
        </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#FFF",
        borderTopRightRadius: 20,
        borderTopLeftRadius: 20,
        marginTop: 20,
        paddingHorizontal: 8,
        minHeight: '40%'
    },

});

export default ViewNotification;