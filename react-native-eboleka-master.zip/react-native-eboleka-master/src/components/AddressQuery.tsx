import React, {useContext, useState, useEffect} from "react";
import { View, TouchableOpacity, Modal, ScrollView, StyleSheet, Image, Platform, Keyboard } from "react-native";
import { Text, Appbar, Divider, TextInput, FAB, Snackbar, Switch, RadioButton, Button, ActivityIndicator} from "react-native-paper";
import { Octicons } from '@expo/vector-icons';
import axios, { AxiosError, AxiosResponse } from "axios";
import { AccountContext, AccountInterface} from '../providers/AccountContext';
import MapsCard from "./MapsCard";
import host from "../config/host.json";
import MapsIllustr from '../assets/maps.svg';

const AddressQuery = ({visible, setVisible, street, suburb, city, code, lookedup, setLookedup, places, setPlaces, setDeliveryAddress, mapsError, setMapsError }:{visible: boolean, setVisible: Function, street:string, suburb:string, city:string, code:string, lookedup:boolean, setLookedup:Function, places: Array<any>, setPlaces: Function, setDeliveryAddress: Function, mapsError: boolean, setMapsError:Function})=>{
    const api = host.url;

    const {userID, email, name, token} = useContext(AccountContext) as AccountInterface;

    const [choice, setChoice] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);

    const queryAddress = async()=>{
        setLoading(true);
        await axios.post(`${api}/map`, {
            street: street,
            suburb: suburb,
            city: city,
            code: code
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            console.log(response.data);
            setPlaces(response.data.data);
            setLookedup(true);
            setLoading(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setMapsError(true);
            setLoading(false);
        });
    }
    
    return(
        <Modal transparent visible = {visible} animationType = 'slide' onDismiss={()=> setVisible(false)}>
        <View style = {{flexDirection: 'column', flex: 1, justifyContent: 'flex-end'}}>
        <View style = {styles.Container}>
        <TouchableOpacity style = {{alignSelf: 'center'}} onPress={()=> setVisible(false)}>
        <Octicons name="horizontal-rule" size={50} color="gray" />
        </TouchableOpacity>

        {!loading && mapsError &&
        <View style = {{flex: 1, display: 'flex', flexDirection: "column", justifyContent: 'center', alignItems: 'center'}}>
        <MapsIllustr width={200} height={200}/>
        <Text variant="titleSmall" style = {{color: "#FFF", marginTop: 5}}>Address not valid</Text>
        </View>
        }

        {!lookedup && !mapsError &&
        <View style = {{flex: 1, display: 'flex', flexDirection: "column", justifyContent: 'space-between'}}>

        <View>
        <Text variant="titleMedium" style = {{color: "#FFF", marginBottom: 12}}>Address to lookup</Text>
        <Text style = {{color: "#FFF"}}>{street}</Text>
        <Text style = {{color: "#FFF"}}>{suburb}</Text>
        <Text style = {{color: "#FFF"}}>{city}</Text>
        <Text style = {{color: "#FFF"}}>{code}</Text>
        </View>

        <Button loading = {loading} buttonColor='#FFB200' textColor="#FFFFFF" mode='contained' style = {{marginTop: 20, borderRadius: 5, backgroundColor: "#FFB200", marginBottom: 50,}} onPress={()=> queryAddress()}>Search</Button>
        </View>
        }

        {!loading && !mapsError && places.length > 0 &&
       <ScrollView>

        <View style = {{flex: 1, display: 'flex', flexDirection: "column", justifyContent: 'space-between'}}>
        <View>
        
        <Text variant="titleMedium" style = {{color: "#FFF", marginBottom: 12}}>Select your address below</Text>
        
        {places.map((item, index)=>
        <MapsCard 
        setChoice={setChoice}
        place={item}
        key={index}
        setDeliveryAddress={setDeliveryAddress}
        />
        )}
        
        </View>

        <Button disabled = {!choice} buttonColor='#FFB200' textColor="#FFFFFF" mode='contained' style = {{marginTop: 20, borderRadius: 5, backgroundColor: "#FFB200", marginBottom: 50,}} onPress={()=> setVisible(false)}>Continue</Button>
        </View>

        </ScrollView>
        }
        
        </View>
        </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#282828",
        borderTopRightRadius: 20,
        borderTopLeftRadius: 20,
        marginTop: 20,
        paddingHorizontal: 8,
        minHeight: '57%',
        maxHeight: '75%'

    },

});

export default AddressQuery;