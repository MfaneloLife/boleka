import React, {useContext, useState, useEffect} from "react";
import { View, TouchableOpacity, Modal, ScrollView, StyleSheet, Image, Platform, Keyboard } from "react-native";
import { Text, Appbar, Divider, TextInput, Snackbar, Button, Avatar} from "react-native-paper";
import * as ImagePicker from 'expo-image-picker';
import uuid from 'react-native-uuid';
import { firebase } from "../config/firebase";
import axios, { AxiosError, AxiosResponse } from "axios";
import darkMode from '../theme/darkMode';
import InvisibleLoader from "../utils/InvisibleLoader";
import { AccountContext, AccountInterface} from '../providers/AccountContext';
import host from "../config/host.json";

const UpdateProfile = ({visible, setVisible}:{visible: boolean, setVisible: Function})=>{
    const api = host.url;
    const {userID, email, name, token, isBusiness, about, street, suburb, city, code, imageUrl, phone, updateProfile} = useContext(AccountContext) as AccountInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    const [image, setImage] = useState<string | null>(null);
    const [textAbout, setTextAbout] = useState<string>("");
    const [textPhone, setTextPhone] = useState<string>("");

    const [textStreet , setTextStreet] = useState<string>("");
    const [textSuburb , setTextSuburb] = useState<string>("");
    const [textCity , setTextCity] = useState<string>("");
    const [textCode , setTextCode] = useState<string>("");

    const [uploading, setUploading] = useState<boolean>(false);

    const [toast, setToast] = useState('');
    const [showSnackbar, setShowSnackbar] = useState(false);

    const onDismissSnackBar = () =>{
        setShowSnackbar(false);
    }

    useEffect(()=>{
        initValues();
    }, []);

    const onClose = ()=>{
        setVisible(false);
        initValues();
    }

    const initValues = ()=>{
        setImage(imageUrl);
        setTextAbout(about);
        setTextPhone(phone);
        setTextStreet(street);
        setTextSuburb(suburb);
        setTextCity(city);
        setTextCode(code);
    }

    const pickImage = async () => {
        let result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          allowsEditing: true,
          aspect: [4, 3],
          quality: 1,
        });
    
        if (!result.canceled) {
            setImage(result.assets[0].uri);
        }
    };

    const uploadImage = async()=>{
        setUploading(true);
        if(String(image) === imageUrl){
            onUpdateProfile(String(image));
        }else{
            setToast('Failed to update');
            const response = await fetch(String(image));
            const blob = await response.blob();
            const filename = uuid.v4('128');
            
            const ref = firebase.storage().ref().child(`profile/${filename}`);
            
            ref.put(blob).then((snapshot:any) => {
                snapshot.ref.getDownloadURL().then((url:string) => {
                    if(image !== null){
                        removeImage(image);
                    }
                    onUpdateProfile(url);
                })
            }).catch((err:any)=>{
                console.log(err);
                setShowSnackbar(true);
                setUploading(false);
            });
        }
    }

    const removeImage = async(imageUrl: string)=>{
        try{
            let imageRef = firebase.storage().refFromURL(imageUrl);
            imageRef.delete().then((res)=>{}).catch((err)=>{});
        }catch{

        }
    }

    const validateFields = ()=>{
        Keyboard.dismiss();
        if(image === null){
            setToast("Upload Image");
            setShowSnackbar(true);
            return;
        }

        if(isBusiness && textAbout.trim() === ""){
            setToast("About is Empty");
            setShowSnackbar(true);
            return;
        }

        if(!String(textPhone).match(/^((06)|(07)|(08))[0-9]{8}$/)){
            setToast("Invalid Phone Number");
            setShowSnackbar(true);
            return;
        }

        if(isBusiness && textStreet.trim() === "" && textSuburb.trim() === "" && textCity.trim() === ""){
            setToast("Invalid Address");
            setShowSnackbar(true);
            return;
        }

        if(isBusiness && !String(textCode).match(/^[0-9]{4}$/)){
            setToast("Invalid Postal Code");
            setShowSnackbar(true);
            return;
        }

        uploadImage();
    }

    const onUpdateProfile =async(url: string)=>{
        setToast('Failed to update');
        await axios.put(`${api}/profile`, {
            imageUrl: url,
            about: textAbout.trim(),
            phone: textPhone.trim(),
            street: textStreet.trim(),
            suburb: textSuburb.trim(),
            city: textCity.trim(),
            code: textCode.trim()
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            const data = response.data.data;
            updateProfile(url, data.street, data.suburb, data.city, data.code, data.about, data.phone);
            setUploading(false);
            setVisible(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setUploading(false);
            setShowSnackbar(true);
        });
    }

    return(
        <Modal visible = {visible} animationType = 'slide'>
            <View style = {darkMode.Main}>
            <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
            <Appbar.Content title="Update Profile" color = "#FFFFFF"/>
            <Appbar.Action icon="window-close" onPress={()=> onClose()} color = "#FFFFFF"/>
            </Appbar.Header>
            <ScrollView>
            <View style = {{flexDirection: 'column', alignItems: 'center', marginTop: 12}}>
            <TouchableOpacity onPress={()=> pickImage()}>
            {image === null?
            <Avatar.Text size={180} label={name[0]} />
            :
            <Avatar.Image size={180} source={{uri: String(image)}} />
            }
            </TouchableOpacity>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Contacts</Text>
                {isBusiness &&
                <TextInput 
                value={textAbout}
                label="About" 
                style = {styles.Input}
                textColor='#121212'
                activeUnderlineColor='#FFB200'
                maxLength={140}
                dense
                multiline
                onChangeText={(text)=> setTextAbout(text)}
                />
                }

                <TextInput 
                value={textPhone}
                label="Phone Number" 
                style = {styles.Input}
                textColor='#121212'
                activeUnderlineColor='#FFB200'
                maxLength={10}
                dense
                keyboardType="decimal-pad"
                onChangeText={(text)=> setTextPhone(text)}
                />

                <TextInput 
                value={email}
                label="Email" 
                style = {styles.Input}
                textColor='#121212'
                activeUnderlineColor='#FFB200'
                maxLength={140}
                dense
                editable = {false}
                />
            </View>

            {isBusiness &&
            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Address</Text>
                <TextInput 
                value={textStreet}
                label="Street" 
                style = {styles.Input}
                textColor='#121212'
                activeUnderlineColor='#FFB200'
                maxLength={40}
                dense
                onChangeText={(text)=> setTextStreet(text)}
                />

                <TextInput 
                value={textSuburb}
                label="Suburb" 
                style = {styles.Input}
                textColor='#121212'
                activeUnderlineColor='#FFB200'
                maxLength={40}
                dense
                onChangeText={(text)=> setTextSuburb(text)}
                />

                <TextInput 
                value={textCity}
                label="City" 
                style = {styles.Input}
                textColor='#121212'
                activeUnderlineColor='#FFB200'
                maxLength={40}
                dense
                onChangeText={(text)=> setTextCity(text)}
                />

                <TextInput 
                value={textCode}
                label="Postal Code" 
                style = {styles.Input}
                textColor='#121212'
                activeUnderlineColor='#FFB200'
                maxLength={4}
                dense
                keyboardType="decimal-pad"
                onChangeText={(text)=> setTextCode(text)}
                />
            </View>
            }


           
            <Button loading={uploading} mode = "contained" style = {{marginTop: 20, marginHorizontal: 12, borderRadius: 5, backgroundColor: "#FFB200", marginBottom: 50}} onPress={()=> validateFields()}>UPDATE</Button>
            
            <Snackbar duration={1500} visible={showSnackbar} onDismiss={onDismissSnackBar} style={{backgroundColor: '#282828'}}>{toast}</Snackbar>
            <InvisibleLoader visible={uploading}/>
            </ScrollView>
            </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#282828",
        borderRadius: 10,
        marginHorizontal: 12,
        marginTop: 20,
        padding: 8
    },
    Title:{
        color: "#FFFFFF",
        marginBottom: 5
    },
    Radio:{
        flexDirection: 'row',
        alignItems: 'center'
    },
    Image:{
        minHeight: 100,
        width: '100%',
        marginBottom: 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    Input:{
        marginVertical: 5,
        //backgroundColor: "#282828", 
        fontWeight: '600',
    }
});

export default UpdateProfile;
