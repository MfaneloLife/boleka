import React, {useContext, useState} from "react";
import { View, Dimensions, Alert } from "react-native";
import { Card, Text, Button, Snackbar } from "react-native-paper";
import axios, { AxiosError, AxiosResponse } from "axios";
import {firebase} from "../config/firebase";
import host from "../config/host.json";
import { AccountContext, AccountInterface } from "../providers/AccountContext";
import Editservice from "./EditService";
import { BusinessDataContext, DataInterface } from "../providers/BusinessDataContext";
import Help from "../utils/Help";

const ServiceCard = ({navigation, service}: {navigation: any, service: any})=>{
    const url = host.url;
    
    const {setServices, getServices} = useContext(BusinessDataContext) as DataInterface;
    const {userID, email, name, isBusiness, token} = useContext(AccountContext) as AccountInterface;
    const cardWidth = (Dimensions.get('window').width / 2) - 10;

    const [deleteService, setDeleteService] = useState(false);
    const [edit, setEdit] = useState<boolean>(false);

    const [showHelp, setShowHelp] = useState<boolean>(false);

    const onView = ()=>{
        navigation.navigate("ViewService", {service});
    }

    const onDeleteDialog = ()=>{
        if(!deleteService){
            Alert.alert('Delete', `You are about to delete ${service.title}`, [
                {
                  text: 'Cancel',
                  onPress: () => console.log('Cancel Pressed'),
                  style: 'cancel',
                },
                {text: 'Delete', onPress: () => onDelete()},
              ]);
        }
    }

    const deleteImage = async()=>{
        let imageRef = firebase.storage().refFromURL(service.imageUrl);
        imageRef.delete().then(()=>{
        console.log('image deleted');
        }).catch((err)=>{
        console.log(err)
        console.log('failed to delete image');
        });
    }

    const onDelete = async()=>{
        setDeleteService(true);
        await axios.delete(`${url}/product/`, {
            headers:{"Authorization" : `Bearer ${token}`},
            data:{
                uid: service.uid,
            }
        }).then((response: AxiosResponse)=>{
            deleteImage();
            setDeleteService(false);
            setServices(response.data.products);
        }).catch((reason: AxiosError)=>{
            setShowHelp(true);
            console.log(reason);
            setDeleteService(false);
        })
    }

    return(
        <Card onPress={()=> onView()} style = {{width: cardWidth, marginHorizontal: 5, marginVertical: 5, backgroundColor: "#282828"}}>
            <Card.Cover source={{ uri: service.imageUrl }} />
            <View style = {{paddingHorizontal: 5, paddingTop: 5, paddingBottom: 10}}>
            <Text variant="titleLarge" style = {{color: "#FFFFFF", fontSize: 18}}>{service.title}</Text>
            <Text variant="titleLarge" style = {{color: "#FFFFFF", fontSize: 14}}>{service.ownerName}</Text>
            <Text variant="titleLarge" style = {{color: "#FFFFFF", fontSize: 20, fontWeight: 'bold'}}>{`R${service.price}`}</Text>
            </View>

            {isBusiness &&
            <Card.Actions>
                <Button loading = {deleteService} textColor="#FFB200"onPress = {()=> onDeleteDialog()} >{deleteService ? '' : 'Delete'}</Button>
                <Button buttonColor="#FFB200" onPress={()=> deleteService? {} : setEdit(true)}>Edit</Button>
            </Card.Actions>
            }

        <Editservice visible = {edit} setVisible={setEdit} service={service}/>
        {showHelp &&
        <Help visible = {showHelp} setVisible={setShowHelp} query="DeleteOrder" />
        }
        </Card>

    );
}

export default ServiceCard;

