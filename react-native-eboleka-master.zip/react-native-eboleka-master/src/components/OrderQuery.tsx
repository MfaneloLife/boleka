import { View, StyleSheet, Modal, ActivityIndicator } from 'react-native';
import { Text } from 'react-native-paper';
import React from 'react';

const OrderQuery = ({visible}: {visible: boolean}) => {
    return (
        <View style={styles.centeredView}>
        <Modal visible = {visible} transparent={true}>
            <View style = {styles.centeredView}>
                <View style = {styles.Main}>
                    <Text variant="titleLarge" >Payment</Text>
                    <Text variant="bodyMedium" >Please wait as we verify the order infomation. This make take a while.</Text>
                    <ActivityIndicator size = "large" color="#FFB200" style = {{marginVertical: 12}}/>
                </View>
            </View>
        </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    Main:{
        display: 'flex',
        flexDirection: 'column',
        margin: 20,
        width: '95%',
        backgroundColor: "white",
        borderRadius: 12,
        padding: 12,
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22,
        marginHorizontal: 12,
    }
});

export default OrderQuery;