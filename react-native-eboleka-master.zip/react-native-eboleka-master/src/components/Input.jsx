import React, {useState} from "react";
import {View, Text, TextInput, StyleSheet} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

export default Input = ({label, iconName, error, password, onFocus = ()=> {}, ...props})=>{
    const [hidePassword, setHidePassword] = useState(password);
    const [isFocused, setIsFocused] = useState(false);

    return(
        <View style={{marginBottom: 20}}>
            <Text style={style.label}>{label}</Text>
            <View style = {[style.inputContainer,{borderColor: error? 'red': isFocused ? '#FFB200': '#F3F4FB',alignItems: 'center',},]}>
            <Icon name = {iconName} style={{color: '#FFB200', fontSize: 22, marginRight: 10}}/>
            <TextInput autoCorrect={false}
                onFocus={() => {
                    onFocus();
                    setIsFocused(true);
                }}
                onBlur={() => setIsFocused(false)}
                secureTextEntry={hidePassword}
                style={{color: '#FFB200', flex: 1, fontWeight: '500'}}
                {...props}
            />
            {password && (
            <Icon
                onPress={() => setHidePassword(!hidePassword)}
                name={hidePassword ? 'eye-outline' : 'eye-off-outline'}
                style={{color: '#FFB200', fontSize: 22}}
            />
            )}
            </View>
            {error && (
            <Text style={{marginTop: 7, color: 'red', fontSize: 12}}>{error}</Text>
            )}
        </View>
    );

}

const style = StyleSheet.create({
    label: {
      marginVertical: 5,
      fontSize: 14,
      color: 'gray',
    },
    inputContainer: {
      height: 55,
      backgroundColor: '#F3F4FB',
      flexDirection: 'row',
      paddingHorizontal: 15,
      borderWidth: 0.5,
      borderRadius: 5
    },
  });
