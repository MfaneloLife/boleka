import { View, StyleSheet, Modal } from 'react-native';
import React from 'react';

const InvisibleLoader = ({visible}: {visible: boolean}) => {
    return (
        <View style={styles.centeredView}>
        <Modal visible = {visible} transparent={true}>
        <View style = {styles.centeredView}>
        </View>
        </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    Main:{
        display: 'flex',
        flexDirection: 'column',
        margin: 20,
        width: '95%',
        backgroundColor: "white",
        borderRadius: 20,
        padding: 12,
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22,
        marginHorizontal: 12
    }
});

export default InvisibleLoader;