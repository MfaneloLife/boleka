import { View, StyleSheet, Modal, ActivityIndicator } from 'react-native';
import React from 'react';

const Loader = ({visible}: {visible: boolean}) => {
    return (
        <View style={styles.centeredView}>
        <Modal visible = {visible} transparent={true}>
        <View style = {styles.centeredView}>
            <ActivityIndicator size = "large" color="#FFB200" />
        </View>
        </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    Main:{
        display: 'flex',
        flexDirection: 'column',
        margin: 20,
        width: '95%',
        backgroundColor: "white",
        borderRadius: 20,
        padding: 12,
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22,
        marginHorizontal: 12
    }
});

export default Loader;