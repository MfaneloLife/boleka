import { View, Text } from 'react-native';
import React from 'react';
import Empty from "../assets/empty-ist.svg";

const EmptyHolder = () => {
    return (
        <View style = {{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <Empty width={300} height={300}/>
        </View>
    );
}

export default EmptyHolder;