import React, {useState} from "react";
import { View, Modal, ScrollView, StyleSheet, Platform, } from "react-native";
import { Text, Appbar } from "react-native-paper";
import darkMode from '../theme/darkMode';

const Help = ({visible, setVisible, query}:{visible: boolean, setVisible: any, query:string})=>{
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    
    return(
        <Modal visible = {visible} animationType = 'slide'>
            <View style = {darkMode.Main}>
            <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
            <Appbar.Content title="Help" color = "#FFFFFF"/>
            <Appbar.Action icon="window-close" onPress={()=> setVisible(false)} color = "#FFFFFF"/>
            </Appbar.Header>
            <ScrollView>

            <View style = {styles.Container}>
            {query === "MyOrders" &&
            <>
            <Text variant="headlineSmall" style = {{color: "#FFF"}}>How it works</Text>
            <Text style = {{color: "gray"}}>Once you checkout your cart a request gets send to the vendor. It is up to the vendor to approve or decline your request, a request can be declined for a variety of reasons. If the order is approved you will be required to make a payment if you chose to pay with a card.</Text>

            <Text variant="titleSmall" style = {{color: "#FFF", marginTop: 12}}>Awaiting approval</Text>
            <Text style = {{color: "gray"}}>This is the initial step after you checkout your order. You are required to wait for the vendor to approve your order. If your order is not approved in about 3 days we will remove the order from the system.</Text>


            <Text variant="titleSmall" style = {{color: "#FFF", marginTop: 12}}>Awaiting payment</Text>
            <Text style = {{color: "gray"}}>This means your order has been approved and you are required to make a payment as soon as possible. You have to click the pay button that will direct you to the payment portal. If a payment is not received in about 3 days your order will be cancelled automatically.</Text>


            <Text variant="titleSmall" style = {{color: "#FFF", marginTop: 12}}>Cash payment</Text>
            <Text style = {{color: "gray"}}>This means your order has been approved and you will be required to make payment in person to the vendor.</Text>


            <Text variant="titleSmall" style = {{color: "#FFF", marginTop: 12}}>Payment received</Text>
            <Text style = {{color: "gray"}}>You have made a payment and has been verified.</Text>


            <Text variant="titleSmall" style = {{color: "#FFF", marginTop: 12}}>Scan button</Text>
            <Text style = {{color: "gray"}}>On the day of the service you are required to show the QR Code to the vendor to complete the order. Each QR Code generated expires in 120 seconds. It is advised not to share the QR Code before the day of the service delivery.</Text>

            </>
            }

            {query === "DeleteOrder" &&
            <>
             <Text variant="titleSmall" style = {{color: "#FFF", marginTop: 12}}>Deleting Services</Text>
            <Text style = {{color: "gray"}}>You can only delete a service if there are no orders placed for that particular service. If you are trying to delete a service and it has orders we will change it's visibility to hide it from clients.</Text>
            </>
            }

            <Text variant="titleSmall" style = {{color: "#FFF", marginTop: 12}}>For support</Text>
            <Text style = {{color: "gray"}}>Email support@eboleka.co.za</Text>
        
            </View>
            </ScrollView>
            </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    Container:{
       
        borderRadius: 10,
        marginHorizontal: 12,
        marginTop: 20,
        padding: 8
    },
    Title:{
        color: "#FFFFFF",
        marginBottom: 5
    },
    Radio:{
        flexDirection: 'row',
        alignItems: 'center'
    },
    Image:{
        minHeight: 100,
        width: '100%',
        marginBottom: 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    Input:{
        marginVertical: 5,
        //backgroundColor: "#282828", 
        fontWeight: '600',
    }
});

export default Help;
