import firebase from "firebase/compat/app";
import 'firebase/compat/auth';
import 'firebase/compat/storage';

const firebaseConfig = {
  apiKey: "AIzaSyB0zvc_zoYVxgJVJEBE9EmebFSEyz3SJ38",
  authDomain: "eboleka-3a6ee.firebaseapp.com",
  databaseURL: "https://eboleka-3a6ee-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "eboleka-3a6ee",
  storageBucket: "eboleka-3a6ee.appspot.com",
  messagingSenderId: "178481275672",
  appId: "1:178481275672:web:07408865d5faebac9bb46d",
  measurementId: "G-3P3X5XMCYF"
};


firebase.initializeApp(firebaseConfig);

export {firebase}