import React, {createContext, useState} from "react";
import axios, { AxiosError, AxiosResponse } from "axios";
import host from "../config/host.json";

export interface ClientDataInterface{
    stores: Array<any>
    services: Array<any>
    loadingExplore: boolean
    getExplore: Function
    loadingCart: boolean
    cart: Array<any>
    setCart: any
    getCart: Function
    orders: Array<any>
    loadingOrders: boolean
    getOrders: Function
    setOrders: Function
    initializeClientData: Function
    getNotifications: Function
    notifications: Array<any>
    loadingNotifications: boolean
    resetExplore: Function
    searchLoading: Boolean
    searchProducts: Array<any>
    onSearchProducts: Function
}

export const ClientDataContext = createContext<ClientDataInterface | null>(null);

const ClientDataContextProvider = (props:any)=>{
    const url = host.url;

    //Explore 
    const [stores, setStores] = useState<Array<any>>([]);
    const [services, setServices] = useState<Array<any>>([]);
    const [loadingExplore, setLoadingExplore] = useState<boolean>(false);

    const getExplore = async(token:string)=>{
        setLoadingExplore(true);
        await axios.post(`${url}/explore/`,  {
            products: getIds(services),
            businesses: getIds(stores)
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            let serviceArr:Array<any> = services.concat(response.data.data.products);
            let storeArr:Array<any> = stores.concat(response.data.data.businesses);

            setServices(serviceArr);
            setStores(storeArr);
            
            setLoadingExplore(false);
        }).catch((reason: AxiosError)=>{
            setLoadingExplore(false);
        });
    }

    function getIds(list: Array<any>):Array<string>{
        let ids:Array<string> = new Array();

        for(let i = 0; i < list.length; i++){
            ids.push(list[i].uid);
        }

        return ids;
    }

    const resetExplore = async(token:string)=>{
        setLoadingExplore(true);
        await axios.post(`${url}/explore/`,  {
            products: [],
            businesses: []
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setServices(response.data.data.products);
            setStores(response.data.data.businesses);
            setLoadingExplore(false);
        }).catch((reason: AxiosError)=>{
            setLoadingExplore(false);
        });
    }


    // CART
    const [cart, setCart] = useState<Array<any>>([]);
    const [loadingCart, setLoadingCart] = useState<boolean>(false);

    const getCart = async(uid: string, token:string)=>{
        setLoadingCart(true);
        await axios.get(`${url}/cart`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setCart(response.data.data);
            setLoadingCart(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setLoadingCart(false);
        });
    }

    // ORDERS
    const [orders, setOrders] = useState<Array<any>>([]);
    const [loadingOrders, setLoadingOrders] = useState<boolean>(false);

    const getOrders = async(uid: string, token:string)=>{
        setLoadingOrders(true);
        await axios.get(`${url}/order/`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setOrders(response.data.data);
            setLoadingOrders(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setLoadingOrders(false);
        });
    }

    //  Notifications

    const [notifications, setNotifications] = useState<Array<any>>([]);
    const [loadingNotifications, setLoadingNotifications] = useState<boolean>(false);

    const getNotifications = async(uid: string, token:string)=>{
        setLoadingNotifications(true);
        await axios.get(`${url}/notifications/`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setNotifications(response.data.data);
            setLoadingNotifications(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setLoadingNotifications(false);
        });
    }


    const initializeClientData = (userID: string, token:string)=>{
        getExplore(token);
        getCart(userID, token);
        getOrders(userID, token);
        getNotifications(userID, token);
    }

    // Search 
    const [searchLoading, setSearchLoading] = useState<boolean>(false);
    const [searchProducts, setSearchProducts] = useState<Array<any>>([]);

    const onSearchProducts = async(query: string, token:string)=>{
        setSearchLoading(true);
        setSearchProducts([]);
        await axios.post(`${url}/search/`, {
            item: query
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setSearchProducts(response.data.data);
            setSearchLoading(false);
        }).catch((reason: AxiosError)=>{
            setSearchLoading(false);
        });
    } 
    
    return(
        <ClientDataContext.Provider value={{
            services, stores, loadingExplore, 
            getExplore, getCart, cart, loadingCart, 
            setCart, orders, loadingOrders, getOrders, 
            setOrders, initializeClientData, resetExplore,
            getNotifications, notifications, loadingNotifications,
            searchProducts, searchLoading, onSearchProducts
            }}>
            {props.children}
        </ClientDataContext.Provider>
    );
}

export default ClientDataContextProvider;
