import React, {createContext, useState} from "react";
import axios, {AxiosResponse, AxiosError} from "axios";
import host from "../config/host.json";

export interface AccountInterface{
    name: string
    email: string
    token: string
    userID: string
    isBusiness: boolean
    removeUser: Function
    initialiseUser: Function
    imageUrl: string|null 
    street: string 
    suburb: string
    code: string
    city: string
    about: string
    phone:string
    updateProfile: Function
    getProfile: Function
    setToken: Function
    cardIncome: string
    cashIncome: string
    payoutDate: string 
    ordersCompleted: string
    getWallet: Function
}

export const AccountContext = createContext<AccountInterface | null>(null);

const AccountContextProvider = (props:any)=>{
    const url = host.url;

    const [name, setName] = useState<string>('');
    const [email, setEmail] = useState<string>('');
    const [token, setToken] = useState<string>('');
    const [userID, setUserID] = useState<string>('');
    const [isBusiness, setIsBusiness] = useState<boolean>(false);

    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [about, setAbout] = useState<string>("");
    const [phone, setPhone] = useState<string>("");

    const [street, setStreet] = useState<string>("");
    const [suburb, setSuburb] = useState<string>("");
    const [city, setCity] = useState<string>("");
    const [code, setCode] = useState<string>("");

    const [cardIncome, setCardIncome] = useState<string>("0");
    const [cashIncome, setCashIncome] = useState<string>("0");
    const [payoutDate, setPayoutDate] = useState<string>("");
    const [ordersCompleted, setOrdersCompleted] = useState<string>("0");

    const initialiseUser = (userID: string, email: string, name: string, isBusiness: boolean, token: string)=>{
        setName(name);
        setEmail(email);
        setToken(token);
        setUserID(userID);
        setIsBusiness(isBusiness);
    }

    const updateProfile = (imageUrl: string|null, street: string, suburb: string, city: string, code: string, about:string, phone:string)=>{
        setImageUrl(imageUrl);
        setStreet(street);
        setSuburb(suburb);
        setCity(city);
        setCode(code);
        setAbout(about);
        setPhone(phone);
    }

    const removeUser = ()=>{
        setName('');
        setEmail('');
        setUserID('');
        setIsBusiness(false);
    }

    const getProfile = async(token:string)=>{
        await axios.get(`${url}/profile/me`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            const data = response.data.data;

            const about = data.about;
            const imageUrl = data.imageUrl;

            updateProfile(imageUrl, data.street, data.suburb, data.city, data.code, about, data.phone);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
        });
    }

    const getWallet = async(token:string)=>{
        await axios.get(`${url}/transaction/wallet`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            const data = response.data;
            setCardIncome(data.cardIncome);
            setCashIncome(data.cashIncome);
            setPayoutDate(data.date);
            setOrdersCompleted(data.orders);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
        });
    }

    return(
        <AccountContext.Provider value={{
            name, email, userID, isBusiness, 
            initialiseUser, removeUser, token,
            imageUrl, street, code, city, suburb, 
            phone, updateProfile, about, getProfile, setToken,
            cardIncome, cashIncome, payoutDate, ordersCompleted, getWallet
            }}>
            {props.children}
        </AccountContext.Provider>
    );
}

export default AccountContextProvider;
