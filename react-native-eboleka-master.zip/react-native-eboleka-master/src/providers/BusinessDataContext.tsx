import React, {createContext, useState} from "react";
import axios, { AxiosError, AxiosResponse } from "axios";
import host from "../config/host.json";

export interface DataInterface{
    services: Array<any>
    setServices: any
    loadingServices: boolean
    getServices: Function
    requests: Array<any>
    loadingRequests: boolean
    getRequests: Function
    setRequests: Function
    orders: Array<any>
    setOrders: Function
    updateOrder: Function
    loadingOrders: boolean
    getOrders: Function
    initializeBusinessData: Function
    getNotifications: Function
    notifications: Array<any>
    loadingNotifications: boolean
}

export const BusinessDataContext = createContext<DataInterface | null>(null);

const BusinessDataContextProvider = (props:any)=>{
    const url = host.url;

    //SERVICES
    const [services, setServices] = useState([]);
    const [loadingServices, setLoadingServices] = useState<boolean>(false);

    const initializeBusinessData = (userID: string, token:string)=>{
        getOrders(userID, token);
        getServices(userID, token);
        getRequests(userID, token);
        getNotifications(userID, token);
    }

    const getServices = async(userID: string, token:string)=>{
        setLoadingServices(true);
        await axios.get(`${url}/product/?id=${userID}`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setServices(response.data.products);
            setLoadingServices(false);
        }).catch((reason: AxiosError)=>{
            setLoadingServices(false);
            console.log(reason);
        });
    }

    // REQUESTS
    const [requests, setRequests] = useState<Array<any>>([]);
    const [loadingRequests, setLoadingRequests] = useState<boolean>(false);

    const getRequests = async(userID: string, token:string)=>{
        setLoadingRequests(true);
        await axios.get(`${url}/order/requests/`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setRequests(response.data.data);
            setLoadingRequests(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setLoadingRequests(false);
        });
    }

    //ORDERS
    const [orders, setOrders] = useState<Array<any>>([]);
    const [loadingOrders, setLoadingOrders] = useState<boolean>(false);

    const updateOrder =(list: Array<any>)=>{
        setOrders(list);
    }

    const getOrders = async(userID: string, token:string)=>{
        setLoadingOrders(true);
        await axios.get(`${url}/order/approved/`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setOrders(response.data.data);
            setLoadingOrders(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setLoadingOrders(false);
        });
    }

    // Notifications

    const [notifications, setNotifications] = useState<Array<any>>([]);
    const [loadingNotifications, setLoadingNotifications] = useState<boolean>(false);

    const getNotifications = async(uid: string, token:string)=>{
        setLoadingNotifications(true);
        await axios.get(`${url}/notifications/`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setNotifications(response.data.data);
            setLoadingNotifications(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
            setLoadingNotifications(false);
        });
    }

    return(
        <BusinessDataContext.Provider value={{
            getServices, loadingServices, 
            services, setServices, requests, getRequests, 
            loadingRequests, setRequests, setOrders,
            orders, getOrders, loadingOrders,
            initializeBusinessData, updateOrder,
            getNotifications, notifications, loadingNotifications
            }}>
            {props.children}
        </BusinessDataContext.Provider>
    );
}

export default BusinessDataContextProvider;
