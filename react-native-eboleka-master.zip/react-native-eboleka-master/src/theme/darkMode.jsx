import React from "react";
import { StyleSheet } from "react-native";

export default darkMode = StyleSheet.create({
    Main: {
        display: 'flex',
        flexDirection: 'column',
        flex: 1, 
        backgroundColor: '#121212'
    },
    Title:{
        color: '#FFFFFF',
        fontSize: 40,
        fontWeight: 'bold',
    },
    PrimaryColour:{
        color: '#FFFFFF'
    },
    Background:{
        color: '#121212'
    },
    HeaderColour:{
        color: '#282828'
    },
});

