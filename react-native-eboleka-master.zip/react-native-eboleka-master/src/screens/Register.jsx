import { View, SafeAreaView, Keyboard, TouchableOpacity } from 'react-native';
import React, {useState, useContext} from 'react';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import Input from '../components/Input';
import RegisterSVG from "../assets/register-ist.svg";
import { Button, Text } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import InvisibleLoader from '../utils/InvisibleLoader';
import { Switch, Snackbar } from 'react-native-paper';
import axios from "react-native-axios";
import host from "../config/host.json";

const Register = ({navigation}) => {
    const url = host.url;
    const [isBusiness, setBusiness] = useState(false);

    let displayName = isBusiness ? "Enter your business name" : "Enter your name";

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');

    const [loading, setLoading] = useState(false);
    const [toast, setToast] = useState('');
    const [showSnackbar, setShowSnackbar] = useState(false);

    const onDismissSnackBar = () =>{
        setLoading(false);
        setShowSnackbar(false);
        if(toast == 'Account created'){
            setToast('');
            navigation.replace('Login');
        }else{
            setToast('');
        }
    }

    const [errors, setErrors] = useState({});

    const handleError = (error, input) => {
        setErrors(prevState => ({...prevState, [input]: error}));
    };

    const onChangePhone = (text)=>{
        let update = true;
        const numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

        for(let i = 0; i < text.length; i++){
            const curr = text[i];

            if(update){
                let found = false;
                for(let j = 0; j < numbers.length; j++){
                    const currNum = numbers[j];

                    if(curr == currNum){
                        found = true;
                    }
                }

                if(!found){
                    update = false;
                }
            }

        }

        if(update){
            setPhone(text);
        }
    }

    const validate = async () => {
        Keyboard.dismiss();
        let isValid = true;
        if(email.trim() == '') {
          handleError('Please input email', 'email');
          isValid = false;
        }else if(!String(email).toLowerCase().match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)){
            handleError('Email format not valid', 'email');
            isValid = false;
        }

        if (password.trim() == '') {
          handleError('Please input password', 'password');
          isValid = false;
        }else if(password.trim().length <= 6){
            handleError('Password length should be at least 7 characters long', 'password');
            isValid = false;
        }

        if(name.trim() == ''){
            handleError('Please input display name', 'name');
            isValid = false;
        }

        if(phone.trim() == ''){
            handleError('Please input phone number', 'phone');
            isValid = false;
        }else if(!String(phone).match(/^((06)|(07)|(08))[0-9]{8}$/)){
            handleError('Please input valid phone number', 'phone');
            isValid = false;
        }

        if (isValid) {
            onRegister();
        }
    };

    const onRegister = async()=>{
        setLoading(true);
        await axios.post(`${url}/account/register`, {
            name: name.trim(),
            phone: phone,
            isBusiness: isBusiness,
            password: password.trim(),
            email: email.toLowerCase().trim(),
        }).then((response)=>{
            setToast('Account created');
            clearAll();
            setShowSnackbar(true);
        }).catch((reason)=>{
            if (reason.response.status === 400 && reason.response.data.status === "EXISTS") {
                setToast('Account Exists');
                clearAll();
            }else if(reason.response.status === 400 && reason.response.data.status === "INVALID"){
                setToast('Invalid Input');
                clearAll();
            }else {
                setToast('Failed, Try Again Later');
            }
            setShowSnackbar(true);
        });
    }

    const clearAll = ()=>{
        setEmail('');
        setName('');
        setPassword('');
        setPhone('');
    }

    return (
        <SafeAreaView style = {darkMode.Main}>
            <KeyboardAwareScrollView>
            <View style = {{paddingHorizontal: 12}}>

            <View style ={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
            <Text style = {{color: 'gray', marginVertical: 10, fontSize: 18}}>Create business account</Text>
            <Switch value={isBusiness} color='orange' onValueChange={()=> setBusiness(!isBusiness)}/>
            </View>

            <View style = {{justifyContent: 'center', alignItems: 'center'}}>
            <RegisterSVG width = {300} height = {300}/>
            </View>

            <Text style = {darkMode.Title}>Register</Text>

            {isBusiness ?
                <Text style = {{color: 'gray', marginVertical: 10, fontSize: 18}}>Business Account</Text>
                :
                <Text style = {{color: 'gray', marginVertical: 10, fontSize: 18}}>Personal Account</Text>
            }

            <Input
                onChangeText={(text)=> setEmail(text)}
                onFocus={() => handleError(null, 'email')}
                iconName="email-outline"
                label="Email"
                placeholder="Enter your email address"
                error={errors.email}
                value = {email}
                maxLength = {45}
            />

            <Input
                onChangeText={(text)=> setName(text)}
                onFocus={() => handleError(null, 'name')}
                iconName="account-outline"
                label="Display Name"
                placeholder= {displayName}
                error={errors.name}
                value = {name}
                maxLength = {45}
            />

            <Input
                onChangeText={(text)=> onChangePhone(text)}
                onFocus={() => handleError(null, 'phone')}
                iconName="phone-outline"
                label="Phone Number"
                placeholder="Enter your phone number"
                error={errors.phone}
                value = {phone}
                maxLength = {10}
                keyboardType = 'decimal-pad'
            />

            <Input
                onChangeText={(text)=> setPassword(text)}
                onFocus={() => handleError(null, 'password')}
                iconName="lock-outline"
                label="Password" 
                placeholder="Enter your password"
                error={errors.password}
                password
                value = {password}
                maxLength = {20}
            />

            <Button loading = {loading ? (toast == '' ? true : false) : false} mode = "contained" buttonColor='#FFB200' style = {{marginVertical: 12, fontWeight: 'bold', borderRadius:  5}} onPress={()=> validate()}>Register</Button>

            <View style = {{flexDirection: 'row', justifyContent:  'center'}}>
            <Text style = {{color: 'gray'}}>Already have an account? </Text>
            <TouchableOpacity onPress={()=> navigation.replace('Login')}>
            <Text style = {{color: 'gray', fontWeight: 'bold'}}>Sign In</Text>
            </TouchableOpacity>
            </View>

            </View>
            <InvisibleLoader visible = {loading}/>
            </KeyboardAwareScrollView>
            <Snackbar duration={2500} visible={showSnackbar} onDismiss={onDismissSnackBar} style={{backgroundColor: '#282828'}}>{toast}</Snackbar>
        </SafeAreaView>
    );
}

export default Register