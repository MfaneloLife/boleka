import { View, Platform, ScrollView, StyleSheet, Image, TouchableOpacity} from 'react-native'
import React, {useContext, useState, useEffect} from 'react'
import darkMode from '../theme/darkMode';
import { Appbar, Text, Snackbar, Button} from 'react-native-paper';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import host from "../config/host.json";
import axios, { AxiosError, AxiosResponse } from 'axios';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import { WebView } from 'react-native-webview';

const Payment = ({navigation, route}: {navigation: any, route: any}) => {
    const url = host.url_payments;
    const {token} = route.params;
    const {isBusiness, userID} = useContext(AccountContext) as AccountInterface;
    const {setCart, cart} = useContext(ClientDataContext) as ClientDataInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title="Payment" />
            </Appbar.Header>

            {/* <WebView source={{uri:`${url}/${token}` }}/> */}
        </View>
    );
}

const styles = StyleSheet.create({
    
});

export default Payment;