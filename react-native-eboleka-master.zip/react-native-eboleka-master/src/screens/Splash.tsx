import { View, Text, SafeAreaView, StyleSheet, Image, Platform } from 'react-native'
import React, {useState, useEffect, useContext} from 'react';
import * as SecureStore from 'expo-secure-store';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import { BusinessDataContext,  DataInterface } from '../providers/BusinessDataContext';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import { Dialog, Portal, Provider, Button, Snackbar } from 'react-native-paper';
import * as Location from 'expo-location';
import axios, { AxiosError, AxiosResponse } from 'axios';
import host from "../config/host.json";

export default function Splash({navigation}: {navigation: any}) {
    const url = host.url;
    const {initialiseUser, updateProfile, setToken, getWallet} = useContext(AccountContext) as AccountInterface;
    const {initializeBusinessData} = useContext(BusinessDataContext) as DataInterface;
    const {initializeClientData} = useContext(ClientDataContext) as ClientDataInterface;


    const [visible, setVisible] = useState<boolean>(false);
    const[isOffline, setIsOffile] = useState<boolean>(false);

    const messageIos:string = "Open the Settings app on your device\nScroll down and tap on Privacy\nSelect Location Services\nFind our app in the list and tap on it\nChoose While Using the App to grant location access.";
    const messageAndroid:string = "Open the Settings app on your device\nScroll down and tap on Apps & notifications\nSelect our app from the list\nTap on Permissions\nEnable the toggle next to Location.";

    const message:string = Platform.OS === "android" ? messageAndroid : messageIos; 
    const [showSnackbar, setShowSnackbar] = useState<boolean>(false);

    useEffect(()=>{
        getLocation();
    }, []);

    const getLocation = async()=>{
        await Location.requestForegroundPermissionsAsync()
        .then((data)=>{
            if(data.granted){
                setVisible(false);
                initApp();
            }else{
                setVisible(true);
                return;
            }
        }).catch((err)=>{
            console.log(err);
            setVisible(true);
            return;
        });
    }

    const onDismissSnackBar = async() =>{
        await SecureStore.deleteItemAsync('userID');
        await SecureStore.deleteItemAsync('name');
        await SecureStore.deleteItemAsync('email');
        await SecureStore.deleteItemAsync('phone');
        await SecureStore.deleteItemAsync('deviceId');
        await SecureStore.deleteItemAsync('token');
        await SecureStore.deleteItemAsync('timestamp');
        await SecureStore.deleteItemAsync('isBusiness');

        setTimeout(()=>{
            setShowSnackbar(false);
            navigation.replace('Login');
        }, 2500);
    }

    const refreshForTimer = async(tk:string, id:string)=>{
        await axios.post(`${url}/account/refresh`, {
            uid: tk,
            deviceId: id
        }).then((response: AxiosResponse)=>{
            let timestamp:string = String(new Date());
            SecureStore.setItemAsync('timestamp', timestamp);

            const token = response.data.token;
            SecureStore.setItemAsync('token', token);
            setToken(token);

            keepTimer(token, id);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
        });
    }

    const refreshToken = async(store:any)=>{
        await axios.post(`${url}/account/refresh`, {
            uid: store.token,
            deviceId: store.deviceId
        }).then((response: AxiosResponse)=>{
            let timestamp:string = String(new Date());
            SecureStore.setItemAsync('timestamp', timestamp);

            const token = response.data.token;
            SecureStore.setItemAsync('token', token);
            getProfile(store, token);
        }).catch((reason: AxiosError)=>{
            if (reason.response!.status === 400){
                setShowSnackbar(true);
            }else{
                setIsOffile(true);
            }
            console.log(reason);
        });
    }

    const getProfile = async(store:any, token:string)=>{
        await axios.get(`${url}/profile/me`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            const data = response.data.data;

            const uid = data.uid;
            const email = data.email;
            const about = data.about;
            const imageUrl = data.imageUrl;

            initialiseUser(uid, email, store.name, store.isBusiness, token);
            getWallet(token);
            updateProfile(imageUrl, data.street, data.suburb, data.city, data.code, about, data.phone);
            accountFound(uid, store.isBusiness, token, store.deviceId);

        }).catch((reason: AxiosError)=>{
            if (reason.response!.status === 400){
                setShowSnackbar(true);
            }else if(reason.response!.status === 401){
                setShowSnackbar(true);
            }else{
                setIsOffile(true);
            }
            console.log(reason);
        })
    }

    const checkToken = (timestamp:number, store:any)=>{
        const now:any = new Date();
        const difference = Math.abs((now - timestamp) / 1000);

        if(difference >= 3900){
            refreshToken(store);
        }else{
            getProfile(store, store.token);
        }
    }

    const initApp = async()=>{
        const userID = await SecureStore.getItemAsync('userID');
        if(userID){
            const name = await SecureStore.getItemAsync('name');
            const email = await SecureStore.getItemAsync('email');
            const token = await SecureStore.getItemAsync('token');
            const isBusiness = await SecureStore.getItemAsync('isBusiness');
            const timestamp = await SecureStore.getItemAsync('timestamp');
            const deviceId = await SecureStore.getItemAsync('deviceId');

            const business = isBusiness?.toLocaleLowerCase() === "true" ? true : false;

            const store = {
                userID: userID,
                name: name,
                email: email,
                token: token,
                deviceId: deviceId,
                isBusiness: business
            }

            checkToken(Date.parse(timestamp!), store);

        }else{
                accountNotFound();
        }
    }

    const accountFound = (userID: string, isBusiness: boolean, token:any, deviceId:string)=>{
        if(isBusiness){
            initializeBusinessData(userID, token);
        }else{
            initializeClientData(userID, token);
        }
        setTimeout(()=>{
            navigation.replace('Home', {isBusiness: isBusiness});
            keepTimer(token, deviceId);
        }, 3500);
    }

    const keepTimer = (token:string, deviceId:string)=>{
        setTimeout(() => {
            refreshForTimer(token, deviceId);
        }, 4140000);
    }

    const accountNotFound = ()=>{
        setTimeout(()=>{
            navigation.replace('Login');
        }, 2500);
    }

    return (
        <Provider>
            <Portal>
                <SafeAreaView style = {styles.Main}>
                    <Image source={require('../assets/logo.png')} style = {{width: 100, height: 103}}/>
                    <Text style = {styles.Title}>Eboleka</Text>
                    <Text style = {styles.Bottom}>{`v1.0.0`}</Text>

                    <Dialog visible={visible} dismissable = {false}>
                        <Dialog.Icon icon="map-marker" />
                        <Dialog.Title style={{}}>Location Access</Dialog.Title>
                        <Dialog.Content>
                        <Text>{message}</Text>
                        </Dialog.Content>
                    </Dialog>

                    <Dialog visible={isOffline} dismissable = {false}>
                        <Dialog.Icon icon="wifi-off" />
                        <Dialog.Title style={{}}>Internet Access</Dialog.Title>
                        <Dialog.Content>
                        <Text>You're offline. Check your connection</Text>
                        </Dialog.Content>
                        <Dialog.Actions>
                        <Button onPress={()=> {}}>Try Again</Button>
                        </Dialog.Actions>
                    </Dialog>

                    <Snackbar duration={2500} visible={showSnackbar} onDismiss={onDismissSnackBar} style={{backgroundColor: '#282828'}}>Session Suspended</Snackbar>
                </SafeAreaView>
            </Portal>
        </Provider>
    );
}

const styles = StyleSheet.create({
    Main:{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1, 
        backgroundColor: '#121212'
    },
    Title:{
        color: 'rgba(255, 255, 255, 0.7)',
        fontSize: 30,
        fontWeight: 'bold'
    },
    Bottom:{
        color: '#B3B3B3',
        position: 'absolute',
        bottom: 20,
        fontSize: 11
    }
});