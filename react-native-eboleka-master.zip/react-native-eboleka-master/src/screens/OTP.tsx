import { View, Platform, Keyboard, ActivityIndicator } from 'react-native'
import React, {useState, useContext} from 'react'
import { Appbar, Text, TextInput, Snackbar } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import InvisibleLoader from '../utils/InvisibleLoader';
import host from "../config/host.json";
import axios, { AxiosError, AxiosResponse } from 'axios';
import * as SecureStore from 'expo-secure-store';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import { BusinessDataContext,  DataInterface } from '../providers/BusinessDataContext';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import * as Device from 'expo-device';
import uuid from 'react-native-uuid';

const OTP = ({navigation, route}: {navigation: any, route: any}) => {
    const url = host.url;
    const {user} = route.params;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const numbers: Array<string> = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

    const {initialiseUser, getProfile, getWallet} = useContext(AccountContext) as AccountInterface;
    const {initializeBusinessData} = useContext(BusinessDataContext) as DataInterface;
    const {initializeClientData} = useContext(ClientDataContext) as ClientDataInterface;

    const [loading, setLoading] = useState<boolean>(false);
    const [value, setValue] = useState<string>('');

    const [toast, setToast] = useState<string>('');
    const [showSnackbar, setShowSnackbar] = useState<boolean>(false);

    const onDismissSnackBar = () =>{
        setShowSnackbar(false);
    }

    const onChangeOTP = (text: string)=>{
        let valid = true;
        for(let i = 0; i < text.length; i++){
            if(!numbers.includes(text[i])){
                valid = false;
                break;
            }
        }

        if(valid){
            setValue(text);
            if(text.length == 8){
                Keyboard.dismiss();
                setLoading(true);
                onCheckOTP(text);
            }
        }
    }

    const storeUser =async(token:string, deviceId:string)=>{
        setShowSnackbar(true);
        getProfile(token);

        let timestamp:string = String(new Date());

        SecureStore.setItemAsync('deviceId', deviceId);
        SecureStore.setItemAsync('token', token);
        SecureStore.setItemAsync('userID', user.uid);
        SecureStore.setItemAsync('email', user.email);
        SecureStore.setItemAsync('name', user.name);
        SecureStore.setItemAsync('phone', user.phone);
        SecureStore.setItemAsync('isBusiness', user.isBusiness);
        SecureStore.setItemAsync('timestamp', timestamp);

        const isBusiness:boolean = user.isBusiness === "true" ? true : false;

        initialiseUser(user.uid, user.email, user.name, isBusiness, token);
        getWallet(token);

        if(isBusiness){
            initializeBusinessData(user.uid, token);
        }else{
            initializeClientData(user.uid, token);
        }

        setTimeout(()=>{
            setLoading(false);
            navigation.replace('Home', {isBusiness: isBusiness});
        }, 3500);
    }

    const onCheckOTP =async(code: string)=>{
        const deviceId:string = String(uuid.v4());
        const device:string = `${Device.brand} ${Device.modelName} running ${Device.osName} ${Device.osVersion}`;

        await axios.post(`${url}/account/otp`, {
            uid: user.uid,
            otp: code,
            device: device,
            deviceId: deviceId
        }).then((response: AxiosResponse)=>{
            const token: string = response.data.token;
            setToast('Saving Account');
            storeUser(token, deviceId);
            setShowSnackbar(true);
            setValue('');
            setLoading(false);
        }).catch((reason: AxiosError)=>{
            if (reason.response!.status === 400) {
                const data: any = reason.response?.data;
                if(data !== undefined){
                    const status:string = data.status;

                    if(status === "TIMEOUT"){
                        setToast('OTP Limit Reached. Try Again Tomorrow');
                    }

                    if(status === "EXPIRED"){
                        setToast('OTP Expired');
                    }

                    if(status === "INVALID"){
                        setToast('Invalid OTP');
                    }

                }else{
                    setToast('Failed, Try Again Later');
                }
            } else {
                setToast('Failed, Try Again Later');
            }
            setShowSnackbar(true);
            setValue('');
            setLoading(false);
        });
    }

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title="OTP" />
            </Appbar.Header>

            <View style = {{paddingHorizontal: 12, marginTop: 20}}>
            
            <Text variant="labelLarge" style = {{color: "#FFF"}}>An OTP has been sent to {user.email}. Please check your inbox and enter the code below to continue.</Text>

            <TextInput
            value={value}
            textColor='#FFF'
            activeOutlineColor='#FFB200'
            activeUnderlineColor='white'
            label="OTP"
            maxLength={8}
            keyboardType="numeric"
            style = {{marginTop: 20, marginBottom: 50, backgroundColor: "#282828", fontWeight: '600'}}
            onChangeText={(text)=> onChangeOTP(text)}
            />

            {loading &&
                <ActivityIndicator color="#FFFFFF" size='large' />
            }

            </View>
            <InvisibleLoader visible = {loading}/>
            <Snackbar duration={2500} visible={showSnackbar} onDismiss={onDismissSnackBar} style={{backgroundColor: '#282828'}}>{toast}</Snackbar>
        </View>
    );
}

export default OTP;