import { View, SafeAreaView, Keyboard, TouchableOpacity } from 'react-native';
import React, {useState, useContext, useEffect} from 'react';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import Input from '../components/Input';
import LoginSVG from "../assets/login-ist.svg";
import { Button, Text, Snackbar } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import InvisibleLoader from '../utils/InvisibleLoader';
import axios from "react-native-axios";
import host from "../config/host.json";

const Login = ({navigation}) => {
    const url = host.url;
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({});

    const [toast, setToast] = useState('');
    const [showSnackbar, setShowSnackbar] = useState(false);

    const onDismissSnackBar = () =>{
        setShowSnackbar(false);
    }

    const validate = async () => {
        Keyboard.dismiss();
        let isValid = true;
        if(email.trim() == '') {
          handleError('Please input email', 'email');
          isValid = false;
        }else if(!String(email).toLowerCase().match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)){
            handleError('Email format not valid', 'email');
            isValid = false;
        }

        if (password.trim() == '') {
          handleError('Please input password', 'password');
          isValid = false;
        }else if(password.trim().length <= 6){
            handleError('Password length should be at least 7 characters long', 'password');
            isValid = false;
        }

        if (isValid) {
            onSignIn();
        }
      };

    const handleError = (error, input) => {
    setErrors(prevState => ({...prevState, [input]: error}));
    };

    const onSignIn = async()=>{
        setLoading(true);
        await axios.post(`${url}/account/signin`, {
            password: password.trim(),
            email: email.toLowerCase().trim()
        }).then((response)=>{
            console.log(response.data);
            setPassword('');
            setLoading(false);
            navigation.navigate('OTP', {user: response.data});
        }).catch((reason)=>{
            if (reason.response.status === 400) {
                setToast('Incorrect Credentials');
                setPassword('');
            } else {
                setPassword('');
                setToast('Failed, Try Again Later');
            }
            setShowSnackbar(true);
            setLoading(false);
        });
    }

    return (
        <SafeAreaView style = {darkMode.Main}>
            <KeyboardAwareScrollView>
                <View style = {{paddingHorizontal: 12}}>
                <View style = {{justifyContent: 'center', alignItems: 'center'}}>
                <LoginSVG width = {300} height = {300}/>
                </View>
                <Text style = {darkMode.Title}>Sign In</Text>
                <Text style = {{color: 'gray', marginVertical: 10, fontSize: 18}}>Welcome back</Text>
                <Input
                    onChangeText={(text)=> setEmail(text)}
                    onFocus={() => handleError(null, 'email')}
                    iconName="email-outline"
                    label="Email"
                    placeholder="Enter your email address"
                    error={errors.email}
                    password={false}
                    value = {email}
                    maxLength = {45}
                />

                <Input
                    onChangeText={(text)=> setPassword(text)}
                    onFocus={() => handleError(null, 'password')}
                    iconName="lock-outline"
                    label="Password"
                    placeholder="Enter your password"
                    error={errors.password}
                    password = {true}
                    value = {password}
                    maxLength = {20}
                />

                <View style = {{flexDirection: 'row', justifyContent: 'flex-end'}}>
                <TouchableOpacity onPress={()=> navigation.navigate('ResetPassword')}>
                <Text style = {{color: 'gray'}}>Forgotten password?</Text>
                </TouchableOpacity>
                </View>

                <Button loading = {loading} mode = "contained" buttonColor='#FFB200' style = {{marginVertical: 12, fontWeight: 'bold', borderRadius:  5}} onPress={()=> validate()}>Sign In</Button>

                <View style = {{flexDirection: 'row', justifyContent:  'center'}}>
                <Text style = {{color: 'gray'}} >Don't have an account? </Text>
                <TouchableOpacity onPress={()=> navigation.replace('Register')}>
                <Text style = {{color: 'gray', fontWeight: 'bold'}}>Register</Text>
                </TouchableOpacity>
                </View>
                </View>
                <InvisibleLoader visible = {loading}/>
                </KeyboardAwareScrollView>
                <Snackbar duration={2500} visible={showSnackbar} onDismiss={onDismissSnackBar} style={{backgroundColor: '#282828'}}>{toast}</Snackbar>
    </SafeAreaView>
  );
}

export default Login