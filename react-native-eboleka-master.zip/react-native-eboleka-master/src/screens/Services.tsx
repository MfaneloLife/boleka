import { View, Text, SafeAreaView, ScrollView, ActivityIndicator, RefreshControl, Platform, StyleSheet } from 'react-native';
import React, {useContext, useState} from 'react';
import { Appbar, FAB } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import EmptyHolder from '../utils/EmptyHolder';
import Addservice from '../components/AddService';
import ServicesSkeleton from '../components/ServicesSkeleton';
import { BusinessDataContext, DataInterface } from '../providers/BusinessDataContext';
import ServiceCard from '../components/ServiceCard';
import { AccountContext, AccountInterface } from '../providers/AccountContext';


const Services = ({navigation}:{navigation: any}) => {
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {token, userID} = useContext(AccountContext) as AccountInterface;
    const {loadingServices, services, getServices} = useContext(BusinessDataContext) as DataInterface;

    const [showAddModal, setShowAddModal] = useState(false);
    const loaderArray: Array<number> = [1, 2, 3, 4, 5, 6];

    const onRefresh = ()=> {
        getServices(userID, token);
    }

    return (
        <View style = {darkMode.Main}>
        <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
        <Appbar.Content title="My Services" color = "#FFFFFF"/>
        <Appbar.Action icon="bell" onPress={()=> {navigation.navigate("NotificationsX")}} color = '#FFB200' />
        
        </Appbar.Header>

        {loadingServices &&
        <ScrollView>
        <View style = {{display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', flexDirection: 'row'}}>
        {loaderArray.map((value, index)=>
        <ServicesSkeleton 
        key={index}
        />
        )}
        </View>
        </ScrollView>
        }

        {!loadingServices && services.length == 0 && 
        <EmptyHolder />
        }

        {!loadingServices && services.length != 0 &&
            <ScrollView refreshControl={<RefreshControl tintColor="#FFF" refreshing={loadingServices} onRefresh={onRefresh} />}>
                <View style = {{display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', flexDirection: 'row', marginBottom: 60}}>
                {services.map((item, index)=>
                <ServiceCard 
                service={item} 
                navigation={navigation} 
                key={index}/>
                )}
                </View>
            </ScrollView>
        }

        
        <FAB
        disabled = {services.length >= 30}
        icon="plus"
        color= "#282828"
        style={styles.fab}
        onPress={() => loadingServices? {} : setShowAddModal(true)}
        />

        <Addservice setVisible={setShowAddModal} visible = {showAddModal}/>
        </View>
    );
}

const styles = StyleSheet.create({
    fab: {
        backgroundColor: '#FFB200',
        position: 'absolute',
        margin: 16,
        right: 0,
        bottom: 0,
    },
})

export default Services;