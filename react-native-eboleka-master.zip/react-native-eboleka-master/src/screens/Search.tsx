import { View, Platform, Keyboard, ActivityIndicator, ScrollView } from 'react-native'
import React, {useState, useContext} from 'react'
import { Appbar, Text, TextInput, Snackbar } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import host from "../config/host.json";
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import ServiceCard from '../components/ServiceCard';

const Search = ({navigation, route}: {navigation: any, route: any}) => {
    const url = host.url;
    const {query} = route.params;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {searchLoading, searchProducts} = useContext(ClientDataContext) as ClientDataInterface;


    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title={query}/>
            </Appbar.Header>

            {searchLoading &&
            <View style = {{marginTop: 20}}>
                <ActivityIndicator color="#FFFFFF" size='large'/>
            </View>
            }

            {!searchLoading && searchProducts.length == 0 &&
                <View style = {{display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', flex: 1}}>
                    <Text style = {{color: "gray"}}>Could not find any product with the name "{query}"</Text>
                </View>
            }

            {!searchLoading && searchProducts.length != 0 &&
            <ScrollView >
                <View style = {{display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', flexDirection: 'row', marginBottom: 60}}>
                {searchProducts.map((item, index)=>
                <ServiceCard 
                service={item} 
                navigation={navigation} 
                key={index}/>
                )}
                </View>
            </ScrollView>
            }

        </View>
    );
}

export default Search;