import { View, ScrollView, ActivityIndicator, RefreshControl, Platform, Alert, StyleSheet } from 'react-native';
import React, {useContext, useState} from 'react';
import {Appbar, Avatar, Provider, Menu, Divider, Text } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import * as SecureStore from 'expo-secure-store';
import { AccountContext, AccountInterface} from '../providers/AccountContext';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Loader from '../utils/Loader';
import UpdateProfile from '../components/UpdateProfile';

const Account = ({navigation}:{navigation: any}) => {
    const {userID, email, name, isBusiness, phone, about, street, suburb, city, code, imageUrl, payoutDate, cardIncome, cashIncome, ordersCompleted} = useContext(AccountContext) as AccountInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    const [visible, setVisible] = useState(false);
    const [log, setLog] = useState<boolean>(false);

    const openMenu = () => setVisible(true);
    const closeMenu = () => setVisible(false);

    const [editProfile, setEditProfile] = useState<boolean>(false);

    const onLogout = async()=>{
        setLog(true);
        await SecureStore.deleteItemAsync('userID');
        await SecureStore.deleteItemAsync('name');
        await SecureStore.deleteItemAsync('email');
        await SecureStore.deleteItemAsync('phone');
        await SecureStore.deleteItemAsync('deviceId');
        await SecureStore.deleteItemAsync('token');
        await SecureStore.deleteItemAsync('timestamp');
        await SecureStore.deleteItemAsync('isBusiness');

        setTimeout(()=>{
            setLog(false);
            navigation.replace('Login');
        }, 2500);
    }

    const logoutAlert = () =>
        Alert.alert('Logout', 'You are about to logout your account.', [
        {
            text: 'Cancel',
            style: 'cancel',
        },
        {text: 'Logout', onPress: () => onLogout()},
    ]);

    return (
        <View style = {darkMode.Main}>
            
        <Provider>
        <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
        <Appbar.Content title="Account" color = "#FFFFFF"/>
        <Menu
        visible={visible}
        onDismiss={closeMenu}
        anchor={<Appbar.Action icon="dots-vertical" color = "#FFFFFF" onPress={()=> openMenu()} />}>
        <View>
        <Menu.Item onPress={() => setEditProfile(true)} title="Update Profile" />
        <Divider />
        <Menu.Item onPress={() => logoutAlert()} title="Logout" />
        </View>
        </Menu>
        </Appbar.Header>

        <ScrollView style = {{height: '100%'}}>
        <View style = {{marginTop: 12}}>
        
        
        <View style = {{flexDirection: 'column', alignItems: 'center'}}>
        {imageUrl === null?
        <Avatar.Text size={180} label={name[0]} />
        :
        <Avatar.Image size={180} source={{uri: String(imageUrl)}} />
        }
        <Text variant="displaySmall" style = {{color: "#FFFFFF", marginTop: 12}}>{name}</Text>
        </View>

        {isBusiness &&
        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.Title}>About</Text>
            <Text style = {{color: "gray"}}>{about}</Text>
        </View>
        }

        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.Title}>Contact</Text>
            <View style = {styles.IconText}>
            <MaterialCommunityIcons name="email" size={20} color="gray" />
            <Text style = {{color: "gray", marginLeft: 10}}>{email}</Text>
            </View>

            <View style = {styles.IconText}>
            <MaterialCommunityIcons name="phone" size={20} color="gray" />
            <Text style = {{color: "gray", marginLeft: 10}}>{phone}</Text>
            </View>


        </View>

        {isBusiness &&
        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.Title}>Address</Text>
            <Text style = {{color: "gray"}}>{street}</Text>
            <Text style = {{color: "gray"}}>{suburb}</Text>
            <Text style = {{color: "gray"}}>{city}</Text>
            <Text style = {{color: "gray"}}>{code}</Text>
        </View>
        }

        {!isBusiness &&
        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.Title}>Wallet</Text>
           
            <Text style = {{color: "gray", fontWeight: 'bold'}}>Refund:</Text>
            <Text style = {{color: "gray"}}>{`R${cardIncome}`}</Text>

        </View>
        }

        {isBusiness &&
        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.Title}>Wallet</Text>
           
            <Text style = {{color: "gray", fontWeight: 'bold'}}>Card Income:</Text>
            <Text style = {{color: "gray"}}>{`R${cardIncome}`}</Text>
                   
            <Text style = {{color: "gray", fontWeight: 'bold', marginTop: 12}}>Cash Income:</Text>
            <Text style = {{color: "gray"}}>{`R${cashIncome}`}</Text>

            <Text style = {{color: "gray", fontWeight: 'bold', marginTop: 12}}>Last Payout:</Text>
            <Text style = {{color: "gray"}}>{payoutDate}</Text>
            
            <Text style = {{color: "gray", fontWeight: 'bold', marginTop: 12}}>Completed Orders:</Text>
            <Text style = {{color: "gray"}}>{ordersCompleted}</Text>
        </View>
        }

       
        </View>
        </ScrollView>
        <Loader visible = {log} />
        <UpdateProfile visible = {editProfile} setVisible = {setEditProfile} />
        </Provider>
        
        </View>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#282828",
        borderRadius: 5,
        marginHorizontal: 12,
        marginTop: 10,
        padding: 8
    },
    Title:{
        color: "#FFFFFF",
        marginBottom: 5
    },
    IconText:{
        display: "flex",
        flexDirection: "row",
        alignItems: "center"
    }
});

export default Account;