import { View, Text, SafeAreaView, ScrollView, ActivityIndicator, RefreshControl, Platform } from 'react-native';
import React, {useContext, useState} from 'react';
import { Appbar, Badge, Button } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import NotificationCard from '../components/NotificationCard';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import { AccountContext, AccountInterface } from '../providers/AccountContext';

const Notifications = ({navigation}:{navigation: any}) => {
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {token, userID} = useContext(AccountContext) as AccountInterface;

    const {notifications, loadingNotifications, getNotifications} = useContext(ClientDataContext) as ClientDataInterface;

    const onRefresh = ()=> {
        getNotifications(userID, token);
    }

    return (
        <View style = {darkMode.Main}>
        <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
        <Appbar.Content title="Notifications" color = "#FFFFFF"/>
        <Appbar.Action icon="cart" onPress={()=> navigation.navigate('Cart')} color = '#FFB200' />
        </Appbar.Header>

        <ScrollView style = {{marginTop:2}} refreshControl={<RefreshControl tintColor="#FFF" refreshing={loadingNotifications} onRefresh={onRefresh} />}>
        {notifications.map((item, index)=>
            <NotificationCard 
            key={index}
            navigation={navigation} 
            notification={item}/>
            )}
        </ScrollView>

        </View>
    );
}

export default Notifications;