import {Platform} from 'react-native';
import React, {useContext} from "react";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import Explore from './Explore';
import Account from './Account';
import Notifications from './Notifications';
import MyOrders from './MyOrders';
import Services from './Services';
import Requests from './Requests';
import Overview from './Overview';

const Tab = createBottomTabNavigator();

const Home = ({route}:{route: any}) => {
    const {isBusiness} = route.params;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const width = Platform.OS == 'android' ? 0 : 22;

    return (
        <Tab.Navigator
        screenOptions={({ route }) => ({
            tabBarIcon: ({ color, size }) => {
              
              if (route.name === 'Explore' || route.name === 'Overview') {
                return <MaterialIcons name="home" size={size} color={color} />
              } else if (route.name === 'Account') {
                return <MaterialCommunityIcons name="account" size={size} color={color} />
              }else if(route.name === 'Notifications'){
                return <MaterialIcons name="notifications" size={size} color={color} />
              }else if(route.name === 'MyOrders'){
                return <MaterialIcons name="shopping-bag" size={size} color={color} />
              }else if(route.name === 'Requests'){
                return <MaterialCommunityIcons name="source-pull" size={size} color={color} />
              }else if(route.name === 'Services'){
                return <MaterialCommunityIcons name="toolbox" size={size} color={color} />
              }
            },
            tabBarActiveTintColor: '#FFB200',
            tabBarInactiveTintColor: 'gray',
            tabBarActiveBackgroundColor: background,
            tabBarInactiveBackgroundColor: background,
            tabBarItemStyle: {borderBottomWidth: width, borderBottomColor: background},
            tabBarStyle: {paddingBottom: 0, backgroundColor: background}
          })}
        >
            {!isBusiness ?
            <>
            <Tab.Screen name="Explore" component={Explore} options = {{tabBarLabel: 'Home', header: ()=> null}}/>
            <Tab.Screen name="MyOrders" component={MyOrders} options = {{tabBarLabel: 'My Orders', header: ()=> null}}/>
            <Tab.Screen name="Notifications" component={Notifications} options = {{tabBarLabel: 'Notifications', header: ()=> null}}/>
            </>
            :
            <>
            <Tab.Screen name="Overview" component={Overview} options = {{tabBarLabel: 'Home', header: ()=> null}}/>
            <Tab.Screen name="Services" component={Services} options = {{tabBarLabel: 'Services', header: ()=> null}}/>
            <Tab.Screen name="Requests" component={Requests} options = {{tabBarLabel: 'Requests', header: ()=> null}}/>
            </>
            }
            <Tab.Screen name="Account" component={Account} options = {{tabBarLabel: 'Account', header: ()=> null}}/>
        </Tab.Navigator>
    );
}

export default Home;