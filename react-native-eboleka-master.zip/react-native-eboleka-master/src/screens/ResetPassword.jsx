import { View, Text, Platform, Keyboard } from 'react-native'
import React, {useState} from 'react'
import { Appbar, Button } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import ResetSVG from "../assets/reset-ist.svg";
import Input from '../components/Input';

const ResetPassword = ({navigation}) => {
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});

    const handleError = (error, input) => {
        setErrors(prevState => ({...prevState, [input]: error}));
    };

    const validate = async () => {
        Keyboard.dismiss();
        let isValid = true;
        if(email.trim() == '') {
          handleError('Please input email', 'email');
          isValid = false;
        }else if(!String(email).toLowerCase().match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)){
            handleError('Email format not valid', 'email');
            isValid = false;
        }

        if (isValid) {
            setLoading(true);
        }
    };

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
            <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
            <Appbar.Content color='white' title="Password Reset" />
        </Appbar.Header>

        <View style = {{paddingHorizontal: 12}}>
        <View style = {{justifyContent: 'center', alignItems: 'center'}}>
            <ResetSVG width = {300} height = {300}/>
        </View>

        <Input
            onChangeText={(text)=> setEmail(text)}
            onFocus={() => handleError(null, 'email')}
            iconName="email-outline"
            label="Email"
            placeholder="Enter your email address"
            error={errors.email}
            value = {email}
            maxLength = {45}
        />

        <Button loading = {loading} mode = "contained" buttonColor='#FFB200' style = {{marginVertical: 12, fontWeight: 'bold', borderRadius:  5}} onPress={()=> validate()}>Reset</Button>


        </View>
        </View>
    );
}

export default ResetPassword;