import { View, Text, SafeAreaView, ScrollView, ActivityIndicator, RefreshControl, Platform } from 'react-native';
import React, {useContext, useState} from 'react';
import { Appbar, Badge, Button } from 'react-native-paper';
import { Searchbar } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import OrderCard from '../components/OrderCard';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import Help from '../utils/Help';

const MyOrders = ({navigation}:{navigation: any}) => {
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {token, userID} = useContext(AccountContext) as AccountInterface;
    const {orders, getOrders, loadingOrders} = useContext(ClientDataContext) as ClientDataInterface;
    const [dim, setDim] = useState<boolean>(false);

    const [showHelp, setShowHelp] = useState<boolean>(false);

    const onRefresh = ()=> {
        getOrders(userID, token);
    }

    return (
        <View style = {darkMode.Main}>
        <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
        <Appbar.Content title="My Orders" color = "#FFFFFF"/>
        <Appbar.Action icon="help-circle" onPress={()=> setShowHelp(true)} color = 'gray' />
        <Appbar.Action icon="cart" onPress={()=> navigation.navigate('Cart')} color = '#FFB200' />
        
        </Appbar.Header>

        <ScrollView refreshControl={<RefreshControl tintColor="#FFF" refreshing={loadingOrders} onRefresh={onRefresh} />}>
        {orders.map((item, index)=>
        <OrderCard 
        key={index}
        setDim = {setDim}
        navigation={navigation}
        order={item.order}
        service={item.product}
        />
        )}

        </ScrollView>
        <Help visible = {showHelp} setVisible={setShowHelp} query='MyOrders'/>
        </View>
    );
}

export default MyOrders;