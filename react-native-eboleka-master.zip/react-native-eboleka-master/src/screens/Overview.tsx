import { View, Text, SafeAreaView, ScrollView, ActivityIndicator, RefreshControl, Platform } from 'react-native';
import React, {useContext, useState} from 'react';
import { Appbar, Badge, Button } from 'react-native-paper';
import { Searchbar } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import EmptyHolder from '../utils/EmptyHolder';
import { BusinessDataContext, DataInterface } from '../providers/BusinessDataContext';
import ApprovedCard from '../components/ApprovedCard';
import OrderSkeleton from '../components/OrderSkeletn';
import { AccountContext, AccountInterface } from '../providers/AccountContext';

const Overview = ({navigation, route}: {navigation: any, route: any}) => {
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {token, userID} = useContext(AccountContext) as AccountInterface;
    const {orders, loadingOrders, getOrders} = useContext(BusinessDataContext) as DataInterface;

    const [searchQuery, setSearchQuery] = useState('');

    const loaderArray: Array<number> = [1, 2, 3, 4];

    const onRefresh = ()=> {
        getOrders(userID, token);
    }


    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
            <Appbar.Content title="Eboleka" color = "#FFFFFF"/>
            <Appbar.Action icon = "qrcode-scan" onPress={()=> navigation.navigate("Scanner")} color = '#FFB200' />
            <Appbar.Action icon="bell" onPress={()=> {navigation.navigate("NotificationsX")}} color = '#FFB200' />
            </Appbar.Header>
            <View style = {{paddingBottom: 12, paddingHorizontal: 12, backgroundColor: background}}>
            <Searchbar
            style = {{backgroundColor: '#B3B3B3', borderRadius: 12}}
            placeholder="Search"
            value={searchQuery}
            />
            </View>

            {loadingOrders &&
            <ScrollView>
            {loaderArray.map((item, index)=>
                <OrderSkeleton 
                key={index}
                />
            )}
            </ScrollView>
            }
            

            {!loadingOrders && orders.length == 0 &&
            <EmptyHolder /> 
            }

            {!loadingOrders && orders.length != 0 &&
            <ScrollView refreshControl={<RefreshControl tintColor="#FFF" refreshing={loadingOrders} onRefresh={onRefresh} />}>
                {orders.map((item, index)=>
                <ApprovedCard 
                key={index}
                navigation={navigation}
                order={item.order}
                service={item.product}
                />
                )}
            </ScrollView>
            }

        </View>
    );
}

export default Overview;