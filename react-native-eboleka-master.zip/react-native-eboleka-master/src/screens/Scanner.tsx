import { View, Platform, ScrollView, StyleSheet, Image, TouchableOpacity, ActivityIndicator} from 'react-native'
import React, {useContext, useState, useEffect} from 'react'
import darkMode from '../theme/darkMode';
import { Appbar, Text, Snackbar, Button, Dialog, Portal, Provider} from 'react-native-paper';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import { Feather } from '@expo/vector-icons';
import InvisibleLoader from '../utils/InvisibleLoader';
import host from "../config/host.json";
import axios, { AxiosError, AxiosResponse } from 'axios';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import { BarCodeScanner,  } from 'expo-barcode-scanner';

const Scanner = ({navigation}: {navigation: any}) => {
    const url = host.url;

    const {userID, token, getWallet} = useContext(AccountContext) as AccountInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    const [hasPermission, setHasPermission] = useState<boolean | null>(null);

    const [scanned, setScanned] = useState<boolean>(false);
    const [invalid, setInvalid] = useState<boolean>(false);

    const [loading, setLoading] = useState<boolean>(false);
    const [success, setSuccess] = useState<boolean>(false);
    const [validating, setValidating] = useState<boolean>(false);

    useEffect(() => {
        const getBarCodeScannerPermissions = async () => {
        const { status } = await BarCodeScanner.requestPermissionsAsync();
        setHasPermission(status === 'granted');
        }

        getBarCodeScannerPermissions();

    },[]);

    const onRetry = ()=>{
        setScanned(false);
        setInvalid(false);
    }

    const reset = ()=>{
        setLoading(false);

        setTimeout(()=>{
            setSuccess(false);
            setValidating(false);
            setScanned(false);
        }, 3600);
    }

    const onComplete =async(uid:string, key:string)=>{
        setValidating(true);
        setLoading(true);
        await axios.post(`${url}/order/scan`, {
            uid: uid,
            key: key
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response:AxiosResponse)=>{
            getWallet(token);
            setSuccess(true);
            reset();
        }).catch((reason:AxiosError)=>{
            setSuccess(false);
            reset();
            console.log(reason);
        });
    }

    const handleBarCodeScanned = (type:string, code:string) => {
        if(!scanned){
            setScanned(true); 
            if(type === "org.iso.QRCode"){
                try{
                    const data = JSON.parse(code);

                    const uid = data.uid;
                    const key = data.key;
                    const engine = data.engine;
                    const clientId = data.clientId;
                    const businessId = data.businessId;

                    if(uid !== undefined && key !== undefined && engine === "ebolekangn" && clientId !== undefined && businessId === userID){
                        onComplete(uid, key);
                    }else{
                        setInvalid(true);
                    }
                }catch{
                    setInvalid(true);
                }
            }else{
               setInvalid(true);
            }
        }
    }

    return (
        <View style = {darkMode.Main}>
            <Provider>
            <Portal>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title="Scan" />
            </Appbar.Header>

            {validating ?
            <View style = {{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            {loading ? 
            <ActivityIndicator size="large" color="#FFB200" />
            :
            <>
            {success ? 
            <Feather name="check-circle" size={200} color="green" />
            :
            <Feather name="x-circle" size={200} color="#282828" />
            }
            </>
            }
            </View>
            :
            <>
            {hasPermission === null || !hasPermission &&
            <View style = {{flex: 1, justifyContent: 'center', alignItems: "center"}}>
            <Text variant="labelLarge" style = {{color: "#FFF"}}>Requesting for camera permission</Text>
            </View>
            }

            {hasPermission && 
            <BarCodeScanner
            onBarCodeScanned={(e)=> handleBarCodeScanned(e.type, e.data)}
            style={{flex: 1}}
            />
            }

            <Dialog visible={invalid}>
            <Dialog.Title>QRCode</Dialog.Title>
                <Dialog.Content>
                <Text variant="bodyMedium">The format of the code is invalid</Text>
                </Dialog.Content>
                <Dialog.Actions>
                <Button onPress={()=> onRetry()}>Dismiss</Button>
                </Dialog.Actions>
            </Dialog>
            </>
            }

            </Portal>
            </Provider>
        </View>
    );
}

const styles = StyleSheet.create({
    
});

export default Scanner;