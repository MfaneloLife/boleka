import { View, Text, SafeAreaView, ScrollView, ActivityIndicator, RefreshControl, Platform } from 'react-native';
import React, {useContext, useState} from 'react';
import { Appbar, Badge, Button } from 'react-native-paper';
import { Searchbar } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import EmptyHolder from '../utils/EmptyHolder';
import { BusinessDataContext, DataInterface } from '../providers/BusinessDataContext';
import OrderCard from '../components/OrderCard';
import InvisibleLoader from '../utils/InvisibleLoader';
import { AccountContext, AccountInterface } from '../providers/AccountContext';


const Requests = ({navigation}:{navigation: any}) => {
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {token, userID} = useContext(AccountContext) as AccountInterface;
    const {requests, loadingRequests, getRequests} = useContext(BusinessDataContext) as DataInterface;

    const [dim, setDim] = useState<boolean>(false);

    const onRefresh = ()=> {
        getRequests(userID, token);
    }

    return (
        <View style = {darkMode.Main}>
        <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
        <Appbar.Content title="Requests" color = "#FFFFFF"/>
        <Appbar.Action icon="bell" onPress={()=> {navigation.navigate("NotificationsX")}} color = '#FFB200' />
        
        </Appbar.Header>

        {!loadingRequests && requests.length == 0 &&
         <ScrollView refreshControl={<RefreshControl tintColor="#FFF" refreshing={loadingRequests} onRefresh={onRefresh} />}>
        <EmptyHolder />
        </ScrollView>
        }

        {!loadingRequests && requests.length != 0 &&
        <ScrollView refreshControl={<RefreshControl tintColor="#FFF" refreshing={loadingRequests} onRefresh={onRefresh} />}>
            {requests.map((item, index)=>
            <OrderCard 
            key={index}
            navigation={navigation}
            order={item.order}
            service={item.product}
            setDim={setDim}
            />
            )}
        </ScrollView>
        }

        <InvisibleLoader visible = {dim}/>

        </View>
    );
}

export default Requests;