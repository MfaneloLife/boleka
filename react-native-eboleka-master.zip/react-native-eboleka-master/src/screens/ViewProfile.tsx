import { View, Platform, ScrollView, StyleSheet, Image, TouchableOpacity, ActivityIndicator} from 'react-native'
import React, {useContext, useState, useEffect} from 'react'
import darkMode from '../theme/darkMode';
import { Appbar, Text, Snackbar, Button, Avatar} from 'react-native-paper';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import { Feather, MaterialCommunityIcons, FontAwesome, FontAwesome5 } from '@expo/vector-icons';
import InvisibleLoader from '../utils/InvisibleLoader';
import host from "../config/host.json";
import axios, { AxiosError, AxiosResponse } from 'axios';
import ServiceCard from '../components/ServiceCard';

export interface AccountType{
    about: string
    email: string
    imageUrl: string
    phone: string
    createdDate: string
    street: string
    suburb: string
    city: string
    code: string
}


const ViewProfile = ({navigation, route}: {navigation: any, route: any}) => {
    const url = host.url;
    const {name, id} = route.params;
    const {isBusiness, userID, token} = useContext(AccountContext) as AccountInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const [account, setAccount] = useState<null | AccountType>(null);
    const [services, setServices] = useState<Array<any>>([]);
 
    const [loading, setLoading] = useState<boolean>(false);

    useEffect(()=>{
        getProfile();
    }, []);

    const getProfile = async()=>{
        setLoading(true);
        await axios.get(`${url}/profile/?id=${id}`, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setAccount(response.data.data.account);
            setServices(response.data.data.products);
            setLoading(false);
        }).catch((reason: AxiosError)=>{
            console.log(reason.message);
            setLoading(false);
        })
    }

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title={name} />
            </Appbar.Header>

            <ScrollView>
            <View style = {{flexDirection: 'column', alignItems: 'center', marginTop: 12}}>
            {account?.imageUrl === null?
            <Avatar.Text size={180} label={name[0]} />
            :
            <Avatar.Image size={180} source={{uri: String(account?.imageUrl)}} />
            }
            <Text variant="displaySmall" style = {{color: "#FFFFFF", marginTop: 12}}>{name}</Text>
            </View>

            {loading &&
                <ActivityIndicator size="large" color="#FFF" style = {{marginTop: 100}}/>
            }

            {!loading &&
            <>

            {!isBusiness &&
            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>About</Text>
                <Text style = {{color: "gray"}}>{account?.about}</Text>
                <Text style = {{color: "gray", marginTop:12}}>{`Joined: ${account?.createdDate.split(" ")[1]} ${account?.createdDate.split(" ")[2]} ${account?.createdDate.split(" ")[3]}`}</Text>
            </View>
            }

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Contact</Text>
                <View style = {styles.IconText}>
                <MaterialCommunityIcons name="email" size={20} color="gray" />
                <Text style = {{color: "gray", marginLeft: 10}}>{account?.email}</Text>
                </View>

                <View style = {styles.IconText}>
                <MaterialCommunityIcons name="phone" size={20} color="gray" />
                <Text style = {{color: "gray", marginLeft: 10}}>{account?.phone}</Text>
                </View>
            </View>

            {!isBusiness &&
            <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.Title}>Address</Text>
            <Text style = {{color: "gray"}}>{account?.street}</Text>
            <Text style = {{color: "gray"}}>{account?.suburb}</Text>
            <Text style = {{color: "gray"}}>{account?.city}</Text>
            <Text style = {{color: "gray"}}>{account?.code}</Text>
            </View>
            }

            
            <View style = {{display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', flexDirection: 'row', marginBottom: 60, marginTop:20}}>
            {services.map((item, index)=>
            <ServiceCard 
            service={item} 
            navigation={navigation} 
            key={index}/>
            )}
            </View>
            
            </>
            }
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#282828",
        borderRadius: 5,
        marginHorizontal: 12,
        marginTop: 10,
        padding: 8
    },
    Title:{
        color: "#FFFFFF",
        marginBottom: 5
    },
    IconText:{
        display: "flex",
        flexDirection: "row",
    }
     
});

export default ViewProfile;