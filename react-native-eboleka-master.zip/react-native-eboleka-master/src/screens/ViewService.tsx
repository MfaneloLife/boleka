import { View, Platform, ScrollView, StyleSheet, Image, TouchableOpacity} from 'react-native'
import React, {useContext, useState, useEffect} from 'react'
import darkMode from '../theme/darkMode';
import { Appbar, Text, Snackbar, Button} from 'react-native-paper';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import { Feather, MaterialCommunityIcons, FontAwesome, FontAwesome5 } from '@expo/vector-icons';
import InvisibleLoader from '../utils/InvisibleLoader';
import host from "../config/host.json";
import axios, { AxiosError, AxiosResponse } from 'axios';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';

export const ImageText = ({text}:{text: string})=>{
    return(
        <View style = {{flexDirection: 'row', marginBottom: 5}}>
        {text == "DELIVERY" &&
        <MaterialCommunityIcons name="truck-delivery-outline" size={20} color="gray" />
        }

        {text == "COLLECTION" &&
            <Feather name="package" size={20} color='gray' />
        }

        {text == "CARD" &&
        <FontAwesome name="cc-visa" size={20} color="gray" />
        }

        {text == "CASH" &&
        <FontAwesome5 name="money-bill-wave" size={20} color="gray" />
        }

        <Text style = {{color:"#FFFFFF", marginLeft: 5}}>{text}</Text>
        </View>
    );
}


const ViewService = ({navigation, route}: {navigation: any, route: any}) => {
    const url = host.url;
    const {service} = route.params;
    const {isBusiness, userID, token} = useContext(AccountContext) as AccountInterface;
    const {setCart, cart} = useContext(ClientDataContext) as ClientDataInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    const [loading, setLoading] = useState<boolean>(false);
    const [toast, setToast] = useState('');
    const [showSnackbar, setShowSnackbar] = useState(false);
    const [enabled, setEnabled] = useState<boolean>(true);

    useEffect(()=>{
        checkItem();
    }, []);

    const onViewProfile = ()=>{
        if(!isBusiness){
            navigation.navigate('ViewProfile', {name: service.ownerName, id: service.ownerId});
        }
    }

    const checkItem = ()=>{
        for(let i = 0; i < cart.length; i++){
            const product = cart[i];
            if(product.uid == service.uid){
                setEnabled(false);
                break;
            }
        }
    }

    const onDismissSnackBar = () =>{
        setShowSnackbar(false);
    }

    const onAddCart = async()=>{
        setLoading(true);
        await axios.post(`${url}/cart/`, {
            uid: service.uid
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setToast("Added");
            setCart(response.data.data);
            setEnabled(false);
            setLoading(false);
            setShowSnackbar(true);
        }).catch((reason: AxiosError)=>{
            setToast("Failed");
            console.log(reason);
            setLoading(false);
            setShowSnackbar(true);
        });
    }

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title={service.title} />
            </Appbar.Header>

            <ScrollView>
                <Image source={{uri: service.imageUrl}} style = {styles.ImageHolder}/>

            <View style = {styles.Container}>
                <Text variant="titleLarge" style = {styles.Title}>{service.title}</Text>
                <TouchableOpacity onPress={()=> onViewProfile()}>
                <Text variant="titleSmall" style = {{color: "#FFB200", fontSize: 16, marginBottom: 2}}>{service.ownerName}</Text>
                </TouchableOpacity>
                <Text style = {{color: "gray"}}>{service.description}</Text>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Pricing</Text>
                <Text variant="titleMedium" style = {styles.Title}>{`R${service.price}`}</Text>
                <Text style = {{color: "gray"}}>PER DAY</Text>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Delivery Methods</Text>
                {service.deliveryMethods.map((item: string, index: number)=>
                <ImageText key={index} text={item}/>
                )}
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Payment Methods</Text>
                {service.paymentMethods.map((item: string, index: number)=>
                <ImageText key={index} text={item}/>
                )}
            </View>

            {isBusiness &&
            <View style = {{alignSelf: 'center'}}>
            <Text style = {{color: "gray", marginLeft: 12, marginTop: 5,}}>{service.isVisible ? "Service visible to clients" : "Service not visible to clients"}</Text>
            </View>
            }
            
            {!isBusiness &&
            <Button disabled = {!enabled} loading = {loading} icon="cart" mode = "contained" style = {{marginTop: 20, marginHorizontal: 12, borderRadius: 5, backgroundColor: "#FFB200", marginBottom: 50}} onPress={()=> onAddCart()}>ADD TO CART</Button>
            }

            <Snackbar duration={1500} visible={showSnackbar} onDismiss={onDismissSnackBar} style={{backgroundColor: '#282828'}}>{toast}</Snackbar>

            </ScrollView>
            <InvisibleLoader visible = {loading}/>
        </View>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#282828",
        borderRadius: 10,
        marginHorizontal: 12,
        marginTop: 10,
        padding: 8
    },
    Title:{
        color: "#FFFFFF",
        marginBottom: 5
    },
    ImageHolder:{
        backgroundColor: "#282828",
        borderRadius: 10,
        width: "100%",
        height: 280,
        marginTop: 10,
    }
   
});

export default ViewService;