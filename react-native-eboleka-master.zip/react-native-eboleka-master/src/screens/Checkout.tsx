import { View, Platform, TouchableOpacity, StyleSheet, ScrollView, Image } from 'react-native';
import React, {useContext, useEffect, useState} from 'react';
import darkMode from '../theme/darkMode';
import { Appbar, Text, TextInput, Snackbar, Divider, Button, RadioButton } from 'react-native-paper';
import { Feather, MaterialCommunityIcons, MaterialIcons, FontAwesome, FontAwesome5 } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import MapView, {Marker, PROVIDER_GOOGLE}from 'react-native-maps';
import { ImageText } from './ViewService';
import axios, { AxiosError, AxiosResponse } from 'axios';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import InvisibleLoader from '../utils/InvisibleLoader';
import host from "../config/host.json";
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import { Ionicons } from '@expo/vector-icons';
import AddressQuery from '../components/AddressQuery';

const Checkout = ({navigation, route}:{navigation: any, route: any}) => {
    const url = host.url;
    const {service} = route.params;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {userID, name, token} = useContext(AccountContext) as AccountInterface;
    const {setCart, setOrders} = useContext(ClientDataContext) as ClientDataInterface;

    const [location, setLocation] = useState({"coords": {"accuracy": 0, "altitude": 0, "altitudeAccuracy": 0, "heading": 0, "latitude": -25.9644113, "longitude": 28.1021085, "speed": 0}, "mocked": false, "timestamp": 0});
    const [locationDisable, setLocationDisable] = useState(false);

    const locationDelta = {
        latitudeDelta: 0.04,
        longitudeDelta: 0.05,
    };

    const [street, setStreet] = useState('');
    const [suburb, setSuburb] = useState('');
    const [city, setCity] = useState('');
    const [code, setCode] = useState('');

    const [lookedup, setLookedup] = useState<boolean>(false);
    const [places, setPlaces] = useState<Array<any>>([]);
    const [mapsError, setMapsError] = useState<boolean>(false);
    const [deliveryAddress, setDeliveryAddress] = useState<any>(null);

    const [payment, setPayment] = useState<string>("0");
    const [comments, setComments] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(false);

    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    const [step, setStep] = useState(0);
    const [deliveryOption, setDeliveryOption] = useState('');
    const [paymentOption, setPaymentOption] = useState('');

    const [date, setDate] = useState(new Date());
    const [mode, setMode] = useState(undefined);
    const [showPicker, setShowPicker] = useState(false);
    const [duration, setDuration] = useState(1);
    const [myTime, setMyTime] = useState('');
    const [myDate, setMyDate] = useState('');

    const [queryAddress, setQueryAddress] = useState<boolean>(false);

    const showMode = (currentMode: any)=>{
        setShowPicker(true);
        setMode(currentMode);
    }

    const onChangeDatetime = (event: any, selectedDate: any)=>{
        const currentDate = selectedDate || date;
        setShowPicker(Platform.OS === 'ios');
        setDate(currentDate);

        let tempDate = new Date(currentDate);
        let fDate = `${String(tempDate.getDate()).padStart(2, '0')} ${months[tempDate.getMonth()]} ${tempDate.getFullYear()}`;
        let fTime = `${String(tempDate.getHours()).padStart(2, '0')}:${String(tempDate.getMinutes()).padStart(2, '0')}`;

        setMyDate(fDate);
        setMyTime(fTime);
    }

    const onPeriodNext = ()=>{
        if(myDate != '' && myTime != '')
        setStep(step + 1);
    }

    const onAddressNext = ()=>{
        if(street.trim() != '' && suburb.trim() != '' && city.trim() != '' && code.trim().length == 4)
        setStep(step + 1);
    }

    const clearAddress = ()=>{
        setDeliveryAddress(null);
        setStreet('');
        setSuburb('');
        setCity('');
        setCode('');
    }

    const onAddressLookup = ()=>{
        if(street.trim() != '' && suburb.trim() != '' && city.trim() != '' && code.trim().length == 4){
            setLookedup(false);
            setMapsError(false);
            setPlaces([]);
            setQueryAddress(true);
        }
    }

    const onDurationChange = (oparator: string)=>{
        switch (oparator){
            case '+':
                if(duration < 7)
                setDuration(duration + 1);
                break;
            case '-':
                if(duration > 1)
                setDuration(duration - 1);
                break;
        }
    }

    const onSelectDelivey = (option: string)=>{
        setDeliveryOption(option);
        setStep(step + 1);
    }

    const onSelectPayment =(option: string)=>{
        setPaymentOption(option);
        setStep(step + 1);
    }

    const onCheckout = async()=>{
        setLoading(true);

        let payment:number = 0;
        let delivery:number = 0;

        if(paymentOption === 'CARD'){
            payment = 1;
        }

        if(deliveryOption === "COLLECTION"){
            delivery = 1;
        }
        
        await axios.post(`${url}/order/`, {
            productId: service.uid,
            serviceDate: `${myDate} ${myTime}`,
            comments: comments.trim(),
            duration: duration,
            paymentMethod: payment,
            deliveryMethod: delivery,
            street: street.trim(),
            city: city.trim(),
            suburb: suburb.trim(),
            code: code,
            lat: deliveryAddress.lat,
            lon: deliveryAddress.lng
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            setCart(response.data.data.cart);
            setOrders(response.data.data.order);
            setLoading(false);
            navigation.goBack();
        }).catch((reason: AxiosError)=>{
            setLoading(false);
        });
    }

    return (
        <View style = {darkMode.Main}>
        <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
        <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
        <Appbar.Content color='white' title="Checkout" />
        </Appbar.Header>

        <View style = {{paddingBottom: 12, paddingHorizontal: 12, backgroundColor: background}}>
            <View style = {styles.Bar}>
                <Text variant='titleSmall' style = {{color: step >= 0 ? "#FFFFFF" : 'gray'}} >DELIVERY</Text>
                <Text variant='titleSmall' style = {{color: step >= 2 ? "#FFFFFF" : 'gray'}}>DURATION</Text>
                <Text variant='titleSmall' style = {{color: step >= 3 ? "#FFFFFF" : 'gray'}}>ADDRESS</Text>
                <Text variant='titleSmall' style = {{color: step >= 4 ? "#FFFFFF" : 'gray'}}>SUMMARY</Text>
            </View>
            </View>

        <ScrollView>

        {step == 0 &&
            <>
            <View style = {styles.Title}>
                <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Delivery options</Text>
            </View>

            <Divider></Divider>
            {service.deliveryMethods.includes("DELIVERY") &&
            <TouchableOpacity style = {{backgroundColor: "#282828", paddingHorizontal: 12, paddingVertical: 12, flexDirection: 'row', alignItems: 'center'}} onPress={()=> onSelectDelivey('DELIVERY')}>
            <MaterialCommunityIcons name="truck-delivery-outline" size={50} color="gray" />
            <View style = {{flexDirection: 'column', paddingHorizontal: 10}}>
            <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Delivery</Text>
            <Text variant='bodySmall' style = {{color: "#FFFFFF"}}>Ask the suppier to deliver the services to your address.</Text>
            <Text variant='bodySmall' style = {{color: "#FFFFFF"}}>The suppier can add additional charges for delivery.</Text>
            </View>
            </TouchableOpacity>
            }

            <Divider></Divider>

            {service.deliveryMethods.includes("COLLECTION") &&
            <TouchableOpacity style = {{backgroundColor: "#282828", paddingHorizontal: 12, paddingVertical: 12, flexDirection: 'row', alignItems: 'center'}} onPress={()=> onSelectDelivey('COLLECTION')}>
            <Feather name="package" size={50} color='gray' />
            <View style = {{flexDirection: 'column', marginLeft: 10}}>
            <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Collection</Text>
            <Text variant='bodySmall' style = {{color: "#FFFFFF"}}>Collect the services from the suppier's warehouse.</Text>
            </View>
            </TouchableOpacity>
            }
            </>
        }

        {step == 1 &&
            <>
            <View style = {styles.Title}>
                <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Payment options</Text>
            </View>

            <Divider></Divider>

            {service.paymentMethods.includes("CARD") &&
            <TouchableOpacity style = {{backgroundColor: "#282828", paddingHorizontal: 12, paddingVertical: 12, flexDirection: 'row', alignItems: 'center'}} onPress={()=> onSelectPayment('CARD')}>
            <FontAwesome name="cc-visa" size={40} color="gray" />
            <View style = {{flexDirection: 'column', marginLeft: 10}}>
            <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Card</Text>
            <Text variant='bodySmall' style = {{color: "#FFFFFF"}}>After your request has been approved</Text>
            <Text variant='bodySmall' style = {{color: "#FFFFFF"}}>You will be required to make payments online</Text>
            </View>
            </TouchableOpacity>
            }

            <Divider></Divider>

            {service.paymentMethods.includes("CASH") &&
            <TouchableOpacity style = {{backgroundColor: "#282828", paddingHorizontal: 12, paddingVertical: 12, flexDirection: 'row', alignItems: 'center'}} onPress={()=> onSelectPayment('CASH')}>
            <FontAwesome5 name="money-bill-wave" size={40} color="gray" />
            <View style = {{flexDirection: 'column', marginLeft: 10}}>
            <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Cash</Text>
            <Text variant='bodySmall' style = {{color: "#FFFFFF"}}>You will have to pay the supplier cash</Text>
            <Text variant='bodySmall' style = {{color: "#FFFFFF"}}>Upon delivery or collection </Text>
            </View>
            </TouchableOpacity>
            }
            </>
        }


        {step == 2 &&
            <>
            <View style = {styles.Title}>
                <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Delivery datetime</Text>
            </View>
            <Divider></Divider>
            <View style = {{backgroundColor: "#282828", paddingHorizontal: 12, paddingVertical: 12}}>
            <Text variant='bodySmall' style = {{color: "gray"}}>{`Time and date you prefer the services to be ${deliveryOption == 'DELIVERY' ? 'delivered' : 'collected'}`}</Text>

                {showPicker &&(
                    <DateTimePicker 
                    value={date}
                    mode={mode}
                    is24Hour={true}
                    display='default'
                    onChange={onChangeDatetime}
                    minimumDate = {new Date()}
                    />
                )}

                <View style={styles.DTRow}>
                <View style = {styles.DTIcons}>
                <MaterialIcons name="calendar-today" size={24} color="gray" />
                <Text style={{marginLeft: 5, fontWeight: 'bold', color: '#FFFFFF'}}>{myDate}</Text>
                </View>
            
                <TouchableOpacity onPress={()=> showMode('date')}>
                <Text style={{fontWeight: '600', color: 'orange'}}>Select Date</Text>
                </TouchableOpacity>
                </View>

                <View style={styles.DTRow}>
                <View style = {styles.DTRow}>
                <MaterialIcons name="access-time" size={24} color="gray" />
                <Text style={{marginLeft: 5, fontWeight: 'bold', color: '#FFFFFF'}}>{myTime}</Text>
                </View>
            
                <TouchableOpacity onPress={()=> showMode('time')}>
                <Text style={{fontWeight: '600', color: 'orange'}}>Select Time</Text>
                </TouchableOpacity>
                </View>


            </View>

            <View style = {styles.Title}>
                <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Duration</Text>
            </View>
            <Divider></Divider>

            <View style = {{backgroundColor: "#282828", paddingHorizontal: 12, paddingVertical: 12}}>
            <Text variant='bodySmall' style = {{color: "gray"}}>How long would you like to rent the service</Text>

            <View style = {{flexDirection: 'row', alignItems: 'center', marginTop: 10}}>
                <TouchableOpacity style = {{marginRight: 10}} onPress = {()=> onDurationChange('-')}>
                <FontAwesome name="minus" size={24} color="#FFFFFF" />
                </TouchableOpacity>
                <Text variant='titleMedium' style = {{color: "#FFFFFF", borderWidth: 1, width: 75, padding: 5, borderColor: 'gray', borderRadius: 5}}>{`${duration} ${duration > 1 ? 'Days' : 'Day'}`}</Text>
                <TouchableOpacity style = {{marginLeft: 10}} onPress = {()=> onDurationChange('+')}>
                <FontAwesome name="plus" size={24} color="#FFFFFF" />
                </TouchableOpacity>
            </View>
            {duration > 1 &&
            <Text variant='bodySmall' style = {{color: "#FFFFFF", marginTop: 5}}>{`*Total cost R${service.price * duration}`}</Text>
            }
            
            </View>

            <Button buttonColor='#FFB200' textColor="#FFFFFF" mode='contained' style = {{marginTop: 20, marginHorizontal: 12, borderRadius: 5, backgroundColor: "#FFB200", marginBottom: 50,}} onPress={()=> onPeriodNext()}>Next</Button>
            </>
        }

        {step == 3&&
        <>
        <View style = {styles.Title}>
        <Text variant='titleMedium' style = {{color: "#FFFFFF"}}>Address</Text>
        </View>

        <MapView provider={PROVIDER_GOOGLE}
            region = {{latitude: location.coords.latitude, longitude: location.coords.longitude,latitudeDelta: locationDelta.latitudeDelta, longitudeDelta: locationDelta.longitudeDelta}}
            //customMapStyle={theme.mapStyle}
            style={{width: '100%', height: 250}}>
            {deliveryAddress !== null &&
            <Marker
            coordinate={{latitude: deliveryAddress.lat, longitude: deliveryAddress.lng}}
            />
            }
        </MapView>

        
        <Divider></Divider>
        <View style = {{backgroundColor: "#282828", paddingHorizontal: 12, paddingVertical: 12}}>
        <TextInput
        editable = {deliveryAddress === null}
        value={street}
        textColor='#FFF'
        activeOutlineColor='#FFB200'
        activeUnderlineColor='white'
        label="Street"
        maxLength={30}
        style = {{marginTop: 2, marginBottom: 2, backgroundColor: "#282828", fontWeight: '600'}}
        onChangeText={(text)=> setStreet(text)}
        />

        <TextInput
        editable = {deliveryAddress === null}
        value={suburb}
        textColor='#FFF'
        activeOutlineColor='#FFB200'
        activeUnderlineColor='white'
        label="Suburb"
        maxLength={30}
        style = {{marginTop: 2, marginBottom: 2, backgroundColor: "#282828", fontWeight: '600'}}
        onChangeText={(text)=> setSuburb(text)}
        />

        <TextInput
        editable = {deliveryAddress === null}
        value={city}
        textColor='#FFF'
        activeOutlineColor='#FFB200'
        activeUnderlineColor='white'
        label="City"
        maxLength={30}
        style = {{marginTop: 2, marginBottom: 2, backgroundColor: "#282828", fontWeight: '600'}}
        onChangeText={(text)=> setCity(text)}
        />

        <TextInput
        editable = {deliveryAddress === null}
        value={code}
        textColor='#FFF'
        activeOutlineColor='#FFB200'
        activeUnderlineColor='white'
        label="Postal Code"
        maxLength={4}
        keyboardType="numeric"
        style = {{marginTop: 2, marginBottom: 2, backgroundColor: "#282828", fontWeight: '600'}}
        onChangeText={(text)=> setCode(text)}
        />

        </View>

        {deliveryAddress === null &&
            <Button buttonColor='#FFB200' textColor="#FFFFFF" mode='contained' style = {{marginTop: 20, marginHorizontal: 12, borderRadius: 5, backgroundColor: "#FFB200",}} onPress={()=> onAddressLookup()}>Check Address</Button>
        }

        {deliveryAddress !== null &&
        <>
        <Button buttonColor='#FFB200' textColor="#FFFFFF" mode='contained' style = {{marginTop: 20, marginHorizontal: 12, borderRadius: 5, backgroundColor: "#FFB200"}} onPress={()=> onAddressNext()}>Next</Button>

        <Button textColor="#FFB200" mode='text' style = {{marginTop: 10}} onPress={()=> clearAddress()}>Clear Address</Button>
        </>
        }

        <AddressQuery 
        visible = {queryAddress} 
        setVisible={setQueryAddress}
        street = {street}
        suburb = {suburb}
        city = {city}
        code = {code}
        lookedup = {lookedup}
        setLookedup={setLookedup}
        places={places}
        setPlaces={setPlaces}
        setDeliveryAddress={setDeliveryAddress}
        mapsError = {mapsError} 
        setMapsError = {setMapsError}
        />

        </>
        }

        {step == 4 &&
        <>
         <Image source={{uri: service.imageUrl}} style = {styles.ImageHolder}/>

        <View style = {styles.Container}>
            <Text variant="titleSmall" style = {{color: "#FFB200", fontSize: 16, marginBottom: 2}}>{service.ownerName}</Text>
            <Text variant="titleLarge" style = {styles.TitleS}>{service.title}</Text>
            <Text style = {{color: "gray"}}>{service.description}</Text>
        </View>

        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.TitleS}>Time</Text>
            <Text style = {{color:"#FFFFFF"}}>{myDate}</Text>
            <Text style = {{color:"#FFFFFF"}}>{myTime}</Text>
        </View>

        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.TitleS}>Venue</Text>
            <Text style = {{color:"#FFFFFF"}}>{street}</Text>
            <Text style = {{color:"#FFFFFF"}}>{city}</Text>
            <Text style = {{color:"#FFFFFF"}}>{suburb}</Text>
            <Text style = {{color:"#FFFFFF"}}>{code}</Text>
        </View>

        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.TitleS}>Delivery Method</Text>
            <ImageText text={deliveryOption}/>
        </View>

        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.TitleS}>Payment Method</Text>
            <ImageText text={paymentOption}/>
        </View>

        <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.TitleS}>Price</Text>
            <View style = {{flexDirection: "row", alignItems: "center"}}>
            <Text variant="titleMedium" style = {styles.TitleS}>{`R${service.price}`}</Text>
            <Text style = {{color: "gray", marginLeft: 5, fontSize: 12}}>{`(Per Day)`}</Text>
            </View>
            
            <Text style = {{color: "gray", marginLeft: 5, fontSize: 12}}>x</Text>

            <View style = {{flexDirection: "row", alignItems: "center"}}>
            <Text variant="titleMedium" style = {styles.TitleS}>{`${duration} ${duration > 1 ? 'Days' : 'Day'}`}</Text>
            <Text style = {{color: "gray", marginLeft: 5, fontSize: 12}}>{`(Duration)`}</Text>
            </View>

            <Text variant="titleMedium" style = {styles.TitleS}>{`R${service.price * duration}`}</Text>

        </View>

        <Button loading = {loading} buttonColor='#FFB200' textColor="#FFFFFF" mode='contained' style = {{marginTop: 20, marginHorizontal: 12, borderRadius: 5, backgroundColor: "#FFB200", marginBottom: 50,}} onPress={()=> onCheckout()}>CHECKOUT</Button>

        </>
        }

        </ScrollView>
        <InvisibleLoader visible = {loading}/>

        </View>
    )
}

const styles = StyleSheet.create({
    Bar:{
        display: 'flex', 
        flexDirection: 'row', 
        paddingVertical: 10,
        borderRadius: 5,
        backgroundColor: '#B3B3B3',
        alignItems: 'center',
        justifyContent: 'space-around'
    },
    DTRow:{
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 5,
        alignItems: 'center'
    },
    DTIcons:{
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center'
    },
    Input:{
        marginVertical: 5,
        //backgroundColor: "#282828", 
        fontWeight: '600',
    },
    Title:{
        backgroundColor: "#282828", 
        paddingHorizontal: 12, 
        paddingVertical: 12, 
        marginTop: 1,  
    },
    Container:{
        backgroundColor: "#282828",
        borderRadius: 10,
        marginHorizontal: 12,
        marginTop: 10,
        padding: 8
    },
    ImageHolder:{
        backgroundColor: "#282828",
        borderRadius: 10,
        width: "100%",
        height: 280,
        marginTop: 10,
    },
    TitleS:{
        color: "#FFFFFF",
        marginBottom: 5
    },
    Radio:{
        flexDirection: 'row',
        alignItems: 'center'
    },
    
});

export default Checkout;