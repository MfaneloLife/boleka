import { View, Platform, ScrollView, StyleSheet, Image, TouchableOpacity, ActivityIndicator} from 'react-native'
import React, {useContext, useState, useEffect} from 'react'
import darkMode from '../theme/darkMode';
import { Appbar, Text, Snackbar, Button} from 'react-native-paper';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import host from "../config/host.json";
import axios, { AxiosError, AxiosResponse } from 'axios';
import QRCode from 'react-native-qrcode-svg';


const Scan = ({navigation, route}: {navigation: any, route: any}) => {
    const url = host.url;

    const {order, title} = route.params;
    const {token} = useContext(AccountContext) as AccountInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    const [code, setCode] = useState<string>("null");

    const [time, setTime] = useState<number>(120);
    const [expired, setExpired] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);

    useEffect(()=>{
        getQR();
    }, []);

    const getQR = async()=>{
        setLoading(true);
        await axios.put(`${url}/order/scan`, {
            uid: order.uid
        }, {headers: {"Authorization" : `Bearer ${token}`}})
        .then((response: AxiosResponse)=>{
            const data = JSON.stringify(response.data);
            setCode(data);
            setLoading(false);
            setExpired(false);
            counter(120);
        }).catch((reason: AxiosError)=>{
            console.log(reason);
        });
    }

    const counter =(remaining: number)=>{
        if(remaining > 0){
            remaining = remaining - 1;
            setTimeout(() => {
                setTime(remaining);
                counter(remaining);
            }, 1000);
        }else{
            setExpired(true);
        }
    }

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title="Scan" />
            </Appbar.Header>

           
                <View style = {styles.Main}>
                    {loading ? 
                    <ActivityIndicator size="large" color="#FFB200" />
                    :
                    <QRCode color = "#282828" logoSize = {30} value = {code} size = {250}/>
                    }

                    {!loading &&
                    <>
                    <Text variant="labelLarge" style = {{color: "#FFF", marginTop: 12}}>{title}</Text>
                    <Text variant="labelLarge" style = {{color: "#FFF"}}>{`${order.businessName} Must scan this QR Code`}</Text>
                    </>
                    }

                    {!loading &&
                    <>
                    {expired ?
                    <>
                    <Button textColor='#FFB200' onPress={()=> getQR()}>Generate Code</Button>
                    </>
                    :
                    <>
                    <Text variant="labelLarge" style = {{color: "red", marginTop: 12}} >Expires in</Text>
                    <Text variant="labelLarge" style = {{color: "red"}} >{`${time}s`}</Text>
                    </>
                    }
                    </>
                    }

                </View>
            
        </View>
    );
}

const styles = StyleSheet.create({
    Main:{
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center'
    }
});

export default Scan;