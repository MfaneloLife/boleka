import { View, Text, SafeAreaView, ScrollView, ActivityIndicator, RefreshControl, Platform } from 'react-native';
import React, {useContext, useState} from 'react';
import { Appbar, Badge, Button } from 'react-native-paper';
import { Searchbar } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import EmptyHolder from '../utils/EmptyHolder';
import CartCard from '../components/CartCard';
import Loader from '../utils/Loader';

const Cart = ({navigation}:{navigation: any}) => {
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {cart, loadingCart} = useContext(ClientDataContext) as ClientDataInterface;

    const [deleting, setDeleting] = useState<boolean>(false);

    return (
        <View style = {darkMode.Main}>
        <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
        <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
        <Appbar.Content title="My Cart" color = "#FFFFFF"/>
        </Appbar.Header>

        {!loadingCart && cart.length == 0 &&
            <EmptyHolder />
        }

        {cart.length != 0 &&
        <ScrollView>
            {cart.map((item, index)=>
            <CartCard 
            key={index}
            navigation={navigation} 
            service={item}
            setDeleting={setDeleting}
            />
            )}
        </ScrollView>
        }

        <Loader visible = {deleting} />

        </View>
    );
}

export default Cart;