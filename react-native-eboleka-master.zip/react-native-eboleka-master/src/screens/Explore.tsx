import { View, Text, SafeAreaView, ScrollView, ActivityIndicator, RefreshControl, Platform, Keyboard } from 'react-native';
import React, {useContext, useState} from 'react';
import { Appbar, Badge, Button } from 'react-native-paper';
import { Searchbar } from 'react-native-paper';
import darkMode from '../theme/darkMode';
import ServicesSkeleton from '../components/ServicesSkeleton';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import EmptyHolder from '../utils/EmptyHolder';
import ServiceCard from '../components/ServiceCard';
import Storecard from '../components/StoreCard';
import { AccountContext, AccountInterface } from '../providers/AccountContext';

const Explore = ({navigation, route}: {navigation: any, route: any}) => {
    const background = Platform.OS == 'android' ? '#282828' : '#121212';
    const {token, userID} = useContext(AccountContext) as AccountInterface;
    const {services, stores, loadingExplore, getExplore, resetExplore, onSearchProducts} = useContext(ClientDataContext) as ClientDataInterface;

    const [searchQuery, setSearchQuery] = useState('');
    const [showStores, setShowStores] = useState(true);

    const loaderArray: Array<number> = [1, 2, 3, 4, 5, 6];

    const onSearch = ()=>{
        if(searchQuery.trim().length >= 3){
            onSearchProducts(searchQuery.trim(), token);
            navigation.navigate("Search", {query: searchQuery.trim()});
        }
    }

    const onRefresh = ()=> {
        resetExplore(token);
    }

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode = 'small' style = {{backgroundColor: background}}>
            <Appbar.Content title="Eboleka" color = "#FFFFFF"/>
            <Appbar.Action icon = {showStores ? "store" : "shopping"} onPress={()=> setShowStores(!showStores)} color = '#FFB200' />
            <Appbar.Action icon="cart" onPress={()=> navigation.navigate('Cart')} color = '#FFB200' />
            </Appbar.Header>
            <View style = {{paddingBottom: 12, paddingHorizontal: 12, backgroundColor: background}}>
            <Searchbar
            style = {{backgroundColor: '#B3B3B3', borderRadius: 12}}
            placeholder="Search"
            onChangeText={(val)=> setSearchQuery(val)}
            value={searchQuery}
            cursorColor="#FFB200"
            onSubmitEditing={()=> onSearch()}
            />
            </View>

            {loadingExplore && services.length == 0 && 
            <ScrollView>
            <View style = {{display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', flexDirection: 'row'}}>
            {loaderArray.map((value, index)=>
            <ServicesSkeleton 
            key={index}
            />
            )}
            </View>
            </ScrollView>
            }

            {!loadingExplore && services.length == 0 && 
            <EmptyHolder />
            }

            {!loadingExplore && services.length != 0 && showStores &&
            <ScrollView refreshControl={<RefreshControl tintColor="#FFF" refreshing={loadingExplore} onRefresh={onRefresh} />}>
                <View style = {{display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', flexDirection: 'row'}}>
                {services.map((item, index)=>
                <ServiceCard 
                service={item} 
                navigation={navigation} 
                key={index}/>
                )}
                </View>
                {services.length >= 6 &&
                    <Button textColor='#FFB200' onPress={()=> getExplore(token)}>More</Button>
                }
            </ScrollView>
            }

            {!loadingExplore && stores.length != 0 && !showStores &&
                <ScrollView refreshControl={<RefreshControl tintColor="#FFF" refreshing={loadingExplore} onRefresh={onRefresh} />}>
                <View style = {{display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', flexDirection: 'row'}}>
                {stores.map((item, index)=> 
                <Storecard key={index} 
                navigation={navigation}
                store = {item}/>
                )}
                </View>
                {services.length >= 6 &&
                    <Button textColor='#FFB200' onPress={()=> getExplore(token)}>More</Button>
                }
                </ScrollView>
            }

        </View>
    );
}

export default Explore