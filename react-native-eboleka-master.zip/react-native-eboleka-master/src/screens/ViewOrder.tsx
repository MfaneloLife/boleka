import { View, Platform, ScrollView, StyleSheet, Image, TouchableOpacity, Alert} from 'react-native'
import React, {useContext, useState, useEffect} from 'react'
import darkMode from '../theme/darkMode';
import { Appbar, Text, Snackbar, Button} from 'react-native-paper';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import { Feather, MaterialCommunityIcons, FontAwesome, FontAwesome5 } from '@expo/vector-icons';
import InvisibleLoader from '../utils/InvisibleLoader';
import host from "../config/host.json";
import axios, { AxiosError, AxiosResponse } from 'axios';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';
import { ImageText } from './ViewService';
import ViewMap from '../components/ViewMap';
import { BusinessDataContext, DataInterface } from '../providers/BusinessDataContext';

const ViewOrder = ({navigation, route}: {navigation: any, route: any}) => {
    const url = host.url;
    const {service, order} = route.params;
    const {isBusiness, getWallet, token} = useContext(AccountContext) as AccountInterface;

    const {updateOrder} = useContext(BusinessDataContext) as DataInterface;
    const {setOrders} = useContext(ClientDataContext) as ClientDataInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    const [loading, setLoading] = useState<boolean>(false);
    const [toast, setToast] = useState('');
    const [showSnackbar, setShowSnackbar] = useState(false);

    const [showMap, setShowMap] = useState<boolean>(false);

    const onDismissSnackBar = () =>{
        setShowSnackbar(false);
    }

    const onViewProfile = ()=>{
        const name = isBusiness ? order.clientName : service.ownerName;
        const id = isBusiness ? order.clientId : order.businessId;
        navigation.navigate('ViewProfile', {name: name, id: id});
    }

    const onDeleteDialog = ()=>{
        Alert.alert('Cancel', `You are about to cancel ${service.title} order`, [
            {
                text: 'Cancel',
                style: 'cancel',
            },
            {text: 'Decline', onPress: () => onCancel()},
            ]);
    }

    const onCancel = async()=>{
        setLoading(true);
        await axios.delete(`${url}/order/drop`, {
            data:{uid: order.uid},
            headers: {"Authorization" : `Bearer ${token}`}
        }).then((response: AxiosResponse)=>{
            getWallet(token);
            updateOrder(response.data.data);
            setLoading(false);
            navigation.goBack();
        }).catch((reason: AxiosError)=>{
            setLoading(false);
            console.log(reason);
        });
    }

    const onDecline = async()=>{
        setLoading(true);
        await axios.delete(`${url}/order/`, {
            data:{uid: order.uid},
            headers: {"Authorization" : `Bearer ${token}`}
        }).then((response: AxiosResponse)=>{
            setOrders(response.data.data);
            setLoading(false);
            navigation.goBack();
        }).catch((reason: AxiosError)=>{
            setLoading(false);
            console.log(reason);
        });
    }

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title={service.title} />
                {isBusiness && !order.completed &&
                <Appbar.Action icon="trash-can" color = "#FFFFFF" onPress={()=> onDeleteDialog()} />
                }
            </Appbar.Header>

            <ScrollView>
                <Image source={{uri: service.imageUrl}} style = {styles.ImageHolder}/>

            <View style = {styles.Container}>
                <Text variant="titleLarge" style = {styles.Title}>{service.title}</Text>
                <Text style = {{color: "gray"}}>{`#${order.orderId}`}</Text>

                <TouchableOpacity onPress={()=> onViewProfile()}>
                <Text variant="titleSmall" style = {{color: "#FFB200", fontSize: 16, marginBottom: 2}}>{isBusiness ? order.clientName : service.ownerName}</Text>
                </TouchableOpacity>
                <Text style = {{color: "gray"}}>{service.description}</Text>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Status</Text>
                <Text variant="titleMedium" style = {styles.Title}>Waiting</Text>
                <Text style = {{color: "gray"}}>PER DAY</Text>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Time</Text>
                <Text style = {{color: "gray"}}>{order.serviceDate.split(" ")[3]}</Text>
                <Text style = {{color: "gray"}}>{`${order.serviceDate.split(" ")[0]} ${order.serviceDate.split(" ")[1]} ${order.serviceDate.split(" ")[2]}`}</Text>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Venue</Text>
                <Text style = {{color: "gray"}}>{order.street}</Text>
                <Text style = {{color: "gray"}}>{order.suburb}</Text>
                <Text style = {{color: "gray"}}>{order.city}</Text>
                <Text style = {{color: "gray"}}>{order.code}</Text>
                <Button textColor="#FFB200" mode='text' style = {{marginTop: 10}} onPress={()=> setShowMap(true)}>Show Map</Button>
            </View>

            <View style = {styles.Container}>
            <Text variant="titleMedium" style = {styles.Title}>Price</Text>
            <View style = {{flexDirection: "row", alignItems: "center"}}>
            <Text variant="titleMedium" style = {styles.Title}>{`R${service.price}`}</Text>
            <Text style = {{color: "gray", marginLeft: 5, fontSize: 12}}>{`(Per Day)`}</Text>
            </View>
            
            <Text style = {{color: "gray", marginLeft: 5, fontSize: 12}}>x</Text>

            <View style = {{flexDirection: "row", alignItems: "center"}}>
            <Text variant="titleMedium" style = {styles.Title}>{`${order.duration} ${order.duration > 1 ? 'Days' : 'Day'}`}</Text>
            <Text style = {{color: "gray", marginLeft: 5, fontSize: 12}}>{`(Duration)`}</Text>
            </View>

            <Text variant="titleMedium" style = {styles.Title}>{`R${order.price * order.duration}`}</Text>

            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Delivery Method</Text>
                <ImageText text={order.deliveryMethod}/>
            </View>

            <View style = {styles.Container}>
                <Text variant="titleMedium" style = {styles.Title}>Payment Method</Text>
                <ImageText text={order.paymentMethod}/>
            </View>


            
            {!isBusiness && !order.paid &&
            <Button loading = {loading} mode = "contained" style = {{marginTop: 20, marginHorizontal: 12, borderRadius: 5, backgroundColor: "#FFB200", marginBottom: 50}} onPress={()=> onDecline()}>CANCEL</Button>
            }

            <Snackbar duration={1500} visible={showSnackbar} onDismiss={onDismissSnackBar} style={{backgroundColor: '#282828'}}>{toast}</Snackbar>

            </ScrollView>
            <InvisibleLoader visible = {loading}/>
            <ViewMap visible = {showMap} setVisible={setShowMap} lat={order.lat} lng={order.lng}/>
        </View>
    );
}

const styles = StyleSheet.create({
    Container:{
        backgroundColor: "#282828",
        borderRadius: 10,
        marginHorizontal: 12,
        marginTop: 10,
        padding: 8
    },
    Title:{
        color: "#FFFFFF",
        marginBottom: 5
    },
    ImageHolder:{
        backgroundColor: "#282828",
        borderRadius: 10,
        width: "100%",
        height: 280,
        marginTop: 10,
    }
   
});

export default ViewOrder;