import { View, Platform, ScrollView, StyleSheet, Image, TouchableOpacity, TextInput, Alert} from 'react-native'
import React, {useContext, useState, useEffect} from 'react'
import darkMode from '../theme/darkMode';
import { Appbar, Text, Snackbar, Button} from 'react-native-paper';
import { AccountContext, AccountInterface } from '../providers/AccountContext';
import { MaterialCommunityIcons } from '@expo/vector-icons';import InvisibleLoader from '../utils/InvisibleLoader';
import host from "../config/host.json";
import axios, { AxiosError, AxiosResponse } from 'axios';
import { ClientDataContext, ClientDataInterface } from '../providers/ClientDataContext';


const Chat = ({navigation, route}: {navigation: any, route: any}) => {
    const {orderId} = route.params;
    const {isBusiness, userID} = useContext(AccountContext) as AccountInterface;
    const {setCart, cart} = useContext(ClientDataContext) as ClientDataInterface;
    const background = Platform.OS == 'android' ? '#282828' : '#121212';

    useEffect(()=>{
        Alert.alert('Chat', 'This feature is not yet available', [
            {text: 'Ok', onPress: () => navigation.goBack()},
          ]);
    }, []);

    return (
        <View style = {darkMode.Main}>
            <Appbar.Header mode="small" style = {{backgroundColor: background, padding: 0}}>
                <Appbar.BackAction color='white' onPress={() => navigation.goBack()} />
                <Appbar.Content color='white' title={`#${orderId}`} />
            </Appbar.Header>

            <View style = {{display: 'flex', flex: 1, flexDirection: 'column', justifyContent: 'space-between'}}>
                <Text>{''}</Text>

                <View style = {styles.InputBar}>
                    <View style = {styles.InputWrapper}>
                    <TextInput 
                        cursorColor="#FFB200"
                        maxLength={0}
                        multiline
                        style = {{color: "#121212"}}
                    />
                    </View>
                    <MaterialCommunityIcons name="send" size={24} color="#FFB200" />
                </View>
            </View>


            
           
        </View>
    );
}

const styles = StyleSheet.create({
    InputBar:{
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
        marginBottom: 5
    },
    InputWrapper:{
        width: '85%',
        borderRadius: 10,
        borderColor: "#FFF",
        borderWidth: 1,
        padding: 10,
        backgroundColor: "#FFF"
    }
});

export default Chat;