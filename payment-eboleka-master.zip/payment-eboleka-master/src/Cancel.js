import React from "react";
import CancelIcon from '@mui/icons-material/Cancel';
import Typography from '@mui/material/Typography';

const Cancel = ()=>{
    return(
        <div style = {{display: "flex", flexDirection: "column", height: "100vh", justifyContent: "center", alignItems: "center"}}>
            <CancelIcon style = {{color: 'gray', fontSize: 100}}/>
            <Typography variant="h4" style = {{color: "gray"}}>Unsuccessful</Typography>
        </div>
    );
}

export default Cancel;