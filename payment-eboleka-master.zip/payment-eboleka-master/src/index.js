import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

const root = ReactDOM.createRoot(
  document.getElementById('root'));
root.render(
  <React.StrictMode>
    <div style = {{background: '#121212', minHeight: "100vh", margin: 0, padding:0}}>
    <App />
    </div>
  </React.StrictMode>
);

