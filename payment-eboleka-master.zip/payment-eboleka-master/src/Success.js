import React from "react";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import Typography from '@mui/material/Typography';


const Success = ()=>{
    return(
        <div style = {{display: "flex", flexDirection: "column", height: "100vh", justifyContent: "center", alignItems: "center"}}>
           <CheckCircleIcon  style = {{color: 'green', fontSize: 100}} />
           <Typography variant="h4" style = {{color: "green"}}>Successful</Typography>
        </div>
    );
}

export default Success;