import React, { useState, useEffect } from "react";
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import axios from "axios";
import CircularProgress from '@mui/material/CircularProgress';
import { useParams } from 'react-router-dom';

const Home = ()=>{
    const { id } = useParams();
    const [loading, setLoading] = useState(true);

    const [order, setOrder] = useState({});
    const [paymentData, setPaymentData] = useState({});
    const [signature, setSignature] = useState("");

    useEffect(()=>{
        const fetchData = async()=>{
            console.log(id);
            await axios.get('https://eboleka-security-ujtgqd57hq-rj.a.run.app/payment/order',
            { headers: {"Authorization" : `Bearer ${id}`} })
            .then((response)=>{
                const data = response.data;
                setOrder(data.order);
                setPaymentData(data.paymentData);
                setSignature(data.signature);
                setLoading(false);
                console.log(response);
            }).catch((reason)=>{
                console.log(reason);
                setLoading(false);
            });
        }

        if(id !== undefined){
            fetchData();
        }else{
            setLoading(false);
        }
    }, []);

   


    //eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyMzQ1NjY3OCIsInVybCI6ImVib2xla2EuY28uemEiLCJsYW5nIjoiamF2YSIsImZyYW1ld29yayI6InNwcmluZyIsImlhdCI6MTY4NzEwMTI2Nn0.pkvLPseJCx_pylC2TuV4DWAiWaXCxNIyATAMnxG6C0c
   
    if(Object.keys(order).length === 0 && Object.keys(paymentData).length === 0 && signature === ""){
        return(
            <div style = {{display: "flex", flexDirection: "column", alignItems: "center", justifyContent: 'center', height: "100vh"}}>
                {loading &&
                <CircularProgress style = {{color: "#FFB200"}}/>
                }

                {!loading &&
                <>
                    <Typography variant="h5" style = {{color: "white", paddingLeft: 12}}>Error</Typography>
                    <Typography variant="h6" style = {{color: "white", paddingLeft: 12}}>403 Forbidden</Typography>
                </>
                }
            </div>
        );
    }else{
        return(
            <div style = {{display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 20}}>
                <img src={order.imageUrl} alt="Product" style = {{width: "90%"}}/>
                <div style = {{width:  "90%", background: "#282828", marginTop: 12, paddingTop: 12, paddingBottom: 12 }}>
                <Typography variant="h6" style = {{color: "white", paddingLeft: 12}}>{order.title}</Typography>
                <Typography variant="body2" style = {{color: "white", paddingLeft: 12}}>{order.orderId}</Typography>
                <Typography variant="h6" style = {{color: "white", paddingLeft: 12}}>{`R${order.price}`}</Typography>
                </div>
    
                <form action="https://sandbox.payfast.co.za​/eng/process" method="post" style={{width: "100%", display: "flex", flexDirection: "column", alignItems: "center"}}>
                <input type="hidden" name="merchant_id" value={paymentData.merchant_id}/>
                <input type="hidden" name="merchant_key" value={paymentData.merchant_key}/>
                <input type="hidden" name="return_url" value={paymentData.return_url}/>
                <input type="hidden" name="cancel_url" value={paymentData.cancel_url}/>
                <input type="hidden" name="notify_url" value={paymentData.notify_url}/>
                <input type="hidden" name="name_first" value={paymentData.name_first}/>
                <input type="hidden" name="email_address" value={paymentData.email_address}/>
                <input type="hidden" name="m_payment_id" value={paymentData.m_payment_id}/>
                <input type="hidden" name="amount" value={paymentData.amount}/>
                <input type="hidden" name="item_name" value={paymentData.item_name}/>
                <input type="hidden" name="signature" value={signature}/>
                <Button type="submit" variant="contained" style = {{width: "90%", marginTop: 12, borderRadius: 0, background: "#FFB200", fontWeight: "bold"}}>PAY</Button>
                </form>
                
    
            </div>
        );
    }

    
}

export default Home;