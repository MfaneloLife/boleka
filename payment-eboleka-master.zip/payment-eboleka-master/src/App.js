import React from 'react';
import {Route, BrowserRouter, Routes, Outlet, Navigate} from "react-router-dom";
import Home from './Home';
import Success from './Success';
import Cancel from './Cancel';

function App() {
  return (
   <BrowserRouter>

    <Routes>
        <Route path='/:id' element = {<Home/>}/>
        <Route path='/*' element = {<Home/>}/>
        <Route path='/cancel' element = {<Cancel/>}/>
        <Route path='/success' element = {<Success/>}/>
    </Routes>

   </BrowserRouter>
  );
}

//lN!adXvesC?B

export default App;