const express = require("express");
const multer = require('multer');
const mailRouter = require("./src/routes/mail.js");
const paymentRouter = require("./src/routes/payment.js");
const app = express();

const upload = multer(); 
app.use(express.urlencoded({ extended: true })); // support encoded bodies

app.use(upload.any());

const cors=require("cors");
const corsOptions ={
   origin:'*', 
   credentials:true,            //access-control-allow-credentials:true
   optionSuccessStatus:200,
}

app.use(cors(corsOptions))

app.get('/', async(req, res)=>{
    res.status(200).json({status: 'Up'});
});

const port = process.env.port || 8080;

app.use(express.json());
app.use("/mail", mailRouter);
app.use("/payment", paymentRouter);

app.listen(port, ()=>{
    console.log(`security.eboleka.co.za running on port ${port}`);
});


