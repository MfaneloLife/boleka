const jwt = require("jsonwebtoken");
const TOKEN = require("../src/config/token.json");

exports.authenticateServer = function(req, res, next){
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, TOKEN["TOKEN_SECRET"], (err, server) => {
        if (err) return res.sendStatus(403);
        req.server = server;
        next();
    });
}

exports.authenticateOrder = function(req, res, next){
    console.log("here")
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    const _token = decodeURIComponent(token);

    jwt.verify(_token, TOKEN["TOKEN_SECRET"], (err, order) => {
        if (err) return res.sendStatus(403);
        req.order = order;
        next();
    });
}



