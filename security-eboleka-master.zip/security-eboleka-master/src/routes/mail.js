const express = require("express");
const users = require("../config/users.json");
const sendMail = require("../sendMail.js");
const {authenticateServer} = require("../middleware.js");

const mailRouter = express.Router();

mailRouter.post('/new-account', authenticateServer, async(req, res)=>{
    const sender = users["no-reply"];
    const receiver = req.body.email;
    const name = req.body.name;

    const message = `
    <p>Hello ${name},</p>
    <p>Welcome aboard to Eboleka! We are thrilled to have you join our community. Thank you for choosing us as your preferred app for renting services.</p>
    <p>As a new member, you now have access to an array of exciting features that will enhance your renting experience. Whether you're looking to rent or simply rent out services, we've got you covered!</p>
    `;

    sendMail("Account", sender, receiver, "Welcome to Eboleka", message, "Welcome to Eboleka");

    res.status(200).json({status: 'SUCCESS'});

});

mailRouter.post('/otp', authenticateServer, async(req, res)=>{
    const sender = users["no-reply"];
    const receiver = req.body.email;
    const name = req.body.name;
    const otp = req.body.otp;

    const message = `
    <p>Hello ${name},</p>
    <p>We're sending you this email to verify your identity. To sign in, please enter the following one-time password (OTP) within 10 minutes:</p>
    <p style="font-size: 30px; font-weight: 600px;">${otp}</p>
    <p>Please note that the OTP is valid for a limited time period. If you don't enter the OTP 10 minutes, you may need to generate a new one.</p>
    <p>Ensuring the security and integrity of your account is our top priority. By implementing this additional layer of protection, we aim to safeguard your personal information and maintain a secure environment for all our users.</p>
    <p>Thank you for your cooperation and understanding. We appreciate your commitment to maintaining the security of your account.</p>
    `;

    sendMail("Security", sender, receiver, "Account Verification: One-Time PIN Required for Enhanced Security", message, "OTP");

    res.status(200).json({status: 'SUCCESS'});

});

mailRouter.post('/approved', authenticateServer, async(req, res)=>{
    const sender = users["no-reply"];
    const receiver = req.body.email;
    const name = req.body.name;
    const id = req.body.id;
    const image = req.body.imageUrl;
    const title = req.body.title;
    const price = req.body.price;
    const date = req.body.date;
    const isCardPayment = Boolean(req.body.isCardPayment);

    const next = isCardPayment ? "Open the app and make a payment to secure your order" : "You will be required to make a cash payment on the date of the service";

    const message = `
    <p>Hello ${name},</p>
    <p>We are delighted to inform you that your order request #${id} has been successfully approved!</p>

    <div style = "display: flex; flex-direction: row;">
    <img alt = "product" style = "width: 150px; height: 150px;" src = ${image}/>

    <div style = "display: flex; flex-direction: column; margin-left: 12px;">
    <p>${title}<br>R${price}<br>${date}</p>
    </div>

    </div>
   

    <p>${next}</p>
    
    `;

    sendMail("Order", sender, receiver, `Eboleka Order Approved: #${id}`, message, "Order Approved");

    res.status(200).json({status: 'SUCCESS'});

});

mailRouter.post('/decline', authenticateServer, async(req, res)=>{
    const sender = users["no-reply"];
    const receiver = req.body.email;
    const name = req.body.name;
    const id = req.body.id;
    const image = req.body.imageUrl;
    const title = req.body.title;
    const price = req.body.price;
    const date = req.body.date;

    const message = `
    <p>Hello ${name},</p>
    <p>This email is to inform you that your order request #${id} has been declined unfortunately. Try to find an alternative service on the app.</p>

    <div style = "display: flex; flex-direction: row;">
    <img alt = "product" style = "width: 150px; height: 150px;" src = ${image}/>

    <div style = "display: flex; flex-direction: column; margin-left: 12px;">
    <p>${title}<br>R${price}<br>${date}</p>
    </div>

    </div>
    
    `;

    sendMail("Order", sender, receiver, `Eboleka Order Declined: #${id}`, message, "Order Declined");

    res.status(200).json({status: 'SUCCESS'});

});

mailRouter.post('/cancel', authenticateServer, async(req, res)=>{
    const sender = users["no-reply"];
    const receiver = req.body.email;
    const name = req.body.name;
    const id = req.body.id;
    const image = req.body.imageUrl;
    const title = req.body.title;
    const price = req.body.price;
    const date = req.body.date;

    const message = `
    <p>Hello ${name},</p>
    <p>This email is to inform you that your order request #${id} has been cancelled unfortunately. Try to find an alternative service on the app.</p>

    <div style = "display: flex; flex-direction: row;">
    <img alt = "product" style = "width: 150px; height: 150px;" src = ${image}/>

    <div style = "display: flex; flex-direction: column; margin-left: 12px;">
    <p>${title}<br>R${price}<br>${date}</p>
    </div>

    </div>
    <p>If you had already paid a full refund will be sent to your wallet.</p>
    `;

    sendMail("Order", sender, receiver, `Eboleka Order Cancelled: #${id}`, message, "Order Cancelled");

    res.status(200).json({status: 'SUCCESS'});

});

mailRouter.post('/payment', authenticateServer, async(req, res)=>{
    const sender = users["no-reply"];
    const receiver = req.body.email;
    const id = req.body.id;
    const image = req.body.imageUrl;
    const title = req.body.title;
    const price = req.body.price;
    const date = req.body.date;
    const name = req.body.name;

    const message = `
    <p>Hello ${name},</p>
    <p>We hope this email finds you well. We are writing to confirm the successful payment for your order #${id}. We are delighted to inform you that your payment has been received and processed.</p>

    <div style = "display: flex; flex-direction: row;">
    <img alt = "product" style = "width: 150px; height: 150px;" src = ${image}/>

    <div style = "display: flex; flex-direction: column; margin-left: 12px;">
    <p>${title}<br>R${price}<br>${date}</p>
    </div>

    </div>

    <p>We would like to take this opportunity to thank you for choosing us as your preferred supplier. Your satisfaction is our top priority, and we are committed to ensuring that your shopping experience with us is nothing short of exceptional.</p>

    `;

    sendMail("Payments", sender, receiver, `Eboleka Order Payment Received: #${id}`, message, "Payment Received");

    res.status(200).json({status: 'SUCCESS'});

});




module.exports = mailRouter;
