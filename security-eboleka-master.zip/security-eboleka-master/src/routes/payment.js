const express = require("express");
const payment = require("../config/payment.json");
const {authenticateServer, authenticateOrder} = require("../middleware.js");
const {generateOrderToken, generatePaymentToken} = require("../token.js");
const sendMail = require('../sendMail');
const users = require("../config/users.json");
const CryptoJS = require("crypto-js");
const axios = require("axios");

const paymentRouter = express.Router();

const transaction = async(data, payment_string, url, isvalid)=>{
    
    await axios.post(`${payment["transaction_url"]}`, {
        url: String(url),
        payment_string: String(payment_string),
        m_payment_id: String(data.m_payment_id),
        pf_payment_id: String(data.pf_payment_id),
        payment_status: String(data.payment_status),
        item_name: String(data.item_name),
        amount_gross: parseFloat(data.amount_gross),
        amount_net: parseFloat(data.amount_net),
        name_first: String(data.name_first),
        email_address: String(data.email_address),
        isvalid: Boolean(isvalid)
    }, {headers: {"Authorization" : `Bearer ${payment["token"]}`}})
    .then((response)=>{
        console.log(response.data);
    }).catch((err)=>{
        console.log(err);
    });
}

const generateSignature = (data, passPhrase = null) => {
    let pfOutput = "";
    for (let key in data) {
      if(data.hasOwnProperty(key)){
        if (data[key] !== "") {
          pfOutput +=`${key}=${encodeURIComponent(data[key]).replace(/%20/g, "+")}&`
        }
      }
    }
  
    let getString = pfOutput.slice(0, -1);
    if (passPhrase !== null) {
      getString +=`&passphrase=${encodeURIComponent(passPhrase.trim()).replace(/%20/g, "+")}`;
    }
  
    return CryptoJS.MD5(getString).toString();
};

const generateData = (data)=>{
    let pfParamString = "";
    for (let key in data) {
        if(data.hasOwnProperty(key) && key !== "signature"){
            pfParamString +=`${key}=${encodeURIComponent(data[key]).replace(/%20/g, "+")}&`;
        }
    }

    return pfParamString.slice(0, -1);
}

const regenerateSignature = (pfParamString, pfPassphrase = null )=>{
    if (pfPassphrase !== null) {
        pfParamString +=`&passphrase=${encodeURIComponent(pfPassphrase.trim()).replace(/%20/g, "+")}`;
    }

    return CryptoJS.MD5(pfParamString).toString();
}

const isPaymentValid = (passphrase, data, signature, referer)=>{
    const pfData = generateData(data);

    if(regenerateSignature(pfData, passphrase) !== signature){
        return false;
    }

    const refererSplit = referer.split(".");

    const length = refererSplit.length;

    if(length < 3){
        return false;
    }

    const url = `${refererSplit[length - 3]}.${refererSplit[length - 2]}.${refererSplit[length - 1]}`;
    const payfast = 'payfast.co.za';

    if(url !== payfast){
        return false;
    }

    return true;
}
  
paymentRouter.post('/identifier', authenticateServer, async(req, res)=>{
    const uid = req.body.uid;
    const title = req.body.title;
    const imageUrl = req.body.imageUrl;
    const name = req.body.name;
    const email = req.body.email;

    await axios.post(payment["identifier_url"],
        {uid: uid}, 
        {headers: {"Authorization" : `Bearer ${payment["token"]}`}})
        .then((response)=>{
            const data = response.data.data;
            const secret = generateOrderToken(data.uid, data.orderId, title, data.price, imageUrl, name, email);
            res.status(200).json({key: encodeURIComponent(secret)});
        }).catch((err)=>{
            res.status(400).json({});
        });
});

paymentRouter.get('/order', authenticateOrder, async(req, res)=>{
    const order = req.order;

    const passPhrase = "abcde123456789"; //payment["passPhrase"];

    const paymentData = {
        merchant_id: "10029871", //payment["merchant_id"],
        merchant_key: "8h2uwr9gub5jn", //payment["merchant_key"],
        return_url: payment["return_url"],
        cancel_url: payment["cancel_url"],
        notify_url: payment["notify_url"],
        name_first: order.name,
        email_address: order.email,
        m_payment_id: order.uid,
        amount: order.price,
        item_name: order.title,
    };

    const signature = generateSignature(paymentData, passPhrase);

    res.status(200).json({order, paymentData, signature});
});

paymentRouter.post('/itn', async(req, res)=>{
    const data = {
        m_payment_id: req.body.m_payment_id,
        pf_payment_id: req.body.pf_payment_id,
        payment_status: req.body.payment_status,
        item_name: req.body.item_name,
        item_description: req.body.item_description,
        amount_gross: req.body.amount_gross,
        amount_fee: req.body.amount_fee,
        amount_net: req.body.amount_net,
        custom_str1: req.body.custom_str1,
        custom_str2: req.body.custom_str2,
        custom_str3: req.body.custom_str3,
        custom_str4: req.body.custom_str4,
        custom_str5: req.body.custom_str5,
        custom_int1: req.body.custom_int1,
        custom_int2: req.body.custom_int2,
        custom_int3: req.body.custom_int3,
        custom_int4: req.body.custom_int4,
        custom_int5: req.body.custom_int5,
        name_first: req.body.name_first,
        name_last: req.body.name_last,
        email_address: req.body.email_address,
        merchant_id: req.body.merchant_id,
        signature: req.body.signature
    }

    const passphrase = "abcde123456789"; //payment["passPhrase"];

    const referer = req.headers.referer;
    
    let isvalid = isPaymentValid(passphrase, data, data.signature, referer);
    transaction(data, generateData(data), referer, isvalid);

    res.sendStatus(200);
});

module.exports = paymentRouter;
