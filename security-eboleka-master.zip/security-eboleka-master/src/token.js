const TOKEN = require("../src/config/token.json");
const jwt = require("jsonwebtoken");

exports.generateAPIToken = function(){
    const server = {
        id: "",
        key: "",
        phrase: ""
    }

    return jwt.sign(server, TOKEN["TOKEN_SECRET"]);
}

exports.generateOrderToken = function(uid, orderId, title, price, imageUrl, name, email){
    const order = {
        uid,
        orderId,
        title,
        price,
        imageUrl,
        name, 
        email
    }

    return jwt.sign(order, TOKEN["TOKEN_SECRET"], { expiresIn: '3600s' });
}

exports.generatePaymentToken = function(uid, amount){
    const payload = {
        uid,
        amount
    }

    return jwt.sign(payload, TOKEN["TOKEN_SECRET"], { expiresIn: '43200s' });
}
