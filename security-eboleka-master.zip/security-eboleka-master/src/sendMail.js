const nodemailer = require("nodemailer");

async function sendMail(name, sender, receiver, subject, body, title) {

    const message = `
    <html>
        <body style = "font-family: Arial, sans-serif; background-color: #f1f1f1;">
            <div style = "margin: 0 auto;padding: 20px;background-color: #ffffff;box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);">
        
                <div style = "display: flex; flex-direction: row; align-items: center;">
                    <img alt="Eboleka logo" src="https://firebasestorage.googleapis.com/v0/b/eboleka-3a6ee.appspot.com/o/utils%2Flogo.png?alt=media&token=5a8f4424-607a-411a-a764-ef8ead00ccc0" style = " width: 50px; height: 50px;" />
                    <p style = " margin-left: 12px;font-size: 20px;">${title}</p>
                </div>
        
                <hr>

                ${body}

                <p>Regards,<br>Eboleka team</p>
        
                <div style = "display: flex; flex-direction: column; background-color: #000000; padding-top: 12px; padding-bottom: 12px; align-items: center; color: #999999; width: 100%">
                    <p style = "margin: 1px;font-size: 10px;">&#169; 2023 Eboleka (PTY) LTD <br>277 Magagula Heights Katlehong 1431<br>support@eboleka.co.za</p>
    
                </div>
            </div>
        </body>
    </html>
    `;

    let transporter = nodemailer.createTransport({
        host: "mail.eboleka.co.za",
        port: 587,
        secure: false, 
        auth: {
        user: sender.email,
        pass: sender.key
        },
        tls: {
            rejectUnauthorized: false
        }
    });

  let info = await transporter.sendMail({
    from: `"${name}" <${sender.email}>`,
    to: `${receiver}, ${receiver}`,
    subject: subject,
    html: message, 
  });

}

module.exports = sendMail;

